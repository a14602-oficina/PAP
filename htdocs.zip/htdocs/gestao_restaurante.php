<?php
require_once "auth_check.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "admin") {
    header("Location: login.php"); exit;
}
$adminName = $_SESSION["name"] ?? "Administrador";

if (!is_dir("uploads")) mkdir("uploads", 0755, true);

/* Garantir tabela de info do restaurante */
$conn->query("
    CREATE TABLE IF NOT EXISTS restaurant_map (
        id INT AUTO_INCREMENT PRIMARY KEY,
        filename VARCHAR(255) NOT NULL,
        label VARCHAR(120) DEFAULT 'Planta Principal',
        ativo TINYINT(1) DEFAULT 1,
        uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");

/* Inserir linha info se não existir */

$msg = ""; $msgType = "success";

/* ── GUARDAR INFO ── */
/* ── UPLOAD PLANTA ── */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["upload_map"])) {
    if (!empty($_FILES["map_file"]["name"])) {
        $allowed = ["jpg","jpeg","png","webp","gif","svg","pdf"];
        $ext = strtolower(pathinfo($_FILES["map_file"]["name"], PATHINFO_EXTENSION));
        if (in_array($ext, $allowed) && $_FILES["map_file"]["error"] === 0) {
            /* Desativar plantas anteriores */
            $conn->query("UPDATE restaurant_map SET ativo=0");
            $fname = "mapa_restaurante_" . time() . "." . $ext;
            if (move_uploaded_file($_FILES["map_file"]["tmp_name"], "uploads/" . $fname)) {
                $label = trim($_POST["map_label"] ?? "Planta Principal");
                $stmt  = $conn->prepare("INSERT INTO restaurant_map (filename, label, ativo) VALUES (?,?,1)");
                $stmt->bind_param("ss", $fname, $label);
                $stmt->execute();
                /* Atualizar também nome canónico para a entrada_dashboard */
                @copy("uploads/" . $fname, "uploads/mapa_restaurante." . $ext);
                header("Location: gestao_restaurante.php?msg=map"); exit;
            }
        }
        $msg = "Formato inválido ou erro no upload."; $msgType = "error";
    }
}

/* ── ATIVAR PLANTA ── */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["activate_map"])) {
    $mapId = intval($_POST["map_id"]);
    $conn->query("UPDATE restaurant_map SET ativo=0");
    $stmt = $conn->prepare("UPDATE restaurant_map SET ativo=1 WHERE id=?");
    $stmt->bind_param("i", $mapId); $stmt->execute();
    /* Copiar para nome canónico */
    $mapRow = $conn->query("SELECT filename FROM restaurant_map WHERE id=$mapId")->fetch_assoc();
    if ($mapRow) {
        $ext = pathinfo($mapRow["filename"], PATHINFO_EXTENSION);
        foreach (glob("uploads/mapa_restaurante.*") as $f) @unlink($f);
        @copy("uploads/" . $mapRow["filename"], "uploads/mapa_restaurante." . $ext);
    }
    header("Location: gestao_restaurante.php?msg=activated"); exit;
}

/* ── APAGAR PLANTA ── */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["delete_map"])) {
    $mapId = intval($_POST["map_id"]);
    $mapRow = $conn->query("SELECT * FROM restaurant_map WHERE id=$mapId")->fetch_assoc();
    if ($mapRow) {
        @unlink("uploads/" . $mapRow["filename"]);
        $conn->query("DELETE FROM restaurant_map WHERE id=$mapId");
        if ($mapRow["ativo"]) foreach (glob("uploads/mapa_restaurante.*") as $f) @unlink($f);
    }
    header("Location: gestao_restaurante.php?msg=deleted"); exit;
}

if (isset($_GET["msg"])) {
    $msgs = ["info"=>"Informações guardadas.","map"=>"Planta carregada e ativada.","activated"=>"Planta ativada.","deleted"=>"Planta removida."];
    $msg = $msgs[$_GET["msg"]] ?? ""; $msgType = "success";
}

/* Recarregar info */
$maps    = $conn->query("SELECT * FROM restaurant_map ORDER BY uploaded_at DESC");
$mapList = []; while($r = $maps->fetch_assoc()) $mapList[] = $r;
$activeMap = array_filter($mapList, fn($m) => $m["ativo"]);
$activeMap = reset($activeMap);

/* Estatísticas rápidas */
$totalMesas  = intval($conn->query("SELECT COUNT(*) AS n FROM `tables`")->fetch_assoc()["n"]);
$livres      = intval($conn->query("SELECT COUNT(*) AS n FROM `tables` WHERE status='livre'")->fetch_assoc()["n"]);
$ocupadas    = intval($conn->query("SELECT COUNT(*) AS n FROM `tables` WHERE status='ocupada'")->fetch_assoc()["n"]);
$pedidosHoje = intval($conn->query("SELECT COUNT(*) AS n FROM orders WHERE DATE(created_at)=CURDATE()")->fetch_assoc()["n"]);
$faturHoje   = floatval($conn->query("SELECT COALESCE(SUM(total),0) AS t FROM orders WHERE DATE(created_at)=CURDATE() AND status='pago'")->fetch_assoc()["t"]);
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>SmartTable — Gestão do Restaurante</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="favicon.ico" sizes="any">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="apple-touch-icon" href="assets/logo.png">
<link rel="manifest" href="site.webmanifest">
<meta name="theme-color" content="#0d0600">
<?php include_once __DIR__ . "/theme.php"; ?>
<style>
*{box-sizing:border-box;margin:0;padding:0;font-family:Georgia,"Times New Roman",serif}
body{min-height:100vh;color:var(--cream)}

/* msg */
.msg{padding:14px 18px;border-radius:14px;margin-bottom:22px;font-weight:bold;font-size:15px}
.msg.success{background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.35);color:#86efac}
.msg.error  {background:rgba(239,68,68,.12);border:1px solid rgba(239,68,68,.35);color:#fca5a5}

/* kpi strip */
.kpi-strip{display:grid;grid-template-columns:repeat(5,1fr);gap:14px;margin-bottom:28px}
.kpi{padding:18px 20px;border-radius:18px;background:linear-gradient(145deg,rgba(38,21,8,.82),rgba(13,6,0,.96));border:1px solid rgba(201,168,76,.2)}
.kpi-label{font-size:11px;letter-spacing:3px;color:rgba(245,234,216,.5);margin-bottom:6px}
.kpi-val{font-size:28px;font-weight:bold;color:var(--cream)}
.kpi-val.green{color:#86efac}.kpi-val.red{color:#fca5a5}.kpi-val.gold{color:var(--gold-light)}

/* layout 2 col */

/* panel */
.panel{border:1px solid rgba(201,168,76,.25);border-radius:22px;background:linear-gradient(145deg,rgba(38,21,8,.82),rgba(13,6,0,.96));overflow:hidden;margin-bottom:22px}
.panel-header{padding:20px 26px;border-bottom:1px solid rgba(201,168,76,.14);display:flex;align-items:center;gap:12px}
.panel-header h2{color:var(--gold-light);font-size:22px}
.panel-header .icon{font-size:20px}
.panel-body{padding:24px 26px}

/* form */
.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.form-group{display:flex;flex-direction:column;gap:7px}
.form-group.full{grid-column:1/-1}
label{font-size:13px;color:var(--cream2)}
input[type=text],input[type=email],input[type=tel],input[type=time],input[type=number],textarea,select{
  padding:12px 14px;border-radius:12px;border:1px solid rgba(201,168,76,.22);
  background:rgba(13,6,0,.72);color:var(--cream);font-size:14px;
  font-family:Georgia,"Times New Roman",serif;outline:none;width:100%;
}
input:focus,textarea:focus{border-color:var(--gold);box-shadow:0 0 0 3px rgba(201,168,76,.12)}
textarea{resize:vertical;min-height:90px}
input[type=file]{padding:10px 14px;cursor:pointer}
input[type=file]::file-selector-button{background:linear-gradient(135deg,var(--gold),var(--gold-light));color:#140900;border:none;padding:7px 14px;border-radius:8px;cursor:pointer;font-family:Georgia,"Times New Roman",serif;font-size:13px;margin-right:12px}

/* btns */
.btn{padding:12px 20px;border-radius:13px;background:linear-gradient(135deg,var(--gold),var(--gold-light));color:#140900;font-weight:bold;border:none;cursor:pointer;font-size:14px;font-family:Georgia,"Times New Roman",serif;transition:.2s}
.btn:hover{opacity:.9;transform:translateY(-1px)}
.btn-danger{padding:10px 16px;border-radius:12px;background:rgba(239,68,68,.1);color:#fca5a5;border:1px solid rgba(239,68,68,.28);cursor:pointer;font-size:13px;font-family:Georgia,"Times New Roman",serif}
.btn-secondary{padding:10px 16px;border-radius:12px;background:rgba(201,168,76,.08);color:var(--gold-light);border:1px solid rgba(201,168,76,.2);cursor:pointer;font-size:13px;font-family:Georgia,"Times New Roman",serif}
.form-actions{display:flex;gap:10px;margin-top:18px;flex-wrap:wrap}

/* mapa preview */
.map-active{
  border:2px solid rgba(34,197,94,.4);border-radius:18px;overflow:hidden;
  background:rgba(13,6,0,.5);margin-bottom:18px;position:relative;
}
.map-active img{width:100%;max-height:340px;object-fit:contain;display:block;padding:16px}
.map-active-badge{
  position:absolute;top:12px;right:12px;padding:5px 12px;border-radius:999px;
  background:rgba(34,197,94,.2);border:1px solid rgba(34,197,94,.4);color:#86efac;font-size:12px;font-weight:bold;
}
.map-no-img{
  border:2px dashed rgba(201,168,76,.18);border-radius:18px;
  min-height:160px;display:flex;flex-direction:column;align-items:center;justify-content:center;
  gap:10px;color:rgba(245,234,216,.35);margin-bottom:18px;
}
.map-no-img svg{opacity:.25}

/* histórico de plantas */
.map-list{display:flex;flex-direction:column;gap:10px}
.map-row{
  display:flex;align-items:center;gap:12px;padding:12px 16px;border-radius:14px;
  background:rgba(13,6,0,.45);border:1px solid rgba(201,168,76,.12);
}
.map-thumb{width:52px;height:40px;object-fit:cover;border-radius:8px;border:1px solid rgba(201,168,76,.18);flex-shrink:0}
.map-info{flex:1;min-width:0}
.map-info strong{font-size:14px;color:var(--cream)}
.map-info span{font-size:12px;color:rgba(245,234,216,.45);display:block}
.map-row-actions{display:flex;gap:8px;flex-shrink:0}
.badge-active{padding:3px 10px;border-radius:999px;background:rgba(34,197,94,.15);border:1px solid rgba(34,197,94,.3);color:#86efac;font-size:11px}

/* zona de upload drag & drop */
.upload-zone{
  border:2px dashed rgba(201,168,76,.3);border-radius:16px;padding:28px;text-align:center;
  background:rgba(201,168,76,.03);transition:.2s;cursor:pointer;margin-bottom:14px;
}
.upload-zone:hover,.upload-zone.drag{border-color:var(--gold);background:rgba(201,168,76,.07)}
.upload-zone p{color:rgba(245,234,216,.55);font-size:14px;margin-top:8px}
.upload-zone input[type=file]{display:none}

/* horários visual */

@media(max-width:1100px){.kpi-strip{grid-template-columns:repeat(3,1fr)}}
@media(max-width:900px){.kpi-strip{grid-template-columns:repeat(2,1fr)}.form-grid{grid-template-columns:1fr}.page-title{font-size:32px}}
</style>
<style id="sidebar-fixed">
.topbar h1,.page-topbar h1{font-size:44px;line-height:1;color:var(--cream);margin:0}

/* ── TOPBAR UNIFICADO ── */
.topbar,.page-topbar{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:32px;flex-wrap:wrap}
.topbar-left,.page-subtitle,.subtitle{color:var(--gold-light,#e8c97a);letter-spacing:7px;font-size:12px;margin-bottom:6px;display:block}
.session-box,.session,.user-box{
  padding:11px 20px;
  border-radius:999px;
  background:rgba(13,6,0,.65);
  border:1px solid rgba(var(--gold-rgb,201,168,76),.25);
  color:var(--cream2,#ede0c4);
  font-size:14px;
  white-space:nowrap;
  font-family:var(--font,Georgia),serif;
}

/* ── SIDEBAR FIXA ── */
.admin-layout{display:block;margin:0;padding:0}
.sidebar{
  width:285px;min-width:285px;padding:26px 24px;
  background:var(--sidebar-gradient,linear-gradient(180deg,rgba(26,14,4,.98),rgba(13,6,0,.96)));
  border-right:1px solid rgba(var(--gold-rgb,201,168,76),.22);
  position:fixed!important;top:0;left:0;
  height:100vh;overflow-y:auto;overflow-x:hidden;
  z-index:100;display:flex;flex-direction:column;
}
.sidebar::-webkit-scrollbar{width:4px}
.sidebar::-webkit-scrollbar-thumb{background:rgba(201,168,76,.25);border-radius:2px}
.content{margin-left:285px!important;padding:34px 46px;overflow-x:auto;min-height:100vh}
.sidebar .sidebar-logo{display:flex!important;flex-direction:row!important;align-items:center!important;gap:14px!important;margin-bottom:42px!important;flex-shrink:0}
.sidebar .logo-box{width:56px!important;height:56px!important;border-radius:var(--radius,18px)!important;background:var(--grad-primary,linear-gradient(135deg,#c9a84c,#e8c97a))!important;color:#140900!important;display:flex!important;align-items:center!important;justify-content:center!important;font-size:28px!important;font-weight:bold!important;flex-shrink:0!important}
.sidebar .sidebar-logo h2{color:var(--gold-light,#e8c97a)!important;font-size:24px!important;line-height:1!important;margin:0!important}
.sidebar .sidebar-logo span{font-size:12px!important;color:rgba(245,234,216,.55)!important;letter-spacing:2px!important;display:block!important}
.menu-title{font-size:12px;color:rgba(245,234,216,.45);letter-spacing:3px;margin-bottom:16px;flex-shrink:0}
.side-menu{display:flex;flex-direction:column;gap:10px;flex:1}
.side-menu a{padding:14px 16px;border-radius:var(--radius,16px);color:var(--cream2,#ede0c4);text-decoration:none;background:rgba(var(--gold-rgb,201,168,76),.06);border:1px solid rgba(var(--gold-rgb,201,168,76),.12);transition:.22s ease;font-size:var(--fs-base,15px);display:block}
.side-menu a:hover,.side-menu a.active{background:var(--grad-primary,linear-gradient(135deg,#c9a84c,#e8c97a));color:#140900;font-weight:bold;transform:translateX(4px)}
.sidebar .logout{margin-top:18px;flex-shrink:0;display:block;padding:14px;border-radius:var(--radius,14px);text-align:center;color:#fca5a5;text-decoration:none;border:1px solid rgba(239,68,68,.35);background:rgba(239,68,68,.08);font-size:var(--fs-base,15px);font-weight:bold;transition:.2s}
.sidebar .logout:hover{background:rgba(239,68,68,.18)}
@media(max-width:900px){
  .admin-layout{display:block;margin:0;padding:0}
  .sidebar{position:relative!important;width:100%!important;min-width:100%!important;height:auto!important;overflow:visible!important}
  .content,main.content{margin-left:0!important;padding:24px 18px;overflow-x:auto;min-height:auto;width:100%!important}
  .side-menu a{padding:11px 14px}
  .side-menu a:hover,.side-menu a.active{transform:none}
}
</style>
<link rel="stylesheet" href="assets/responsive_global.css">
</head>
<body>
<div class="admin-layout">
<?php include "sidebar_admin.php"; ?>
<main class="content" style="display:block;min-height:100vh;box-sizing:border-box">

  <!-- TOPBAR -->
  <div class="topbar">
    <div>
      <p class="subtitle">GESTÃO DO RESTAURANTE</p>
      <h1>Restaurante</h1>
    </div>
    <div class="topbar-right">
      <div class="session-box">Sessão iniciada como: <strong><?= htmlspecialchars($adminName) ?></strong></div>
    </div>
  </div>

  <?php if ($msg): ?>
    <div class="msg <?= $msgType ?>"><?= htmlspecialchars($msg) ?></div>
  <?php endif; ?>

  <!-- KPIs -->
  <div class="kpi-strip">
    <div class="kpi">
      <div class="kpi-label">TOTAL MESAS</div>
      <div class="kpi-val gold"><?= $totalMesas ?></div>
    </div>
    <div class="kpi">
      <div class="kpi-label">LIVRES AGORA</div>
      <div class="kpi-val green"><?= $livres ?></div>
    </div>
    <div class="kpi">
      <div class="kpi-label">OCUPADAS AGORA</div>
      <div class="kpi-val red"><?= $ocupadas ?></div>
    </div>
    <div class="kpi">
      <div class="kpi-label">PEDIDOS HOJE</div>
      <div class="kpi-val"><?= $pedidosHoje ?></div>
    </div>
    <div class="kpi">
      <div class="kpi-label">FATURADO HOJE</div>
      <div class="kpi-val gold"><?= number_format($faturHoje,2,",",".") ?> €</div>
    </div>
  </div>

  
<!-- Planta ativa -->
      <div class="panel">
        <div class="panel-header">
          <span class="icon">🗺️</span>
          <h2>Planta do Restaurante</h2>
        </div>
        <div class="panel-body">

          <?php if ($activeMap && file_exists("uploads/" . $activeMap["filename"])): ?>
            <div class="map-active">
              <span class="map-active-badge">✔ Ativa</span>
              <img src="uploads/<?= htmlspecialchars($activeMap["filename"]) ?>"
                   alt="<?= htmlspecialchars($activeMap["label"]) ?>">
            </div>
            <p style="font-size:13px;color:rgba(245,234,216,.45);margin-bottom:16px">
              <?= htmlspecialchars($activeMap["label"]) ?> ·
              Carregada em <?= date("d/m/Y H:i", strtotime($activeMap["uploaded_at"])) ?>
            </p>
          <?php else: ?>
            <div class="map-no-img">
              <svg width="52" height="52" viewBox="0 0 24 24" fill="none" stroke="#c9a84c" stroke-width="1.5">
                <rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/>
              </svg>
              <p>Nenhuma planta carregada</p>
            </div>
          <?php endif; ?>

          <!-- Upload nova planta -->
          <form method="POST" enctype="multipart/form-data" id="uploadForm">
            <div class="upload-zone" id="uploadZone" onclick="document.getElementById('mapFileInput').click()">
              <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="#c9a84c" stroke-width="1.5" style="margin:0 auto;display:block">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>
              </svg>
              <p>Clique ou arraste aqui a imagem da planta<br><small>PNG, JPG, WEBP, SVG, PDF — máx. 10MB</small></p>
              <input type="file" id="mapFileInput" name="map_file" accept="image/*,.pdf" onchange="previewMap(this)">
            </div>

            <div id="mapPreviewWrap" style="display:none;margin-bottom:14px">
              <img id="mapPreviewImg" style="max-width:100%;max-height:180px;border-radius:12px;border:1px solid rgba(201,168,76,.2)">
            </div>

            <div class="form-grid" style="margin-bottom:14px">
              <div class="form-group full">
                <label>Etiqueta / Nome da planta</label>
                <input type="text" name="map_label" value="Planta Principal" placeholder="Ex: Sala Principal, Esplanada…">
              </div>
            </div>

            <button type="submit" name="upload_map" class="btn">⬆ Carregar Planta</button>
          </form>
        </div>
      </div>

      <!-- Histórico de plantas -->
      <?php if (!empty($mapList)): ?>
      <div class="panel">
        <div class="panel-header">
          <span class="icon">📁</span>
          <h2>Histórico de Plantas</h2>
        </div>
        <div class="panel-body">
          <div class="map-list">
            <?php foreach ($mapList as $m): ?>
              <?php $isImg = in_array(strtolower(pathinfo($m["filename"],PATHINFO_EXTENSION)),["jpg","jpeg","png","webp","gif"]); ?>
              <div class="map-row">
                <?php if ($isImg && file_exists("uploads/".$m["filename"])): ?>
                  <img src="uploads/<?= htmlspecialchars($m["filename"]) ?>" class="map-thumb" alt="">
                <?php else: ?>
                  <div class="map-thumb" style="background:rgba(201,168,76,.1);display:flex;align-items:center;justify-content:center;font-size:18px">📄</div>
                <?php endif; ?>
                <div class="map-info">
                  <strong><?= htmlspecialchars($m["label"]) ?></strong>
                  <span><?= date("d/m/Y H:i", strtotime($m["uploaded_at"])) ?></span>
                </div>
                <?php if ($m["ativo"]): ?>
                  <span class="badge-active">Ativa</span>
                <?php else: ?>
                  <form method="POST" style="display:inline">
                    <input type="hidden" name="map_id" value="<?= $m["id"] ?>">
                    <button type="submit" name="activate_map" class="btn-secondary">Ativar</button>
                  </form>
                <?php endif; ?>
                <form method="POST" style="display:inline"
                      onsubmit="return confirm('Apagar esta planta?')">
                  <input type="hidden" name="map_id" value="<?= $m["id"] ?>">
                  <button type="submit" name="delete_map" class="btn-danger">🗑</button>
                </form>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
      <?php endif; ?>

</main>
</div>

<script>
/* Drag & Drop na zona de upload */
const zone = document.getElementById('uploadZone');
zone.addEventListener('dragover',  function(e){ e.preventDefault(); zone.classList.add('drag'); });
zone.addEventListener('dragleave', function(){ zone.classList.remove('drag'); });
zone.addEventListener('drop', function(e){
  e.preventDefault(); zone.classList.remove('drag');
  const file = e.dataTransfer.files[0];
  if (file) {
    const dt = new DataTransfer(); dt.items.add(file);
    document.getElementById('mapFileInput').files = dt.files;
    previewMap(document.getElementById('mapFileInput'));
  }
});

function previewMap(input) {
  const wrap = document.getElementById('mapPreviewWrap');
  const img  = document.getElementById('mapPreviewImg');
  if (input.files && input.files[0] && input.files[0].type.startsWith('image/')) {
    const reader = new FileReader();
    reader.onload = function(e){ img.src = e.target.result; wrap.style.display='block'; };
    reader.readAsDataURL(input.files[0]);
    document.getElementById('uploadZone').querySelector('p').textContent = input.files[0].name;
  }
}
</script>

<script src="assets/keep_session.js"></script>
<script src="assets/notifications.js"></script>
</body>
</html>
<?php
require_once "error_config.php";

require_once "auth_check.php";
require_once "service_flow.php";
st_ensure_service_flow_columns($conn);
st_reset_service_flow_for_free_tables($conn);

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "empregado_mesa") {
    header("Location: login.php");
    exit;
}

$empregadoMesa = $_SESSION["name"] ?? "Empregado de Mesa";

/* ENTREGAR ENTRADAS/BEBIDAS */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["deliver_entries_drinks"])) {
    $tableNumber = intval($_POST["table_number"] ?? 0);

    $stmt = $conn->prepare("
        UPDATE `tables`
        SET entries_drinks_delivered_at = NOW()
        WHERE number = ?
    ");
    $stmt->bind_param("i", $tableNumber);
    $stmt->execute();

    header("Location: empregado_mesa_dashboard.php");
    exit;
}

/* DESBLOQUEAR PRATO PRINCIPAL */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["unlock_main"])) {
    $tableNumber = intval($_POST["table_number"] ?? 0);

    $stmt = $conn->prepare("
        UPDATE `tables`
        SET main_unlocked = 1,
            main_unlocked_at = NOW()
        WHERE number = ?
        AND entries_drinks_delivered_at IS NOT NULL
    ");
    $stmt->bind_param("i", $tableNumber);
    $stmt->execute();

    header("Location: empregado_mesa_dashboard.php");
    exit;
}

/* PRATO PRINCIPAL ENTREGUE — desbloqueia sobremesa E finaliza
   automaticamente todos os pedidos "prontos" desta mesa, para o
   empregado de mesa só ter de fazer um único clique. */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["deliver_main"])) {
    $tableNumber = intval($_POST["table_number"] ?? 0);

    $stmt = $conn->prepare("
        UPDATE `tables`
        SET main_delivered_at = NOW(),
            dessert_unlocked = 1,
            dessert_unlocked_at = NOW()
        WHERE number = ?
        AND main_unlocked = 1
    ");
    $stmt->bind_param("i", $tableNumber);
    $stmt->execute();

    $stmtFinalize = $conn->prepare("
        UPDATE orders
        SET status = 'finalizado'
        WHERE table_number = ? AND status = 'pronto'
    ");
    $stmtFinalize->bind_param("i", $tableNumber);
    $stmtFinalize->execute();

    header("Location: empregado_mesa_dashboard.php");
    exit;
}

/* LIMPAR PEDIDOS DA MESA */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["limpar_pedidos_mesa"])) {
    $tableNumber = trim($_POST["table_number"] ?? "");
    if ($tableNumber !== "") {
        // Cancela todos os pedidos não pagos desta mesa (usar string para compatibilidade)
        $stmt = $conn->prepare("
            UPDATE orders SET status = 'cancelado'
            WHERE table_number = ? AND status NOT IN ('pago','cancelado')
        ");
        $stmt->bind_param("s", $tableNumber);
        $stmt->execute();

        // Limpa bar_orders pendentes desta mesa, se a tabela existir
        $barTableCheck = $conn->query("SHOW TABLES LIKE 'bar_orders'");
        if ($barTableCheck && $barTableCheck->num_rows > 0) {
            $stmtBar = $conn->prepare("
                UPDATE bar_orders SET status = 'pronto'
                WHERE table_number = ? AND status IN ('pendente','preparando')
            ");
            if ($stmtBar) {
                $stmtBar->bind_param("s", $tableNumber);
                $stmtBar->execute();
            }
        }

        // Reset service flow da mesa
        $tableNumberInt = intval($tableNumber);
        if ($tableNumberInt > 0) {
            st_reset_table_service_flow($conn, $tableNumberInt);
        }
    }
    header("Location: empregado_mesa_dashboard.php");
    exit;
}

function tempoSentado($arrivalTime) {
    if (empty($arrivalTime)) {
        return "--";
    }

    $diff = time() - strtotime($arrivalTime);
    $horas = floor($diff / 3600);
    $minutos = floor(($diff % 3600) / 60);

    return $horas > 0 ? $horas . "h " . $minutos . "min" : $minutos . "min";
}

$empregadoMesaId = intval($_SESSION["user_id"]);

/* Garantir que a tabela waiter_tables existe */
$conn->query("CREATE TABLE IF NOT EXISTS waiter_tables (
    id INT AUTO_INCREMENT PRIMARY KEY,
    waiter_id INT NOT NULL,
    table_number INT NOT NULL,
    UNIQUE KEY unique_assignment (waiter_id, table_number)
)");

$assignedCheck = $conn->prepare("
    SELECT table_number
    FROM waiter_tables
    WHERE waiter_id = ?
");
$assignedCheck->bind_param("i", $empregadoMesaId);
$assignedCheck->execute();
$assignedResult = $assignedCheck->get_result();

$assignedNumbers = [];

while ($row = $assignedResult->fetch_assoc()) {
    $assignedNumbers[] = intval($row["table_number"]);
}

if (!empty($assignedNumbers)) {
    $numbersSql = implode(",", $assignedNumbers);

    $tables = $conn->query("
        SELECT *
        FROM `tables`
        WHERE number IN ($numbersSql)
        ORDER BY number ASC
    ");
} else {
    $tables = false;
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>SmartTable - Empregado de Mesa</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="favicon.ico" sizes="any">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="apple-touch-icon" href="assets/logo.png">
<link rel="manifest" href="site.webmanifest">
<meta name="theme-color" content="#0d0600">

<?php include_once __DIR__ . "/theme.php"; ?>
<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Georgia,"Times New Roman",serif;
}

body{
    min-height:100vh;
    background:
        linear-gradient(90deg,rgba(201,168,76,.04) 1px,transparent 1px),
        linear-gradient(rgba(201,168,76,.03) 1px,transparent 1px),
        radial-gradient(circle at top left,rgba(201,168,76,.18),transparent 35%),
        linear-gradient(135deg,var(--dark),#080300 70%);
    background-size:80px 80px,80px 80px,cover,cover;
    color:var(--cream);
}

.header{
    padding:26px 42px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    background:rgba(13,6,0,.78);
    border-bottom:1px solid rgba(201,168,76,.25);
}

.brand{
    display:flex;
    align-items:center;
    gap:14px;
}

.logo{
    width:58px;
    height:58px;
    border-radius:16px;
    background:linear-gradient(135deg,var(--gold),var(--gold-light));
    color:#140900;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:28px;
    font-weight:bold;
}

.brand span{
    font-size:11px;
    letter-spacing:4px;
    color:var(--gold-light);
}

.brand h1{
    font-size:30px;
}

.session-area{
    display:flex;
    align-items:center;
    gap:14px;
}

.session-box{
    padding:13px 18px;
    border-radius:999px;
    border:1px solid rgba(201,168,76,.25);
    background:rgba(13,6,0,.65);
    color:var(--cream2);
}

.logout{
    padding:13px 18px;
    border-radius:14px;
    text-decoration:none;
    color:#fca5a5;
    background:rgba(239,68,68,.10);
    border:1px solid rgba(239,68,68,.35);
    font-weight:bold;
}

.main{
    padding:38px;
}

.subtitle{
    color:var(--gold-light);
    letter-spacing:8px;
    font-size:13px;
    margin-bottom:8px;
}

.title{
    font-size:48px;
    margin-bottom:32px;
}

.tables-board{
    display:grid;
    grid-template-columns:repeat(auto-fill,minmax(390px,1fr));
    gap:24px;
}

.table-column{
    border:1px solid rgba(201,168,76,.28);
    border-radius:24px;
    background:linear-gradient(145deg,rgba(38,21,8,.78),rgba(13,6,0,.94));
    box-shadow:0 18px 55px rgba(0,0,0,.35);
    overflow:hidden;
}

.table-header{
    padding:24px;
    border-bottom:1px solid rgba(201,168,76,.16);
    display:flex;
    justify-content:space-between;
    gap:16px;
}

.table-header h2{
    color:var(--gold-light);
    font-size:34px;
}

.status{
    display:inline-block;
    padding:7px 11px;
    border-radius:999px;
    font-size:12px;
    text-transform:uppercase;
    font-weight:bold;
    height:max-content;
}

.status.livre{
    color:#86efac;
    background:rgba(34,197,94,.12);
    border:1px solid rgba(34,197,94,.35);
}

.status.ocupada{
    color:#fca5a5;
    background:rgba(239,68,68,.12);
    border:1px solid rgba(239,68,68,.35);
}

.status.enviado,
.status.processando{
    color:#fbbf24;
    background:rgba(245,158,11,.12);
    border:1px solid rgba(245,158,11,.35);
}

.status.pronto{
    color:#86efac;
    background:rgba(34,197,94,.12);
    border:1px solid rgba(34,197,94,.35);
}

.status.finalizado{
    color:#ddd6fe;
    background:rgba(139,92,246,.12);
    border:1px solid rgba(139,92,246,.35);
}

.status.pagamento{
    color:#fbbf24;
    background:rgba(245,158,11,.16);
    border:1px solid rgba(245,158,11,.45);
}

.table-info{
    padding:22px 24px;
    border-bottom:1px solid rgba(201,168,76,.14);
}

.info-grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:14px;
}

.info-box{
    padding:14px;
    border-radius:16px;
    background:rgba(13,6,0,.45);
    border:1px solid rgba(201,168,76,.12);
}

.info-box span{
    display:block;
    color:rgba(245,234,216,.58);
    font-size:13px;
    margin-bottom:6px;
}

.info-box strong{
    font-size:18px;
}


.service-flow{
    padding:22px 24px;
    border-bottom:1px solid rgba(201,168,76,.14);
}

.service-flow h3{
    color:var(--gold-light);
    font-size:22px;
    margin-bottom:16px;
}

.flow-step{
    padding:16px;
    border-radius:16px;
    background:rgba(13,6,0,.48);
    border:1px solid rgba(201,168,76,.14);
    margin-bottom:12px;
}

.flow-step span{
    display:block;
    color:rgba(245,234,216,.58);
    font-size:13px;
    margin-bottom:8px;
}

.flow-step strong{
    display:block;
    color:#86efac;
    font-size:15px;
    line-height:1.35;
}

.flow-step em{
    display:block;
    color:#dbeafe;
    font-size:14px;
    line-height:1.35;
    font-style:normal;
}

.flow-step form{
    margin-top:8px;
}

.flow-step button{
    width:100%;
    padding:12px 14px;
    border:none;
    border-radius:13px;
    background:linear-gradient(135deg,var(--gold),var(--gold-light));
    color:#140900;
    font-weight:bold;
    font-family:Georgia,"Times New Roman",serif;
    cursor:pointer;
    text-align:center;
    transition:.2s ease;
}

.flow-step button:hover{
    transform:translateY(-1px);
    box-shadow:0 8px 20px rgba(201,168,76,.18);
}

.orders-area{
    padding:22px 24px;
}

.orders-title{
    color:var(--gold-light);
    font-size:22px;
    margin-bottom:16px;
}

.alert{
    margin-bottom:14px;
    padding:12px 14px;
    border-radius:14px;
    background:rgba(239,68,68,.14);
    border:1px solid rgba(239,68,68,.4);
    color:#fca5a5;
    font-weight:bold;
}

.order-card{
    padding:18px;
    border-radius:18px;
    background:rgba(13,6,0,.48);
    border:1px solid rgba(201,168,76,.18);
    margin-bottom:16px;
}

.order-top{
    display:flex;
    justify-content:space-between;
    gap:14px;
    margin-bottom:12px;
}

.order-top h3{
    color:var(--gold-light);
    font-size:22px;
}

.order-meta{
    color:rgba(245,234,216,.58);
    font-size:13px;
    margin-top:4px;
}

.item-row{
    display:flex;
    justify-content:space-between;
    gap:12px;
    padding:8px 0;
    border-bottom:1px solid rgba(201,168,76,.08);
    color:var(--cream2);
}

.customization-badges{display:flex;flex-wrap:wrap;gap:4px;margin-top:5px}
.cbadge{padding:2px 8px;border-radius:999px;font-size:11px;font-weight:bold}
.cbadge.sem{background:rgba(239,68,68,.15);border:1px solid rgba(239,68,68,.35);color:#fca5a5}
.cbadge.com{background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.3);color:#86efac}
.cbadge.extra{background:rgba(245,158,11,.12);border:1px solid rgba(245,158,11,.3);color:#fbbf24}
.cbadge.outro{background:rgba(148,163,184,.1);border:1px solid rgba(148,163,184,.25);color:#cbd5e1}

.total-row{
    margin-top:12px;
    padding:12px;
    border-radius:14px;
    background:rgba(201,168,76,.10);
    border:1px solid rgba(201,168,76,.20);
    display:flex;
    justify-content:space-between;
    color:var(--gold-light);
    font-weight:bold;
    font-size:18px;
}

.btn-limpar-mesa{width:100%;padding:11px;border:1px solid rgba(239,68,68,.35);border-radius:13px;background:rgba(239,68,68,.08);color:#fca5a5;font-weight:bold;cursor:pointer;font-size:13px;font-family:inherit;transition:.2s;margin-top:6px}
.btn-limpar-mesa:hover{background:rgba(239,68,68,.18)}
.action-btn{
    width:100%;
    margin-top:14px;
    padding:13px;
    border:none;
    border-radius:14px;
    background:linear-gradient(135deg,var(--gold),var(--gold-light));
    color:#140900;
    font-weight:bold;
    cursor:pointer;
}

.action-btn:disabled{
    opacity:.55;
    cursor:not-allowed;
}

.status-note{
    margin-top:14px;
    padding:10px 14px;
    border-radius:12px;
    background:rgba(34,197,94,.08);
    border:1px solid rgba(34,197,94,.25);
    color:rgba(245,234,216,.75);
    font-size:13px;
    text-align:center;
}

.empty{
    color:rgba(245,234,216,.58);
    padding:14px 0;
}

@media(max-width:760px){
    .header{
        flex-direction:column;
        align-items:flex-start;
        gap:18px;
        padding:24px 18px;
    }

    .session-area{
        flex-direction:column;
        align-items:flex-start;
        width:100%;
    }

    .session-box,
    .logout{
        width:100%;
        text-align:center;
    }

    .main{
        padding:24px 18px;
    }

    .title{
        font-size:36px;
    }

    .tables-board{
        grid-template-columns:1fr;
    }

    .info-grid{
        grid-template-columns:1fr;
    }
}
</style>
<link rel="stylesheet" href="assets/responsive_global.css">
</head>

<body>

<header class="header">

    <div class="brand">
        <a href="index.php" style="text-decoration:none"><img src="assets/logo.png" alt="SmartTable" style="height:72px;width:auto;object-fit:contain"></a>

        <div>
            <span>RESTAURANT MANAGEMENT</span>
            <h1>SmartTable</h1>
        </div>
    </div>

    <div class="session-area" style="display:flex;align-items:center;gap:12px;">
        <div class="session-box">
            Sessão iniciada como: <strong><?= htmlspecialchars($empregadoMesa) ?></strong>
        </div>

        <a href="logout.php" class="logout">Terminar Sessão</a>
    </div>

</header>

<main class="main">

    <p class="subtitle">PAINEL DO EMPREGADO DE MESA</p>
    <h2 class="title">Mesas e pedidos ativos</h2>

    <section id="live-content" class="tables-board">

        <?php if ($tables && $tables->num_rows > 0): ?>

            <?php while($table = $tables->fetch_assoc()): ?>

                <?php
                    $tableNumber = intval($table["number"]);
                    $status = strtolower($table["status"] ?? "livre");
                    $occupiedSeats = intval($table["occupied_seats"] ?? 0);
                    $capacity = intval($table["capacity"] ?? 0);
                    $typeTable = $table["type_table"] ?? ($table["table_type"] ?? "Padrão");

                    $ordersStmt = $conn->prepare("
                        SELECT *
                        FROM orders
                        WHERE table_number = ?
                        AND (status NOT IN ('pago','cancelado','finalizado') AND status != '' AND status IS NOT NULL)
                        ORDER BY created_at DESC
                    ");
                    $ordersStmt->bind_param("s", $tableNumber);
                    $ordersStmt->execute();
                    $ordersResult = $ordersStmt->get_result();

                    $orderIds = [];
                    $totalItemsMesa = 0;

                    if ($ordersResult && $ordersResult->num_rows > 0) {
                        while ($o = $ordersResult->fetch_assoc()) {
                            $orderIds[] = intval($o["id"]);
                        }

                        if (!empty($orderIds)) {
                            $ids = implode(",", $orderIds);

                            $sumQuery = $conn->query("
                                SELECT SUM(quantity) AS total
                                FROM order_items
                                WHERE order_id IN ($ids)
                            ");

                            if ($sumQuery) {
                                $totalItemsMesa = intval($sumQuery->fetch_assoc()["total"] ?? 0);
                            }
                        }

                        $ordersStmt->execute();
                        $ordersResult = $ordersStmt->get_result();
                    }

                    $alertaPedidos = (
                        $occupiedSeats > 0 &&
                        $totalItemsMesa > $occupiedSeats
                    );

                    $minutesAfterMain = null;

                    if (!empty($table["main_delivered_at"])) {
                        $minutesAfterMain = floor((time() - strtotime($table["main_delivered_at"])) / 60);
                    }
                ?>

                <article class="table-column">

                    <div class="table-header">
                        <h2>Mesa <?= htmlspecialchars($tableNumber) ?></h2>

                        <span class="status <?= htmlspecialchars($status) ?>">
                            <?= htmlspecialchars($status) ?>
                        </span>
                    </div>

                    <div class="table-info">

                        <div class="info-grid">

                            <div class="info-box">
                                <span>Tipo de mesa</span>
                                <strong><?= htmlspecialchars($typeTable) ?></strong>
                            </div>

                            <div class="info-box">
                                <span>Pessoas</span>
                                <strong><?= $occupiedSeats ?>/<?= $capacity ?></strong>
                            </div>

                            <div class="info-box">
                                <span>Chegada</span>
                                <strong>
                                    <?= !empty($table["arrival_time"])
                                        ? date("H:i", strtotime($table["arrival_time"]))
                                        : "--:--" ?>
                                </strong>
                            </div>

                            <div class="info-box">
                                <span>Tempo sentado</span>
                                <strong><?= tempoSentado($table["arrival_time"] ?? null) ?></strong>
                            </div>

                        </div>

                    </div>

                    <div class="service-flow">
                        <h3>Fluxo do Serviço</h3>

                        <div class="flow-step">
                            <span>Entradas e bebidas</span>

                            <?php if (!empty($table["entries_drinks_delivered_at"])): ?>
                                <strong>Entregue às <?= date("H:i", strtotime($table["entries_drinks_delivered_at"])) ?></strong>
                            <?php else: ?>
                                <form method="POST">
                                    <input type="hidden" name="table_number" value="<?= htmlspecialchars($tableNumber) ?>">
                                    <button type="submit" name="deliver_entries_drinks">Marcar entradas/bebidas entregues</button>
                                </form>
                            <?php endif; ?>
                        </div>

                        <div class="flow-step">
                            <span>Prato principal</span>

                            <?php if (!empty($table["main_unlocked"])): ?>
                                <strong>Prato principal desbloqueado</strong>
                            <?php elseif (!empty($table["entries_drinks_delivered_at"])): ?>
                                <form method="POST">
                                    <input type="hidden" name="table_number" value="<?= htmlspecialchars($tableNumber) ?>">
                                    <button type="submit" name="unlock_main">Desbloquear prato principal</button>
                                </form>
                            <?php else: ?>
                                <em>Disponível depois de entregar entradas/bebidas.</em>
                            <?php endif; ?>
                        </div>

                        <div class="flow-step">
                            <span>Prato principal entregue</span>

                            <?php if (!empty($table["main_delivered_at"])): ?>
                                <strong>Entregue às <?= date("H:i", strtotime($table["main_delivered_at"])) ?></strong>
                            <?php elseif (!empty($table["main_unlocked"])): ?>
                                <form method="POST">
                                    <input type="hidden" name="table_number" value="<?= htmlspecialchars($tableNumber) ?>">
                                    <button type="submit" name="deliver_main">Marcar prato entregue</button>
                                </form>
                            <?php else: ?>
                                <em>Aguardando prato principal.</em>
                            <?php endif; ?>
                        </div>

                        <div class="flow-step">
                            <span>Sobremesa</span>

                            <?php if (!empty($table["dessert_unlocked"])): ?>
                                <strong>Disponível desde <?= !empty($table["dessert_unlocked_at"]) ? date("H:i", strtotime($table["dessert_unlocked_at"])) : "agora" ?></strong>
                            <?php else: ?>
                                <em>Disponível depois do prato principal ser entregue.</em>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="orders-area">

                        <h3 class="orders-title">Pedido desta mesa</h3>

                        <?php if ($alertaPedidos): ?>
                            <div class="alert">
                                ⚠ Esta mesa tem <?= $occupiedSeats ?> pessoa(s), mas já pediu <?= $totalItemsMesa ?> item(ns).
                            </div>
                        <?php endif; ?>

                        <?php if ($ordersResult && $ordersResult->num_rows > 0): ?>

                            <?php while($order = $ordersResult->fetch_assoc()): ?>

                                <?php
                                    $itemsStmt = $conn->prepare("
                                        SELECT *
                                        FROM order_items
                                        WHERE order_id = ?
                                    ");
                                    $itemsStmt->bind_param("i", $order["id"]);
                                    $itemsStmt->execute();
                                    $items = $itemsStmt->get_result();
                                ?>

                                <div class="order-card">

                                    <div class="order-top">

                                        <div>
                                            <h3>Pedido #<?= htmlspecialchars($order["id"]) ?></h3>

                                            <div class="order-meta">
                                                <?= htmlspecialchars($order["created_at"]) ?>
                                            </div>
                                        </div>

                                        <span class="status <?= htmlspecialchars($order["status"]) ?>">
                                            <?= htmlspecialchars($order["status"]) ?>
                                        </span>

                                    </div>

                                    <?php if ($items && $items->num_rows > 0): ?>

                                        <?php while($item = $items->fetch_assoc()): ?>
                                            <div class="item-row">
                                                <span>
                                                    <strong><?= htmlspecialchars($item["quantity"]) ?>x</strong>
                                                    <?= htmlspecialchars($item["name"]) ?>
                                                </span>

                                                <span>
                                                    <?= number_format((float)$item["subtotal"], 2, ",", ".") ?> €
                                                </span>
                                            </div>
                                        <?php endwhile; ?>

                                    <?php else: ?>

                                        <p class="empty">Sem itens neste pedido.</p>

                                    <?php endif; ?>

                                    <div class="total-row">
                                        <span>Total</span>
                                        <span><?= number_format((float)$order["total"], 2, ",", ".") ?> €</span>
                                    </div>

                                    <?php if ($order["status"] === "pronto"): ?>
                                        <div class="status-note">Pronto — será marcado como entregue quando o prato principal for confirmado</div>
                                    <?php else: ?>
                                        <button class="action-btn" disabled>
                                            Aguardar cozinha
                                        </button>
                                    <?php endif; ?>

                                </div>

                            <?php endwhile; ?>

                        <?php else: ?>

                            <p class="empty">
                                Esta mesa ainda não tem pedidos ativos.
                            </p>

                        <?php endif; ?>

                        <!-- LIMPAR PEDIDOS -->
                        <form method="POST" onsubmit="return confirm('Limpar todos os pedidos da Mesa <?= $tableNumber ?>?')">
                            <input type="hidden" name="table_number" value="<?= htmlspecialchars($tableNumber) ?>">
                            <button type="submit" name="limpar_pedidos_mesa" class="btn-limpar-mesa">
                                🗑️ Limpar pedidos desta mesa
                            </button>
                        </form>

                    </div>

                </article>

            <?php endwhile; ?>

        <?php else: ?>

            <p class="empty">Nenhuma mesa encontrada.</p>

        <?php endif; ?>

    </section>

</main>

<script src="assets/auto_refresh.js"></script>

<script src="assets/keep_session.js"></script>
<script src="assets/notifications.js"></script>
</body>
</html>
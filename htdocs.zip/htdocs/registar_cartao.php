<?php
require_once "session_config.php";
require_once "config/db.php";
require_once "session_handler.php";
session_start();
require_once 'db.php';

$mensagem = '';
$tipo = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uid  = strtoupper(trim($_POST['rfid_uid'] ?? ''));
    $nome = trim($_POST['nome'] ?? '');
    $role = $_POST['role'] ?? '';

    if ($uid && $nome && in_array($role, ['admin', 'empregado_mesa'])) {
        try {
            $stmt = $pdo->prepare("INSERT INTO rfid_users (uid, nome, role) VALUES (?, ?, ?)");
            $stmt->execute([$uid, $nome, $role]);
            $mensagem = "Cartão registado! — <strong>$nome</strong> ($role) · UID: <code>$uid</code>";
            $tipo = 'success';
        } catch (PDOException $e) {
            $mensagem = "Erro: este UID já existe na base de dados.";
            $tipo = 'error';
        }
    } else {
        $mensagem = "Preenche todos os campos e passa o cartão.";
        $tipo = 'error';
    }
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<link rel="icon" href="favicon.ico" sizes="any">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="apple-touch-icon" href="assets/logo.png">
<link rel="manifest" href="site.webmanifest">
<meta name="theme-color" content="#0d0600">
    <meta charset="UTF-8">
    <title>Registar Cartão RFID</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: system-ui, sans-serif; background: #f5f5f4; color: #1c1c1a; min-height: 100vh; display: flex; align-items: center; justify-content: center; }
        .page { width: 100%; max-width: 480px; padding: 1.5rem; }
        h1 { font-size: 20px; font-weight: 500; margin-bottom: 4px; }
        .subtitle { font-size: 14px; color: #6b6b67; margin-bottom: 1.5rem; }
        .card { background: #fff; border: 1px solid #e2e2de; border-radius: 12px; padding: 1.5rem; }
        .field { margin-bottom: 1.25rem; }
        label { display: block; font-size: 13px; color: #6b6b67; margin-bottom: 6px; }
        input[type=text], select { width: 100%; padding: 8px 12px; border: 1px solid #d4d4d0; border-radius: 8px; font-size: 14px; outline: none; background: #fff; color: #1c1c1a; }
        input[type=text]:focus { border-color: #185FA5; box-shadow: 0 0 0 3px rgba(24,95,165,0.12); }
        .role-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
        .role-btn { border: 1px solid #d4d4d0; border-radius: 8px; padding: 0.75rem; cursor: pointer; background: #fff; text-align: left; transition: all 0.15s; }
        .role-btn:hover { background: #f5f5f4; }
        .role-btn input[type=radio] { display: none; }
        .role-btn.active-admin { border: 2px solid #185FA5; background: #E6F1FB; }
        .role-btn.active-empregado-mesa { border: 2px solid #0F6E56; background: #E1F5EE; }
        .role-icon { font-size: 22px; display: block; margin-bottom: 4px; }
        .role-label { font-size: 13px; font-weight: 500; display: block; }
        .role-desc { font-size: 12px; color: #6b6b67; }
        hr { border: none; border-top: 1px solid #e2e2de; margin: 1.25rem 0; }
        .rfid-area { border: 1.5px dashed #a3a39f; border-radius: 8px; padding: 1.25rem; text-align: center; cursor: pointer; transition: all 0.15s; }
        .rfid-area:focus-within { border-color: #185FA5; background: #f0f7ff; }
        .rfid-area.has-uid { border-color: #0F6E56; border-style: solid; background: #f0faf5; }
        .rfid-area i { font-size: 28px; display: block; margin-bottom: 8px; color: #a3a39f; }
        .rfid-area:focus-within i, .rfid-area.has-uid i { color: #0F6E56; }
        .rfid-area p { font-size: 14px; color: #6b6b67; }
        #uid-display { font-family: monospace; font-size: 15px; color: #185FA5; font-weight: 500; margin-top: 6px; }
        #rfid-hidden { opacity: 0; position: absolute; width: 1px; height: 1px; }
        .hint { font-size: 12px; color: #a3a39f; margin-top: 6px; }
        .btn { width: 100%; padding: 0.7rem; border-radius: 8px; border: none; font-size: 14px; font-weight: 500; cursor: pointer; background: #185FA5; color: #fff; transition: background 0.15s; margin-top: 4px; }
        .btn:hover { background: #0C447C; }
        .toast { padding: 0.75rem 1rem; border-radius: 8px; font-size: 13px; margin-top: 1rem; }
        .toast.success { background: #E1F5EE; color: #085041; border: 1px solid #5DCAA5; }
        .toast.error { background: #FCEBEB; color: #791F1F; border: 1px solid #F09595; }
        code { background: rgba(0,0,0,0.08); padding: 1px 5px; border-radius: 4px; font-size: 12px; }
    </style>
<link rel="stylesheet" href="assets/responsive_global.css">
</head>
<body>
<div class="page">
    <h1><i class="ti ti-credit-card" style="vertical-align:-2px; margin-right:8px;"></i>Registar cartão RFID</h1>
    <p class="subtitle">Preenche os dados e passa o cartão no leitor para registar.</p>

    <div class="card">
        <form method="POST" id="main-form">

            <div class="field">
                <label for="nome">Nome do utilizador</label>
                <input type="text" name="nome" id="nome" placeholder="Ex: João Silva"
                       value="<?= htmlspecialchars($_POST['nome'] ?? '') ?>" required>
            </div>

            <div class="field">
                <label>Papel / Função</label>
                <div class="role-grid">
                    <div class="role-btn <?= ($_POST['role'] ?? 'admin') === 'admin' ? 'active-admin' : '' ?>"
                         id="card-admin" onclick="selectRole('admin')">
                        <i class="ti ti-shield-lock role-icon"></i>
                        <span class="role-label" style="color:<?= ($_POST['role'] ?? 'admin') === 'admin' ? '#185FA5' : '' ?>">Admin</span>
                        <span class="role-desc">Acesso total ao sistema</span>
                        <input type="radio" name="role" value="admin" id="role-admin"
                               <?= ($_POST['role'] ?? 'admin') === 'admin' ? 'checked' : '' ?>>
                    </div>
                    <div class="role-btn <?= ($_POST['role'] ?? '') === 'empregado_mesa' ? 'active-empregado-mesa' : '' ?>"
                         id="card-empregado-mesa" onclick="selectRole('empregado_mesa')">
                        <i class="ti ti-tools-kitchen-2 role-icon"></i>
                        <span class="role-label" style="color:<?= ($_POST['role'] ?? '') === 'empregado_mesa' ? '#0F6E56' : '' ?>">Empregado de Mesa</span>
                        <span class="role-desc">Gestão de mesas e pedidos</span>
                        <input type="radio" name="role" value="empregado_mesa" id="role-empregado-mesa"
                               <?= ($_POST['role'] ?? '') === 'empregado_mesa' ? 'checked' : '' ?>>
                    </div>
                </div>
            </div>

            <hr>

            <div class="field">
                <label>Cartão RFID</label>
                <div class="rfid-area <?= !empty($_POST['rfid_uid']) ? 'has-uid' : '' ?>" id="rfid-area" onclick="document.getElementById('rfid-hidden').focus()">
                    <i class="ti ti-wifi" id="rfid-icon"></i>
                    <p id="rfid-status">
                        <?= !empty($_POST['rfid_uid'])
                            ? 'Cartão lido com sucesso!'
                            : 'Clica aqui e passa o cartão no leitor' ?>
                    </p>
                    <p id="uid-display">
                        <?= !empty($_POST['rfid_uid']) ? 'UID: ' . htmlspecialchars($_POST['rfid_uid']) : '' ?>
                    </p>
                    <input type="text" name="rfid_uid" id="rfid-hidden"
                           value="<?= htmlspecialchars($_POST['rfid_uid'] ?? '') ?>" autocomplete="off">
                </div>
                <p class="hint"><i class="ti ti-info-circle" style="vertical-align:-1px;"></i> O leitor USB comporta-se como teclado — mantém o foco aqui.</p>
            </div>

            <button type="button" class="btn" onclick="submeter()">
                <i class="ti ti-plus" style="margin-right:6px;"></i>Registar cartão
            </button>
        </form>

        <?php if ($mensagem): ?>
            <div class="toast <?= $tipo ?>">
                <i class="ti ti-<?= $tipo === 'success' ? 'circle-check' : 'alert-circle' ?>" style="margin-right:6px;"></i>
                <?= $mensagem ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
    function selectRole(role) {
        document.getElementById('role-admin').checked = role === 'admin';
        document.getElementById('role-empregado-mesa').checked = role === 'empregado_mesa';
        document.getElementById('card-admin').className = role === 'admin' ? 'role-btn active-admin' : 'role-btn';
        document.getElementById('card-empregado-mesa').className = role === 'empregado_mesa' ? 'role-btn active-empregado-mesa' : 'role-btn';
        document.querySelector('#card-admin .role-label').style.color = role === 'admin' ? '#185FA5' : '';
        document.querySelector('#card-empregado-mesa .role-label').style.color = role === 'empregado_mesa' ? '#0F6E56' : '';
    }

    const rfidInput = document.getElementById('rfid-hidden');
    let rfidTimer;

    rfidInput.addEventListener('focus', () => {
        document.getElementById('rfid-status').textContent = 'À espera do cartão...';
    });

    rfidInput.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && this.value.trim().length > 2) {
            e.preventDefault();
            capturarUID(this.value.trim());
        }
    });

    rfidInput.addEventListener('input', function() {
        clearTimeout(rfidTimer);
        if (this.value.length > 2) {
            rfidTimer = setTimeout(() => capturarUID(this.value.trim()), 200);
        }
    });

    function capturarUID(uid) {
        const upper = uid.toUpperCase();
        rfidInput.value = upper;
        document.getElementById('rfid-area').classList.add('has-uid');
        document.getElementById('rfid-status').textContent = 'Cartão lido com sucesso!';
        document.getElementById('uid-display').textContent = 'UID: ' + upper;
        document.getElementById('rfid-icon').className = 'ti ti-circle-check';
        document.getElementById('rfid-icon').style.color = '#0F6E56';
    }

    function submeter() {
        const nome = document.getElementById('nome').value.trim();
        const uid = rfidInput.value.trim();
        if (!nome || !uid) {
            alert('Preenche o nome e passa o cartão primeiro.');
            return;
        }
        document.getElementById('main-form').submit();
    }

    // Redireciona qualquer tecla para o campo RFID (exceto se estiver no campo nome)
    document.addEventListener('keydown', function(e) {
        if (document.activeElement !== document.getElementById('nome')) {
            rfidInput.focus();
        }
    });
</script>
</body>
</html>
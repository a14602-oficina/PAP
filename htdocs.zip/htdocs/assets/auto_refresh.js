/**
 * SmartTable — Auto Refresh via AJAX
 * Atualiza apenas o conteúdo dinâmico da página sem recarregar,
 * evitando redirects para o login por reload completo.
 */
(function () {
  const REFRESH_SECONDS = 6;

  /* Só força o redirect para login depois de falhas CONSECUTIVAS,
     para não expulsar o utilizador por causa de um único pedido
     falhado (rede instável, pico de carga no servidor, etc.). */
  let consecutiveAuthFailures = 0;
  const MAX_FAILURES_BEFORE_REDIRECT = 2;

  /* Não faz nada se o utilizador estiver a preencher um formulário */
  let formSubmitting = false;
  document.addEventListener("submit", function () {
    formSubmitting = true;
    /* Após 3 segundos volta a permitir refresh (POST já foi processado) */
    setTimeout(function () { formSubmitting = false; }, 3000);
  });

  function userIsTyping() {
    const el = document.activeElement;
    if (!el) return false;
    return (
      el.tagName === "INPUT" ||
      el.tagName === "TEXTAREA" ||
      el.tagName === "SELECT"
    );
  }

  /* Não atualiza se houver um modal/overlay aberto — evita fechar
     uma ação a meio (ex: a escolher o número de pessoas de uma mesa) */
  function hasOpenModal() {
    const candidates = document.querySelectorAll(
      ".modal-overlay.open, .modal-overlay[style*='flex'], dialog[open]"
    );
    return candidates.length > 0;
  }

  /* 
   * Fetch silencioso: vai buscar a mesma página,
   * extrai o innerHTML do contentor de dados dinâmicos
   * e substitui apenas esse bloco — sem reload completo.
   *
   * Cada dashboard deve ter um elemento com id="live-content".
   * Se não existir, cai no reload clássico como fallback.
   */
  function silentRefresh() {
    if (formSubmitting) return;
    if (userIsTyping()) return;
    if (hasOpenModal()) return;

    const liveZone = document.getElementById("live-content");

    /* Fallback: se não houver zona marcada, faz reload normal */
    if (!liveZone) {
      window.location.reload();
      return;
    }

    /* Adicionar parâmetro para sinalizar pedido AJAX e evitar cache */
    const url = window.location.pathname + window.location.search +
      (window.location.search ? "&" : "?") + "_ajax=1&_t=" + Date.now();

    fetch(url, {
      method: "GET",
      credentials: "same-origin",   /* envia o cookie de sessão */
      headers: { "X-Requested-With": "XMLHttpRequest" }
    })
      .then(function (res) {
        /* Se a sessão expirou o servidor devolve redirect (302/301)
           O fetch segue o redirect mas a URL final muda para login.php.
           Só forçamos o reload depois de algumas falhas seguidas, para
           não expulsar o utilizador por um único pedido com problemas. */
        if (res.redirected && res.url.indexOf("login") !== -1) {
          consecutiveAuthFailures++;
          if (consecutiveAuthFailures >= MAX_FAILURES_BEFORE_REDIRECT) {
            window.location.href = res.url;
          }
          return null;
        }
        /* Código de erro HTTP — não conta como falha de autenticação */
        if (!res.ok) return null;

        /* Pedido bem-sucedido: repõe o contador de falhas */
        consecutiveAuthFailures = 0;
        return res.text();
      })
      .then(function (html) {
        if (!html) return;

        /* Parsear o HTML devolvido e extrair #live-content */
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, "text/html");
        const newZone = doc.getElementById("live-content");

        if (!newZone) return;

        /* Substituir apenas o conteúdo dinâmico */
        liveZone.innerHTML = newZone.innerHTML;
      })
      .catch(function () {
        /* Em caso de erro de rede, não faz nada — tenta no próximo ciclo */
      });
  }

  setInterval(silentRefresh, REFRESH_SECONDS * 1000);
})();
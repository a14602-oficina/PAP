(function () {

    async function keepAlive() {

        try {

            const response = await fetch("session_ping.php", {
                method: "GET",
                cache: "no-store",
                credentials: "same-origin"
            });

            if (response.status === 401) {
                window.location.href = "login.php?expired=1";
            }

        } catch (e) {
            console.log("Ping error");
        }
    }

    keepAlive();

    setInterval(keepAlive, 120000);

})();
/**
 * SmartTable — Sistema de Notificações
 * - Badges com pontos vermelhos na sidebar
 * - Toast de notificação visual
 * - Som de notificação
 * - Polling a cada 8 segundos
 */
(function () {
  const POLL_MS  = 8000;
  const PING_URL = 'notifications.php';

  /* Estado anterior para detetar mudanças */
  let _prev = { pagamentos: 0, gerente: 0, cozinha: 0, pronto: 0 };
  let _audioCtx = null;
  let _initialized = false;

  /* ── Som de notificação (Web Audio API — sem ficheiro externo) ── */
  function playNotif() {
    try {
      if (!_audioCtx) _audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      const ctx = _audioCtx;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(440, ctx.currentTime + 0.15);
      gain.gain.setValueAtTime(0.25, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.4);
    } catch (e) {}
  }

  /* ── Toast visual ── */
  function showToast(msg, icon) {
    let wrap = document.getElementById('st-toast-wrap');
    if (!wrap) {
      wrap = document.createElement('div');
      wrap.id = 'st-toast-wrap';
      wrap.style.cssText = 'position:fixed;top:20px;right:20px;z-index:99999;display:flex;flex-direction:column;gap:10px;pointer-events:none';
      document.body.appendChild(wrap);
    }
    const t = document.createElement('div');
    t.style.cssText = [
      'background:linear-gradient(135deg,rgba(26,14,4,.97),rgba(13,6,0,.99))',
      'border:1px solid rgba(201,168,76,.35)',
      'color:#f5ead8',
      'padding:14px 18px',
      'border-radius:14px',
      'font-family:Georgia,serif',
      'font-size:14px',
      'box-shadow:0 10px 40px rgba(0,0,0,.5)',
      'display:flex',
      'align-items:center',
      'gap:10px',
      'opacity:0',
      'transform:translateX(30px)',
      'transition:.3s ease',
      'pointer-events:auto',
      'max-width:300px',
    ].join(';');
    t.innerHTML = '<span style="font-size:20px">' + icon + '</span><span>' + msg + '</span>';
    wrap.appendChild(t);
    requestAnimationFrame(function () {
      t.style.opacity = '1';
      t.style.transform = 'translateX(0)';
    });
    setTimeout(function () {
      t.style.opacity = '0';
      t.style.transform = 'translateX(30px)';
      setTimeout(function () { t.remove(); }, 350);
    }, 4000);
  }

  /* ── Badge num elemento da sidebar ── */
  function setBadge(selector, count) {
    const link = document.querySelector(selector);
    if (!link) return;

    link.style.position = 'relative';
    let badge = link.querySelector('.st-badge');

    if (count > 0) {
      if (!badge) {
        badge = document.createElement('span');
        badge.className = 'st-badge';
        badge.style.cssText = [
          'position:absolute',
          'top:6px',
          'right:8px',
          'min-width:20px',
          'height:20px',
          'border-radius:10px',
          'background:#ef4444',
          'color:#fff',
          'font-size:11px',
          'font-weight:bold',
          'display:flex',
          'align-items:center',
          'justify-content:center',
          'padding:0 5px',
          'box-shadow:0 0 0 2px rgba(13,6,0,.8)',
          'animation:st-pulse 2s infinite',
        ].join(';');
        link.appendChild(badge);
      }
      badge.textContent = count > 99 ? '99+' : count;
    } else {
      if (badge) badge.remove();
    }
  }

  /* ── Atualizar favicon com ponto vermelho se houver notifs ── */
  function updateTitle(total) {
    const base = document.title.replace(/^\(\d+\)\s*/, '');
    document.title = total > 0 ? '(' + total + ') ' + base : base;
  }

  /* ── Mapeamento sidebar link → chave de dados ── */
  const BADGE_MAP = {
    'a[href="pagamento_dashboard.php"]': 'pagamentos',
    'a[href="gerente_dashboard.php"]':   'gerente',
  };

  /* ── Poll principal ── */
  function poll() {
    fetch(PING_URL, { credentials: 'same-origin', cache: 'no-store' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (data) {
        if (!data || !data.ok) return;

        /* Badges na sidebar */
        Object.entries(BADGE_MAP).forEach(function ([sel, key]) {
          setBadge(sel, data[key] || 0);
        });

        /* Badge total no título */
        updateTitle(data.total);

        /* Notificações de novos eventos (só depois da primeira poll) */
        if (_initialized) {
          if (data.pagamentos > _prev.pagamentos) {
            playNotif();
            showToast('Nova conta para pagamento!', '💳');
          }
          if (data.gerente > _prev.gerente) {
            playNotif();
            showToast('Chamada ao gerente pendente!', '🔔');
          }
          if (data.pronto > _prev.pronto) {
            playNotif();
            showToast('Pedido pronto para entregar!', '🍽️');
          }
          if (data.cozinha > _prev.cozinha) {
            showToast('Novo pedido na cozinha!', '👨‍🍳');
          }
        }

        _prev = {
          pagamentos: data.pagamentos,
          gerente:    data.gerente,
          cozinha:    data.cozinha,
          pronto:     data.pronto,
        };
        _initialized = true;
      })
      .catch(function () {});
  }

  /* Ativar AudioContext no primeiro clique do utilizador (política dos browsers) */
  document.addEventListener('click', function () {
    if (!_audioCtx) {
      try { _audioCtx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) {}
    }
  }, { once: true });

  /* Injetar animação CSS do pulse */
  const style = document.createElement('style');
  style.textContent = '@keyframes st-pulse{0%,100%{box-shadow:0 0 0 2px rgba(13,6,0,.8),0 0 0 4px rgba(239,68,68,0)}50%{box-shadow:0 0 0 2px rgba(13,6,0,.8),0 0 0 6px rgba(239,68,68,.3)}}';
  document.head.appendChild(style);

  /* Arrancar */
  document.addEventListener('DOMContentLoaded', function () {
    poll();
    setInterval(poll, POLL_MS);
  });
})();
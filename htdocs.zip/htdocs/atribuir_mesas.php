<?php
require_once "error_config.php";

require_once "auth_check.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "admin") {
    header("Location: login.php");
    exit;
}

$adminName = $_SESSION["name"] ?? "Administrador";
$msg = "";
$msgType = "success";

$conn->query("
    CREATE TABLE IF NOT EXISTS waiter_tables (
        id INT AUTO_INCREMENT PRIMARY KEY,
        waiter_id INT NOT NULL,
        table_number INT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_assignment (waiter_id, table_number)
    )
");

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["save_assignment"])) {
    $waiterId = intval($_POST["waiter_id"] ?? 0);
    $tables = $_POST["tables"] ?? [];

    if ($waiterId > 0) {

        $conflictFound = false;
        $conflictMsg = "";

        foreach ($tables as $tableNumber) {
            $tableNumber = intval($tableNumber);

            $check = $conn->prepare("
                SELECT wt.waiter_id, u.name, u.username
                FROM waiter_tables wt
                INNER JOIN users u ON u.id = wt.waiter_id
                WHERE wt.table_number = ?
                AND wt.waiter_id != ?
                LIMIT 1
            ");
            $check->bind_param("ii", $tableNumber, $waiterId);
            $check->execute();

            $conflict = $check->get_result()->fetch_assoc();

            if ($conflict) {
                $waiterName = $conflict["name"] ?: $conflict["username"];

                $conflictFound = true;
                $conflictMsg = "A mesa " . $tableNumber . " já está atribuída ao empregado de mesa " . $waiterName . ". Não pode ser atribuída a outro empregado de mesa.";
                break;
            }
        }

      		 if ($conflictFound) {
	
   			 	$msg = $conflictMsg;
    			$msgType = "error";

			} else {
            $delete = $conn->prepare("DELETE FROM waiter_tables WHERE waiter_id = ?");
            $delete->bind_param("i", $waiterId);
            $delete->execute();

            foreach ($tables as $tableNumber) {
                $tableNumber = intval($tableNumber);

                $stmt = $conn->prepare("
                    INSERT IGNORE INTO waiter_tables (waiter_id, table_number)
                    VALUES (?, ?)
                ");
                $stmt->bind_param("ii", $waiterId, $tableNumber);
                $stmt->execute();
            }

            $msg = "Mesas atribuídas com sucesso.";
        }
    }
}

$waiters = $conn->query("
    SELECT id, name, username
    FROM users
    WHERE role = 'empregado_mesa'
    ORDER BY name ASC
");

$tables = $conn->query("
    SELECT number, capacity, status
    FROM `tables`
    ORDER BY number ASC
");

$assignments = [];
$res = $conn->query("SELECT waiter_id, table_number FROM waiter_tables");

if ($res) {
    while ($row = $res->fetch_assoc()) {
        $assignments[$row["waiter_id"]][] = $row["table_number"];
    }
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>SmartTable - Atribuir Mesas</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="favicon.ico" sizes="any">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="apple-touch-icon" href="assets/logo.png">
<link rel="manifest" href="site.webmanifest">
<meta name="theme-color" content="#0d0600">

<?php include_once __DIR__ . "/theme.php"; ?>
<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Georgia,"Times New Roman",serif;
}

body{
    min-height:100vh;
    background:
        linear-gradient(90deg,rgba(201,168,76,.04) 1px,transparent 1px),
        linear-gradient(rgba(201,168,76,.03) 1px,transparent 1px),
        radial-gradient(circle at top left,rgba(201,168,76,.18),transparent 35%),
        linear-gradient(135deg,var(--dark),#080300 70%);
    background-size:80px 80px,80px 80px,cover,cover;
    color:var(--cream);
}

.admin-layout{display:block;margin:0;padding:0}

.brand h2{
    font-size:22px;
}

.brand span{
    font-size:11px;
    color:rgba(245,234,216,.55);
    letter-spacing:3px;
}

.content{margin-left:285px!important;padding:42px;overflow-x:auto}

.topbar{
    display:flex;
    justify-content:space-between;
    align-items:flex-start;
    gap:20px;
    margin-bottom:34px;
}

.subtitle{
    color:var(--gold-light);
    letter-spacing:8px;
    font-size:13px;
    margin-bottom:8px;
}

.topbar h1{
  font-size:44px;
}

.session{
    padding:14px 18px;
    border-radius:999px;
    border:1px solid rgba(201,168,76,.25);
    background:rgba(13,6,0,.65);
    color:var(--cream2);
    white-space:nowrap;
}

.msg{
    padding:15px 18px;
    border-radius:14px;
    margin-bottom:24px;
    font-weight:bold;
}

.msg.success{
    background:rgba(34,197,94,.12);
    border:1px solid rgba(34,197,94,.45);
    color:#86efac;
}

.msg.error{
    background:rgba(239,68,68,.14);
    border:1px solid rgba(239,68,68,.55);
    color:#fca5a5;
}

.grid{
    display:grid;
    grid-template-columns:repeat(auto-fill,minmax(360px,1fr));
    gap:24px;
}

.card{
    border:1px solid rgba(201,168,76,.28);
    border-radius:24px;
    background:linear-gradient(145deg,rgba(38,21,8,.82),rgba(13,6,0,.96));
    padding:24px;
    box-shadow:0 18px 55px rgba(0,0,0,.35);
}

.card h2{
    color:var(--gold-light);
    font-size:28px;
    margin-bottom:8px;
}

.card p{
    color:rgba(245,234,216,.65);
    margin-bottom:20px;
}

.tables-list{
    display:grid;
    grid-template-columns:repeat(2,1fr);
    gap:12px;
    margin-bottom:20px;
}

.table-check{
    padding:12px;
    border-radius:14px;
    border:1px solid rgba(201,168,76,.15);
    background:rgba(13,6,0,.45);
    display:flex;
    gap:10px;
    align-items:center;
    cursor:pointer;
}

.table-check input{
    transform:scale(1.2);
}

button{
    width:100%;
    padding:14px;
    border:none;
    border-radius:14px;
    background:linear-gradient(135deg,var(--gold),var(--gold-light));
    color:#140900;
    font-weight:bold;
    cursor:pointer;
}

@media(max-width:850px){
    .admin-layout{display:block;margin:0;padding:0}

    

    .content{
        padding:28px 18px;;margin-left:285px!important}

    .topbar{
        flex-direction:column;
    }

    .topbar h1{
        font-size:38px;
    }

    .tables-list{
        grid-template-columns:1fr;
    }
}
</style>
<style id="sidebar-fixed">
/* ── TOPBAR UNIFICADO ── */
.topbar,.page-topbar{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:32px;flex-wrap:wrap}
.topbar-left,.topbar-right{display:flex;align-items:center;gap:12px}
.page-subtitle,.subtitle{color:var(--gold-light,#e8c97a);letter-spacing:7px;font-size:12px;margin-bottom:6px;display:block}
.session-box,.session,.user-box{
  padding:11px 20px;
  border-radius:999px;
  background:rgba(13,6,0,.65);
  border:1px solid rgba(var(--gold-rgb,201,168,76),.25);
  color:var(--cream2,#ede0c4);
  font-size:14px;
  white-space:nowrap;
  font-family:var(--font,Georgia),serif;
}

/* ── SIDEBAR FIXA ── */
.admin-layout{display:block;margin:0;padding:0}
.sidebar{
  width:285px;min-width:285px;padding:26px 24px;
  background:var(--sidebar-gradient,linear-gradient(180deg,rgba(26,14,4,.98),rgba(13,6,0,.96)));
  border-right:1px solid rgba(var(--gold-rgb,201,168,76),.22);
  position:fixed!important;top:0;left:0;
  height:100vh;overflow-y:auto;overflow-x:hidden;
  z-index:100;display:flex;flex-direction:column;
}
.sidebar::-webkit-scrollbar{width:4px}
.sidebar::-webkit-scrollbar-thumb{background:rgba(201,168,76,.25);border-radius:2px}
.content{margin-left:285px!important;padding:34px 46px;overflow-x:auto;min-height:100vh}
.sidebar .sidebar-logo{display:flex!important;flex-direction:row!important;align-items:center!important;gap:14px!important;margin-bottom:42px!important;flex-shrink:0}
.sidebar .logo-box{width:56px!important;height:56px!important;border-radius:var(--radius,18px)!important;background:var(--grad-primary,linear-gradient(135deg,#c9a84c,#e8c97a))!important;color:#140900!important;display:flex!important;align-items:center!important;justify-content:center!important;font-size:28px!important;font-weight:bold!important;flex-shrink:0!important}
.sidebar .sidebar-logo h2{color:var(--gold-light,#e8c97a)!important;font-size:24px!important;line-height:1!important;margin:0!important}
.sidebar .sidebar-logo span{font-size:12px!important;color:rgba(245,234,216,.55)!important;letter-spacing:2px!important;display:block!important}
.menu-title{font-size:12px;color:rgba(245,234,216,.45);letter-spacing:3px;margin-bottom:16px;flex-shrink:0}
.side-menu{display:flex;flex-direction:column;gap:10px;flex:1}
.side-menu a{padding:14px 16px;border-radius:var(--radius,16px);color:var(--cream2,#ede0c4);text-decoration:none;background:rgba(var(--gold-rgb,201,168,76),.06);border:1px solid rgba(var(--gold-rgb,201,168,76),.12);transition:.22s ease;font-size:var(--fs-base,15px);display:block}
.side-menu a:hover,.side-menu a.active{background:var(--grad-primary,linear-gradient(135deg,#c9a84c,#e8c97a));color:#140900;font-weight:bold;transform:translateX(4px)}
.sidebar .logout{margin-top:18px;flex-shrink:0;display:block;padding:14px;border-radius:var(--radius,14px);text-align:center;color:#fca5a5;text-decoration:none;border:1px solid rgba(239,68,68,.35);background:rgba(239,68,68,.08);font-size:var(--fs-base,15px);font-weight:bold;transition:.2s}
.sidebar .logout:hover{background:rgba(239,68,68,.18)}
@media(max-width:900px){
  .admin-layout{display:block;margin:0;padding:0}
  .sidebar{position:relative!important;width:100%!important;min-width:100%!important;height:auto!important;overflow:visible!important}
  .content,main.content{margin-left:0!important;padding:24px 18px;overflow-x:auto;min-height:auto;width:100%!important}
  .side-menu a{padding:11px 14px}
  .side-menu a:hover,.side-menu a.active{transform:none}
}
</style>
<link rel="stylesheet" href="assets/responsive_global.css">
</head>

<body>

<div class="admin-layout">

    <?php include "sidebar_admin.php"; ?>

    <main class="content" style="display:block;min-height:100vh;box-sizing:border-box">

        <div class="topbar">
            <div>
                <p class="subtitle">RESTAURANT MANAGEMENT</p>
                <h1>Atribuir Mesas</h1>
            </div>

            <div class="session-box">
                Sessão iniciada como: <strong><?= htmlspecialchars($adminName) ?></strong>
            </div>
        </div>

        <?php if ($msg !== ""): ?>

   			 <div class="msg <?= $msgType ?>">
      		  <?= htmlspecialchars($msg) ?>
    		</div>

		<?php endif; ?>

        <section class="grid">

            <?php if ($waiters && $waiters->num_rows > 0): ?>

                <?php while($waiter = $waiters->fetch_assoc()): ?>

                    <?php
                        $waiterId = intval($waiter["id"]);
                        $assignedTables = $assignments[$waiterId] ?? [];

                        $tables->data_seek(0);
                    ?>

                    <article class="card">

                        <h2><?= htmlspecialchars($waiter["name"] ?: $waiter["username"]) ?></h2>
                        <p>Seleciona as mesas que este empregado de mesa vai servir.</p>

                        <form method="POST">

                            <input type="hidden" name="waiter_id" value="<?= htmlspecialchars($waiterId) ?>">

                            <div class="tables-list">

                                <?php while($table = $tables->fetch_assoc()): ?>

                                    <?php $tableNumber = intval($table["number"]); ?>

                                    <label class="table-check">
                                        <input
                                            type="checkbox"
                                            name="tables[]"
                                            value="<?= htmlspecialchars($tableNumber) ?>"
                                            <?= in_array($tableNumber, $assignedTables) ? "checked" : "" ?>
                                        >

                                        Mesa <?= htmlspecialchars($tableNumber) ?>
                                    </label>

                                <?php endwhile; ?>

                            </div>

                            <button type="submit" name="save_assignment">
                                Guardar Mesas
                            </button>

                        </form>

                    </article>

                <?php endwhile; ?>

            <?php else: ?>

                <div class="card">
                    <h2>Nenhum empregado de mesa encontrado</h2>
                    <p>Cria primeiro utilizadores com a função empregado de mesa.</p>
                </div>

            <?php endif; ?>

        </section>

    </main>

</div>

<script src="assets/keep_session.js"></script>
</body>
</html>
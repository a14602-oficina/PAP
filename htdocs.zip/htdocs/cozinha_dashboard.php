<?php
require_once "error_config.php";

require_once "auth_check.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "cozinha") {
    header("Location: login.php");
    exit;
}

$cozinhaName = $_SESSION["name"] ?? $_SESSION["username"] ?? "Cozinha";
$msg = "";

function addMovement($conn, $orderId, $status, $message) {
    $check = $conn->query("SHOW TABLES LIKE 'order_movements'");
    if ($check && $check->num_rows > 0) {
        $stmt = $conn->prepare("INSERT INTO order_movements (order_id, status, message) VALUES (?, ?, ?)");
        if ($stmt) {
            $stmt->bind_param("iss", $orderId, $status, $message);
            $stmt->execute();
        }
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["processar"])) {
    $orderId = intval($_POST["order_id"] ?? 0);
    if ($orderId > 0) {
        $stmt = $conn->prepare("UPDATE orders SET status = 'processando' WHERE id = ?");
        $stmt->bind_param("i", $orderId);
        if ($stmt->execute()) {
            addMovement($conn, $orderId, "processando", "A cozinha começou a preparar o pedido.");
            $msg = "Pedido marcado como a ser processado.";
        }
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["pronto"])) {
    $orderId = intval($_POST["order_id"] ?? 0);
    if ($orderId > 0) {
        $stmt = $conn->prepare("UPDATE orders SET status = 'pronto' WHERE id = ?");
        $stmt->bind_param("i", $orderId);
        if ($stmt->execute()) {
            addMovement($conn, $orderId, "pronto", "A cozinha finalizou o pedido.");
            $msg = "Pedido marcado como prato finalizado.";
        }
    }
}

$orders = $conn->query("
    SELECT DISTINCT o.*
    FROM orders o
    INNER JOIN order_items oi ON oi.order_id = o.id
    WHERE o.status IN ('enviado','processando')
    AND LOWER(COALESCE(oi.category, '')) NOT LIKE '%bebida%'
    ORDER BY o.created_at ASC
");
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>SmartTable - Cozinha</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="favicon.ico" sizes="any">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="apple-touch-icon" href="assets/logo.png">
<link rel="manifest" href="site.webmanifest">
<meta name="theme-color" content="#0d0600">
<script src="assets/auto_refresh.js"></script>
<link rel="stylesheet" href="assets/responsive.css">
<link rel="stylesheet" href="assets/style.css">
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{min-height:100vh;font-family:Georgia,"Times New Roman",serif;background:linear-gradient(90deg,rgba(201,168,76,.04) 1px,transparent 1px),linear-gradient(rgba(201,168,76,.03) 1px,transparent 1px),radial-gradient(circle at top left,rgba(201,168,76,.18),transparent 35%),linear-gradient(135deg,var(--dark),#080300 70%);background-size:80px 80px,80px 80px,cover,cover;color:var(--cream)}
.header{padding:26px 42px;display:flex;justify-content:space-between;align-items:center;background:rgba(13,6,0,.78);border-bottom:1px solid rgba(201,168,76,.25)}.brand{display:flex;align-items:center;gap:14px}.logo{width:58px;height:58px;border-radius:16px;background:linear-gradient(135deg,var(--gold),var(--gold-light));color:#140900;display:flex;align-items:center;justify-content:center;font-size:28px;font-weight:bold}.brand span{font-size:11px;letter-spacing:4px;color:var(--gold-light)}.brand h1{font-size:30px}.session{display:flex;align-items:center;gap:14px}.session-box{padding:13px 18px;border-radius:999px;border:1px solid rgba(201,168,76,.25);background:rgba(13,6,0,.65);color:var(--cream2)}.logout{padding:13px 18px;border-radius:14px;text-decoration:none;color:#fca5a5;background:rgba(239,68,68,.10);border:1px solid rgba(239,68,68,.35);font-weight:bold}
.main{padding:38px}.subtitle{color:var(--gold-light);letter-spacing:8px;font-size:13px;margin-bottom:8px}.top h2{font-size:46px;margin-bottom:32px}.msg{padding:14px 18px;margin-bottom:24px;border-radius:14px;background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.35);color:#86efac}.orders-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px}.order-card{border:1px solid rgba(201,168,76,.28);border-radius:24px;background:linear-gradient(145deg,rgba(38,21,8,.78),rgba(13,6,0,.94));box-shadow:0 18px 55px rgba(0,0,0,.35);overflow:hidden}.order-header{padding:22px 24px;border-bottom:1px solid rgba(201,168,76,.16);display:flex;justify-content:space-between;align-items:center}.order-header h3{color:var(--gold-light);font-size:28px}.badge{padding:8px 12px;border-radius:999px;text-transform:uppercase;font-size:12px;font-weight:bold}.badge.enviado{color:#fbbf24;background:rgba(245,158,11,.12);border:1px solid rgba(245,158,11,.35)}.badge.processando{color:#93c5fd;background:rgba(59,130,246,.12);border:1px solid rgba(59,130,246,.35)}.order-body{padding:22px 24px}.meta{color:rgba(245,234,216,.6);font-size:14px;margin-bottom:18px}.item-row{display:flex;justify-content:space-between;gap:18px;padding:12px 0;border-bottom:1px solid rgba(201,168,76,.10);color:var(--cream2)}.item-row strong{color:var(--cream)}.total{margin-top:18px;padding:16px;border-radius:16px;background:rgba(201,168,76,.12);border:1px solid rgba(201,168,76,.25);display:flex;justify-content:space-between;color:var(--gold-light);font-size:22px;font-weight:bold}.actions{padding:22px 24px;display:grid;gap:12px}button{width:100%;padding:14px;border:none;border-radius:14px;background:linear-gradient(135deg,var(--gold),var(--gold-light));color:#140900;font-weight:bold;cursor:pointer}.btn-ready{background:linear-gradient(135deg,#22c55e,#86efac)}
.customization-badges{display:flex;flex-wrap:wrap;gap:4px;margin-top:4px}
.cbadge{padding:3px 9px;border-radius:999px;font-size:11px;font-weight:bold}
.cbadge.sem{background:rgba(239,68,68,.15);border:1px solid rgba(239,68,68,.35);color:#fca5a5}
.cbadge.com{background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.3);color:#86efac}
.cbadge.extra{background:rgba(245,158,11,.12);border:1px solid rgba(245,158,11,.3);color:#fbbf24}
.cbadge.outro{background:rgba(148,163,184,.1);border:1px solid rgba(148,163,184,.25);color:#cbd5e1}

.empty{padding:28px;border:1px solid rgba(201,168,76,.28);border-radius:24px;background:rgba(13,6,0,.45);color:rgba(245,234,216,.65)}
@media(max-width:1200px){.orders-grid{grid-template-columns:repeat(2,1fr)}}@media(max-width:750px){.header{flex-direction:column;align-items:flex-start;gap:18px;padding:24px 18px}.main{padding:22px 18px}.orders-grid{grid-template-columns:1fr}.top h2{font-size:34px}}
    /* FIX INTERFACE NORMAL */
body{
  width:100%;
  min-height:100vh;
  display:block !important;
  align-items:initial !important;
  justify-content:initial !important;
}

.header{
  width:100%;
  max-width:none !important;
  margin:0 !important;
  padding:28px 42px !important;
  display:flex !important;
  justify-content:space-between !important;
  align-items:center !important;
}

.brand{
  display:flex !important;
  align-items:center !important;
  justify-content:flex-start !important;
  gap:14px !important;
  text-align:left !important;
}

.logo{
  width:58px !important;
  height:58px !important;
  font-size:28px !important;
}

.brand h1{
  font-size:30px !important;
  line-height:1 !important;
}

.main{
  width:100%;
  max-width:none !important;
  margin:0 !important;
  padding:42px !important;
}

.top,
.page-top{
  width:100%;
  max-width:none !important;
}

.panel{
  width:100%;
  max-width:none !important;
}

.session{
  display:flex !important;
  flex-direction:row !important;
  align-items:center !important;
  gap:14px !important;
}
</style>
<?php include_once __DIR__ . "/theme.php"; ?>
<link rel="stylesheet" href="assets/responsive_global.css">
</head>
<body>
<header class="header"><div class="brand"><a href="index.php" style="text-decoration:none"><img src="assets/logo.png" alt="SmartTable" style="height:72px;width:auto;object-fit:contain"></a><div><span>RESTAURANT MANAGEMENT</span><h1>SmartTable</h1></div></div><div class="session"><div class="session-box">Sessão iniciada como: <strong><?= htmlspecialchars($cozinhaName) ?></strong></div><a href="logout.php" class="logout">Terminar Sessão</a></div></header>
<main class="main"><div class="top"><p class="subtitle">PAINEL DA COZINHA</p><h2>Pedidos recebidos</h2></div>
<?php if ($msg !== ""): ?><div class="msg"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
<section id="live-content" class="orders-grid">
<?php if ($orders && $orders->num_rows > 0): ?>
<?php while($order = $orders->fetch_assoc()): ?>
<?php
$itemsStmt = $conn->prepare("SELECT * FROM order_items WHERE order_id = ? ORDER BY id ASC");
$itemsStmt->bind_param("i", $order["id"]);
$itemsStmt->execute();
$items = $itemsStmt->get_result();
$kitchenTotal = 0;
$hasKitchenItems = false;
?>
<article class="order-card"><div class="order-header"><h3>Mesa <?= htmlspecialchars($order["table_number"]) ?></h3><span class="badge <?= htmlspecialchars($order["status"]) ?>"><?= htmlspecialchars($order["status"]) ?></span></div>
<div class="order-body"><div class="meta">Pedido #<?= htmlspecialchars($order["id"]) ?> · <?= htmlspecialchars($order["created_at"]) ?></div>
<?php if ($items && $items->num_rows > 0): ?>
<?php while($item = $items->fetch_assoc()):
  // Cozinha só vê não-bebidas
  $itemCat = strtolower($item["category"] ?? "");
  if (str_contains($itemCat, "bebida")) continue;
  $hasKitchenItems = true;
  $kitchenTotal += floatval($item["subtotal"] ?? 0);
  $customStr = $item["customization"] ?? "";
  $badges = [];
  if ($customStr) {
    foreach (explode("|", $customStr) as $opt) {
      $opt = trim($opt);
      if ($opt === "") continue;
      if (str_starts_with($opt,"sem "))  $badges[] = ['sem',  $opt];
      elseif (str_starts_with($opt,"com ")) $badges[] = ['com',  $opt];
      elseif (str_starts_with($opt,"+"))    $badges[] = ['extra',$opt];
      else                                   $badges[] = ['outro',$opt];
    }
  }
?>
<div class="item-row">
  <div>
    <div><strong><?= htmlspecialchars($item["quantity"]) ?>x</strong> <?= htmlspecialchars($item["name"]) ?></div>
    <?php if (!empty($badges)): ?>
      <div class="customization-badges">
        <?php foreach ($badges as [$type,$label]): ?>
          <span class="cbadge <?= $type ?>"><?= htmlspecialchars($label) ?></span>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
  <span><?= number_format((float)$item["subtotal"],2,",",".") ?> €</span>
</div>
<?php endwhile; ?>
<?php if (!$hasKitchenItems): ?>
  <div class="item-row"><span>Sem itens para a cozinha.</span><span>--</span></div>
<?php endif; ?>
<?php else: ?><div class="item-row"><span>Sem itens.</span><span>--</span></div><?php endif; ?>
<div class="total"><span>Total cozinha</span><span><?= number_format((float)$kitchenTotal,2,",",".") ?> €</span></div></div>
<div class="actions">
<?php if ($order["status"] === "enviado"): ?><form method="POST"><input type="hidden" name="order_id" value="<?= htmlspecialchars($order["id"]) ?>"><button type="submit" name="processar">A ser processado</button></form><?php endif; ?>
<form method="POST" onsubmit="return confirm('Marcar este pedido como finalizado?')"><input type="hidden" name="order_id" value="<?= htmlspecialchars($order["id"]) ?>"><button type="submit" name="pronto" class="btn-ready">Prato finalizado</button></form>
</div></article>
<?php endwhile; ?>
<?php else: ?><div class="empty">Ainda não existem pedidos enviados para a cozinha.</div><?php endif; ?>
</section></main><script src="assets/keep_session.js"></script>
<script src="assets/notifications.js"></script>
</body></html>
<?php
require_once "error_config.php";

require_once "auth_check.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "admin") {
    header("Location: login.php");
    exit;
}

$adminName = $_SESSION["name"] ?? "Administrador";
$msg = "";
$editItem = null;

/* ELIMINAR */
if (isset($_GET["delete"])) {
    $id = intval($_GET["delete"]);

    $stmt = $conn->prepare("DELETE FROM menus WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: gestao_menus.php?msg=Item eliminado com sucesso");
        exit;
    } else {
        $msg = "Erro ao eliminar item.";
    }
}

/* BUSCAR PARA EDITAR */
if (isset($_GET["edit"])) {
    $id = intval($_GET["edit"]);

    $stmt = $conn->prepare("SELECT * FROM menus WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    $editItem = $stmt->get_result()->fetch_assoc();
}

/* CRIAR / ATUALIZAR */
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id = intval($_POST["id"] ?? 0);
    $name = trim($_POST["name"] ?? "");
    $description = trim($_POST["description"] ?? "");
    $category = trim($_POST["category"] ?? "");
    $price = floatval($_POST["price"] ?? 0);
    $status = trim($_POST["status"] ?? "disponivel");

    $categoriasPermitidas = ["entrada", "prato", "bebida", "sobremesa"];
    $statusPermitidos = ["disponivel", "indisponivel"];

    if ($name === "" || $category === "" || $price <= 0) {
        $msg = "Preenche o nome, categoria e preço corretamente.";
    } elseif (!in_array($category, $categoriasPermitidas)) {
        $msg = "Categoria inválida.";
    } elseif (!in_array($status, $statusPermitidos)) {
        $msg = "Estado inválido.";
    } else {
        if ($id > 0) {
            $stmt = $conn->prepare("
                UPDATE menus
                SET name = ?, description = ?, category = ?, price = ?, status = ?
                WHERE id = ?
            ");

            $stmt->bind_param("sssdsi", $name, $description, $category, $price, $status, $id);

            if ($stmt->execute()) {
                header("Location: gestao_menus.php?msg=Item atualizado com sucesso");
                exit;
            } else {
                $msg = "Erro ao atualizar item.";
            }
        } else {
            $stmt = $conn->prepare("
                INSERT INTO menus (name, description, category, price, status)
                VALUES (?, ?, ?, ?, ?)
            ");

            $stmt->bind_param("sssds", $name, $description, $category, $price, $status);

            if ($stmt->execute()) {
                header("Location: gestao_menus.php?msg=Item criado com sucesso");
                exit;
            } else {
                $msg = "Erro ao criar item.";
            }
        }
    }
}

if (isset($_GET["msg"])) {
    $msg = htmlspecialchars($_GET["msg"]);
}

$result = $conn->query("SELECT * FROM menus ORDER BY category ASC, name ASC");
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>Gestão de Menus</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="favicon.ico" sizes="any">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="apple-touch-icon" href="assets/logo.png">
<link rel="manifest" href="site.webmanifest">
<meta name="theme-color" content="#0d0600">
<link rel="stylesheet" href="assets/responsive.css">
<?php include_once __DIR__ . "/theme.php"; ?>
<style>

*{box-sizing:border-box;margin:0;padding:0}

body{
  min-height:100vh;
  font-family:Georgia,"Times New Roman",serif;
  background:
    linear-gradient(90deg,rgba(201,168,76,.04) 1px,transparent 1px),
    linear-gradient(rgba(201,168,76,.03) 1px,transparent 1px),
    radial-gradient(circle at top left,rgba(201,168,76,.18),transparent 35%),
    linear-gradient(135deg,var(--dark),#080300 70%);
  background-size:80px 80px,80px 80px,cover,cover;
  color:var(--cream);
}

.brand h2{font-size:22px;line-height:1}
.brand span{font-size:11px;color:rgba(245,234,216,.55);letter-spacing:3px}

.content{margin-left:285px!important;padding:34px 46px;overflow-x:auto}

.topbar{
  display:flex;
  align-items:flex-start;
  justify-content:space-between;
  gap:24px;
  margin-bottom:36px;
}

.subtitle{
  color:var(--gold-light);
  letter-spacing:8px;
  font-size:13px;
  margin-bottom:6px;
}

.topbar h1{
  font-size:46px;
  line-height:1;
  color:var(--cream);
}

.session{
  padding:14px 22px;
  border-radius:999px;
  border:1px solid rgba(201,168,76,.25);
  background:rgba(13,6,0,.65);
  color:var(--cream2);
  white-space:nowrap;
}

.msg{
  padding:14px 18px;
  margin-bottom:24px;
  border-radius:14px;
  background:rgba(34,197,94,.12);
  border:1px solid rgba(34,197,94,.35);
  color:#86efac;
}

.panel{
  border:1px solid rgba(201,168,76,.28);
  border-radius:22px;
  background:linear-gradient(145deg,rgba(38,21,8,.78),rgba(13,6,0,.94));
  box-shadow:0 18px 55px rgba(0,0,0,.35);
  overflow:hidden;
  margin-bottom:28px;
}

.panel-header{
  padding:24px 28px;
  display:flex;
  justify-content:space-between;
  align-items:center;
  border-bottom:1px solid rgba(201,168,76,.16);
}

.panel-header h2{
  color:var(--gold-light);
  font-size:28px;
}

.form-body{
  padding:28px;
}

.form-grid{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:18px;
}

.form-group{
  display:flex;
  flex-direction:column;
}

.form-group.full{
  grid-column:1 / -1;
}

label{
  font-size:14px;
  color:var(--cream2);
  margin-bottom:8px;
}

input,
select,
textarea{
  width:100%;
  padding:14px 15px;
  border-radius:13px;
  border:1px solid rgba(201,168,76,.25);
  background:rgba(13,6,0,.72);
  color:var(--cream);
  outline:none;
  font-family:Georgia,"Times New Roman",serif;
}

textarea{
  min-height:90px;
  resize:vertical;
}

input:focus,
select:focus,
textarea:focus{
  border-color:var(--gold);
  box-shadow:0 0 0 3px rgba(201,168,76,.13);
}

.form-actions{
  margin-top:22px;
  display:flex;
  gap:12px;
}

.btn{
  padding:13px 18px;
  border-radius:14px;
  background:linear-gradient(135deg,var(--gold),var(--gold-light));
  color:#140900;
  text-decoration:none;
  font-weight:bold;
  border:none;
  cursor:pointer;
  display:inline-block;
}

.btn-secondary{
  padding:13px 18px;
  border-radius:14px;
  background:rgba(201,168,76,.09);
  color:var(--gold-light);
  text-decoration:none;
  border:1px solid rgba(201,168,76,.22);
  display:inline-block;
}

.table-wrap{
  overflow-x:auto;
}

table{
  width:100%;
  border-collapse:collapse;
  min-width:950px;
}

th,
td{
  padding:17px 20px;
  text-align:left;
  border-bottom:1px solid rgba(201,168,76,.12);
  font-size:15px;
  vertical-align:top;
}

th{
  color:var(--gold-light);
  background:rgba(201,168,76,.10);
  font-size:14px;
  letter-spacing:1px;
}

td{
  color:var(--cream2);
}

tr:hover td{
  background:rgba(201,168,76,.045);
}

.badge{
  display:inline-block;
  padding:7px 11px;
  border-radius:999px;
  background:rgba(201,168,76,.13);
  border:1px solid rgba(201,168,76,.25);
  color:var(--gold-light);
  text-transform:uppercase;
  font-size:12px;
}

.badge.off{
  color:#fca5a5;
  border-color:rgba(239,68,68,.35);
  background:rgba(239,68,68,.10);
}

.price{
  color:var(--gold-light);
  font-weight:bold;
}

.actions{
  white-space:nowrap;
}

.actions a{
  display:inline-block;
  padding:8px 11px;
  margin-right:7px;
  border-radius:10px;
  text-decoration:none;
  color:var(--gold-light);
  background:rgba(201,168,76,.08);
  border:1px solid rgba(201,168,76,.18);
}

.actions a:hover{
  background:linear-gradient(135deg,var(--gold),var(--gold-light));
  color:#140900;
}

.delete-link{
  color:#fca5a5!important;
  border-color:rgba(239,68,68,.28)!important;
  background:rgba(239,68,68,.08)!important;
}

.empty{
  padding:28px;
  color:rgba(245,234,216,.65);
}

@media(max-width:1100px){
  .form-grid{grid-template-columns:1fr 1fr}
}

@media(max-width:900px){
  .admin-layout{display:block;margin:0;padding:0}
  
  .content{padding:28px 20px;margin-left:285px!important}
  .topbar{flex-direction:column}
  .topbar h1{font-size:36px}
  .session{white-space:normal}
  .form-grid{grid-template-columns:1fr}
}
</style>
<style id="sidebar-fixed">
/* ── TOPBAR UNIFICADO ── */
.topbar,.page-topbar{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:32px;flex-wrap:wrap}
.topbar-left,.topbar-right{display:flex;align-items:center;gap:12px}
.page-subtitle,.subtitle{color:var(--gold-light,#e8c97a);letter-spacing:7px;font-size:12px;margin-bottom:6px;display:block}
.session-box,.session,.user-box{
  padding:11px 20px;
  border-radius:999px;
  background:rgba(13,6,0,.65);
  border:1px solid rgba(var(--gold-rgb,201,168,76),.25);
  color:var(--cream2,#ede0c4);
  font-size:14px;
  white-space:nowrap;
  font-family:var(--font,Georgia),serif;
}

/* ── SIDEBAR FIXA ── */
.admin-layout{display:block;margin:0;padding:0}
.sidebar{
  width:285px;min-width:285px;padding:26px 24px;
  background:var(--sidebar-gradient,linear-gradient(180deg,rgba(26,14,4,.98),rgba(13,6,0,.96)));
  border-right:1px solid rgba(var(--gold-rgb,201,168,76),.22);
  position:fixed!important;top:0;left:0;
  height:100vh;overflow-y:auto;overflow-x:hidden;
  z-index:100;display:flex;flex-direction:column;
}
.sidebar::-webkit-scrollbar{width:4px}
.sidebar::-webkit-scrollbar-thumb{background:rgba(201,168,76,.25);border-radius:2px}
.content{margin-left:285px!important;padding:34px 46px;overflow-x:auto;min-height:100vh}
.sidebar .sidebar-logo{display:flex!important;flex-direction:row!important;align-items:center!important;gap:14px!important;margin-bottom:42px!important;flex-shrink:0}
.sidebar .logo-box{width:56px!important;height:56px!important;border-radius:var(--radius,18px)!important;background:var(--grad-primary,linear-gradient(135deg,#c9a84c,#e8c97a))!important;color:#140900!important;display:flex!important;align-items:center!important;justify-content:center!important;font-size:28px!important;font-weight:bold!important;flex-shrink:0!important}
.sidebar .sidebar-logo h2{color:var(--gold-light,#e8c97a)!important;font-size:24px!important;line-height:1!important;margin:0!important}
.sidebar .sidebar-logo span{font-size:12px!important;color:rgba(245,234,216,.55)!important;letter-spacing:2px!important;display:block!important}
.menu-title{font-size:12px;color:rgba(245,234,216,.45);letter-spacing:3px;margin-bottom:16px;flex-shrink:0}
.side-menu{display:flex;flex-direction:column;gap:10px;flex:1}
.side-menu a{padding:14px 16px;border-radius:var(--radius,16px);color:var(--cream2,#ede0c4);text-decoration:none;background:rgba(var(--gold-rgb,201,168,76),.06);border:1px solid rgba(var(--gold-rgb,201,168,76),.12);transition:.22s ease;font-size:var(--fs-base,15px);display:block}
.side-menu a:hover,.side-menu a.active{background:var(--grad-primary,linear-gradient(135deg,#c9a84c,#e8c97a));color:#140900;font-weight:bold;transform:translateX(4px)}
.sidebar .logout{margin-top:18px;flex-shrink:0;display:block;padding:14px;border-radius:var(--radius,14px);text-align:center;color:#fca5a5;text-decoration:none;border:1px solid rgba(239,68,68,.35);background:rgba(239,68,68,.08);font-size:var(--fs-base,15px);font-weight:bold;transition:.2s}
.sidebar .logout:hover{background:rgba(239,68,68,.18)}
@media(max-width:900px){
  .admin-layout{display:block;margin:0;padding:0}
  .sidebar{position:relative!important;width:100%!important;min-width:100%!important;height:auto!important;overflow:visible!important}
  .content,main.content{margin-left:0!important;padding:24px 18px;overflow-x:auto;min-height:auto;width:100%!important}
  .side-menu a{padding:11px 14px}
  .side-menu a:hover,.side-menu a.active{transform:none}
}
</style>
<link rel="stylesheet" href="assets/responsive_global.css">
</head>

<body>

<div class="admin-layout">

  <?php include "sidebar_admin.php"; ?>

  <main class="content" style="display:block;min-height:100vh;box-sizing:border-box">

    <div class="topbar">
      <div>
        <p class="subtitle">RESTAURANT MANAGEMENT</p>
        <h1>Gestão de Menus</h1>
      </div>

      <div class="session-box">
        Sessão iniciada como: <strong><?= htmlspecialchars($adminName) ?></strong>
      </div>
    </div>

    <?php if ($msg !== ""): ?>
      <div class="msg"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>

    <section class="panel">
      <div class="panel-header">
        <h2><?= $editItem ? "Editar Item" : "Criar Item do Menu" ?></h2>
      </div>

      <div class="form-body">
        <form method="POST" action="gestao_menus.php">
          <input type="hidden" name="id" value="<?= htmlspecialchars($editItem["id"] ?? "") ?>">

          <div class="form-grid">

            <div class="form-group">
              <label>Nome do item</label>
              <input type="text" name="name" required value="<?= htmlspecialchars($editItem["name"] ?? "") ?>">
            </div>

            <div class="form-group">
              <label>Categoria</label>
              <select name="category" required>
                <?php
                $categorias = ["entrada", "prato", "bebida", "sobremesa"];
                foreach ($categorias as $cat):
                    $selected = (($editItem["category"] ?? "") === $cat) ? "selected" : "";
                ?>
                  <option value="<?= $cat ?>" <?= $selected ?>><?= ucfirst($cat) ?></option>
                <?php endforeach; ?>
              </select>
            </div>

            <div class="form-group">
              <label>Preço (€)</label>
              <input type="number" step="0.01" min="0.01" name="price" required value="<?= htmlspecialchars($editItem["price"] ?? "") ?>">
            </div>

            <div class="form-group">
              <label>Estado</label>
              <select name="status" required>
                <option value="disponivel" <?= (($editItem["status"] ?? "") === "disponivel") ? "selected" : "" ?>>Disponível</option>
                <option value="indisponivel" <?= (($editItem["status"] ?? "") === "indisponivel") ? "selected" : "" ?>>Indisponível</option>
              </select>
            </div>

            <div class="form-group full">
              <label>Descrição</label>
              <textarea name="description"><?= htmlspecialchars($editItem["description"] ?? "") ?></textarea>
            </div>

          </div>

          <div class="form-actions">
            <button type="submit" class="btn">
              <?= $editItem ? "Guardar Alterações" : "Criar Item" ?>
            </button>

            <?php if ($editItem): ?>
              <a href="gestao_menus.php" class="btn-secondary">Cancelar edição</a>
            <?php endif; ?>
          </div>
        </form>
      </div>
    </section>

    <section class="panel">
      <div class="panel-header">
        <h2>🍽️ Lista de Itens</h2>
      </div>

      <?php if ($result && $result->num_rows > 0): ?>
        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Descrição</th>
                <th>Categoria</th>
                <th>Preço</th>
                <th>Estado</th>
                <th>Ações</th>
              </tr>
            </thead>

            <tbody>
              <?php while($item = $result->fetch_assoc()): ?>
              <tr>
                <td><?= htmlspecialchars($item["id"]) ?></td>
                <td><?= htmlspecialchars($item["name"]) ?></td>
                <td><?= htmlspecialchars($item["description"]) ?></td>
                <td><span class="badge"><?= htmlspecialchars($item["category"]) ?></span></td>
                <td class="price"><?= number_format((float)$item["price"], 2, ",", ".") ?> €</td>
                <td>
                  <span class="badge <?= $item["status"] === "indisponivel" ? "off" : "" ?>">
                    <?= htmlspecialchars($item["status"]) ?>
                  </span>
                </td>
                <td class="actions">
                  <a href="gestao_menus.php?edit=<?= urlencode($item["id"]) ?>">Editar</a>
                  <a class="delete-link" href="gestao_menus.php?delete=<?= urlencode($item["id"]) ?>" onclick="return confirm('Eliminar este item do menu?')">Eliminar</a>
                </td>
              </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      <?php else: ?>
        <p class="empty">Nenhum item encontrado.</p>
      <?php endif; ?>
    </section>

  </main>

</div>

<script src="assets/keep_session.js"></script>
</body>
</html>
<?php
require_once "error_config.php";

require_once "auth_check.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "admin") {
    header("Location: login.php");
    exit;
}

$name = $_SESSION["name"] ?? "Administrador";

/* ── LIBERTAR MESAS / LIMPAR SERVIÇO ── */
function st_table_exists(mysqli $conn, string $table): bool {
    $table = $conn->real_escape_string($table);
    $res = $conn->query("SHOW TABLES LIKE '$table'");
    return $res && $res->num_rows > 0;
}

function st_column_exists(mysqli $conn, string $table, string $column): bool {
    $table = str_replace('`', '', $table);
    $column = $conn->real_escape_string($column);
    $res = $conn->query("SHOW COLUMNS FROM `$table` LIKE '$column'");
    return $res && $res->num_rows > 0;
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && (isset($_POST["clear_occupations"]) || isset($_POST["reset_ocupacoes"]))) {

    /* Libertar mesas e repor bloqueios do fluxo */
    if (st_table_exists($conn, "tables")) {
        $updates = [];

        $possibleUpdates = [
            "status"                      => "'livre'",
            "occupied_seats"              => "0",
            "people_count"                => "0",
            "current_order_id"            => "NULL",
            "current_payment_code"        => "NULL",
            "selected_at"                 => "NULL",
            "arrival_time"                => "NULL",
            "entries_drinks_delivered_at" => "NULL",
            "main_unlocked"               => "0",
            "main_unlocked_at"            => "NULL",
            "main_delivered_at"           => "NULL",
            "dessert_unlocked"            => "0",
            "dessert_unlocked_at"         => "NULL"
        ];

        foreach ($possibleUpdates as $column => $value) {
            if (st_column_exists($conn, "tables", $column)) {
                $updates[] = "`$column` = $value";
            }
        }

        if (!empty($updates)) {
            $conn->query("UPDATE `tables` SET " . implode(", ", $updates));
        }
    }

    /* Eliminar pagamentos */
    if (st_table_exists($conn, "payments")) {
        $conn->query("DELETE FROM payments");
    }

    /* Eliminar itens dos pedidos antes dos pedidos */
    if (st_table_exists($conn, "order_items")) {
        $conn->query("DELETE FROM order_items");
    }

    /* Eliminar pedidos */
    if (st_table_exists($conn, "orders")) {
        $conn->query("DELETE FROM orders");
    }

    /* Eliminar pedidos do bar, se existir */
    if (st_table_exists($conn, "bar_order_items")) {
        $conn->query("DELETE FROM bar_order_items");
    }

    if (st_table_exists($conn, "bar_orders")) {
        $conn->query("DELETE FROM bar_orders");
    }

    $resetMsg = "Mesas libertadas, pedidos e pagamentos eliminados.";
}

/* Garantir tabela de chamadas */
$conn->query("
    CREATE TABLE IF NOT EXISTS manager_calls (
        id INT AUTO_INCREMENT PRIMARY KEY,
        table_number INT NULL,
        message VARCHAR(255) DEFAULT 'Cliente chamou o gerente',
        status VARCHAR(30) NOT NULL DEFAULT 'pendente',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        resolved_at DATETIME NULL
    )
");

/* Contar notificações */
$notifCount = 0;

$callsCheck = $conn->query("
    SELECT COUNT(*) AS total
    FROM manager_calls
    WHERE status = 'pendente'
");

if ($callsCheck) {
    $notifCount += intval($callsCheck->fetch_assoc()["total"]);
}

$paymentsCheck = $conn->query("
    SELECT COUNT(*) AS total
    FROM orders
    WHERE status = 'pagamento'
");

if ($paymentsCheck) {
    $notifCount += intval($paymentsCheck->fetch_assoc()["total"]);
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>SmartTable - Administração</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="favicon.ico" sizes="any">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="apple-touch-icon" href="assets/logo.png">
<link rel="manifest" href="site.webmanifest">
<meta name="theme-color" content="#0d0600">

<style>
:root{
  --gold:#c9a84c;
  --gold-light:#e8c97a;
  --dark:#0d0600;
  --cream:#f5ead8;
  --cream2:#ede0c4;
}

*{
  margin:0;
  padding:0;
  box-sizing:border-box;
  font-family:Georgia,"Times New Roman",serif;
}

body{
  min-height:100vh;
  background:
    linear-gradient(90deg,rgba(201,168,76,.04) 1px,transparent 1px),
    linear-gradient(rgba(201,168,76,.03) 1px,transparent 1px),
    radial-gradient(circle at top left,rgba(201,168,76,.18),transparent 35%),
    linear-gradient(135deg,var(--dark),#080300 70%);
  background-size:80px 80px,80px 80px,cover,cover;
  color:var(--cream);
}

.admin-layout{display:block;margin:0;padding:0}

.menu-title{
  font-size:12px;
  color:rgba(245,234,216,.45);
  letter-spacing:3px;
  margin-bottom:16px;
}

.side-menu{
  display:flex;
  flex-direction:column;
  gap:12px;
}

.side-menu a{
  padding:15px 16px;
  border-radius:16px;
  color:var(--cream2);
  text-decoration:none;
  background:rgba(201,168,76,.06);
  border:1px solid rgba(201,168,76,.12);
  transition:.25s ease;
}

.side-menu a:hover,
.side-menu a.active{
  background:linear-gradient(135deg,var(--gold),var(--gold-light));
  color:#140900;
  transform:translateX(4px);
  box-shadow:0 10px 30px rgba(201,168,76,.25);
}

.logout{
  margin-top:40px;
  display:block;
  padding:14px;
  border-radius:14px;
  text-align:center;
  color:#fca5a5;
  text-decoration:none;
  border:1px solid rgba(239,68,68,.35);
  background:rgba(239,68,68,.08);
}

.content{margin-left:285px!important;padding:42px;overflow-x:auto}

.topbar{
  display:flex;
  justify-content:space-between;
  align-items:flex-start;
  gap:20px;
  margin-bottom:36px;
}

.subtitle{
  color:var(--gold-light);
  letter-spacing:7px;
  font-size:12px;
  margin-bottom:10px;
}

.topbar h1{
  font-size:44px;
  line-height:1.05;
}

.topbar-right{
  display:flex;
  align-items:center;
  gap:16px;
}

.user-box{
  padding:14px 18px;
  border-radius:999px;
  border:1px solid rgba(201,168,76,.25);
  background:rgba(13,6,0,.65);
  color:var(--cream2);
  white-space:nowrap;
}

.notification-wrapper{
  position:relative;
}

.notification-btn{
  width:56px;
  height:56px;
  border-radius:16px;
  border:1px solid rgba(201,168,76,.25);
  background:rgba(13,6,0,.65);
  color:var(--gold-light);
  font-size:24px;
  cursor:pointer;
  position:relative;
}

.notification-badge{
  position:absolute;
  top:-7px;
  right:-7px;
  min-width:24px;
  height:24px;
  padding:0 7px;
  border-radius:999px;
  background:#ef4444;
  color:white;
  display:flex;
  align-items:center;
  justify-content:center;
  font-size:12px;
  font-weight:bold;
}

.notification-dropdown{
  position:absolute;
  top:70px;
  right:0;
  width:340px;
  max-height:430px;
  overflow:auto;
  display:none;
  z-index:999;
  padding:20px;
  border-radius:22px;
  border:1px solid rgba(201,168,76,.25);
  background:linear-gradient(145deg,rgba(38,21,8,.98),rgba(13,6,0,.98));
  box-shadow:0 20px 60px rgba(0,0,0,.45);
}

.notification-dropdown.active{
  display:block;
}

.notification-dropdown h4{
  color:var(--gold-light);
  font-size:24px;
  margin-bottom:16px;
}

.notification-item{
  padding:14px 0;
  border-bottom:1px solid rgba(201,168,76,.12);
}

.notification-item strong{
  color:var(--cream);
  display:block;
  margin-bottom:6px;
}

.notification-item p{
  color:rgba(245,234,216,.65);
  font-size:14px;
}

.notification-empty{
  color:rgba(245,234,216,.55);
  padding:12px 0;
}

.dashboard-grid{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:24px;
}

.dash-card{
  padding:28px;
  border-radius:22px;
  border:1px solid rgba(201,168,76,.22);
  background:linear-gradient(145deg,rgba(38,21,8,.88),rgba(13,6,0,.94));
  box-shadow:0 12px 40px rgba(0,0,0,.35);
  min-height:190px;
  display:flex;
  flex-direction:column;
}

.dash-card h3{
  color:var(--gold-light);
  font-size:25px;
  margin-bottom:12px;
}

.dash-card p{
  color:rgba(245,234,216,.62);
  line-height:1.6;
  margin-bottom:auto;
  flex:1;
  padding-bottom:20px;
}

.dash-card a{
  display:inline-block;
  padding:11px 22px;
  border-radius:999px;
  background:linear-gradient(135deg,var(--gold),var(--gold-light));
  color:#140900;
  text-decoration:none;
  font-weight:bold;
  font-size:14px;
  letter-spacing:.3px;
}

@media(max-width:1000px){
  .dashboard-grid{
    grid-template-columns:repeat(2,1fr);
  }
}

@media(max-width:760px){
  .admin-layout{display:block;margin:0;padding:0}

  

  .content{
    padding:28px 18px;;margin-left:285px!important}

  .topbar{
    flex-direction:column;
  }

  .topbar h1{
    font-size:38px;
  }

  .topbar-right{
    width:100%;
    flex-direction:column;
    align-items:flex-start;
  }

  .user-box,
  .notification-btn{
    width:100%;
  }

  .notification-dropdown{
    left:0;
    right:auto;
    width:100%;
  }

  .dashboard-grid{
    grid-template-columns:1fr;
  }
}
</style>
<?php include_once __DIR__ . "/theme.php"; ?>
<style id="sidebar-fixed">
/* ── TOPBAR UNIFICADO ── */
.topbar,.page-topbar{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:32px;flex-wrap:wrap}
.topbar-left,.topbar-right{display:flex;align-items:center;gap:12px}
.page-subtitle,.subtitle{color:var(--gold-light,#e8c97a);letter-spacing:7px;font-size:12px;margin-bottom:6px;display:block}
.session-box,.session,.user-box{
  padding:11px 20px;
  border-radius:999px;
  background:rgba(13,6,0,.65);
  border:1px solid rgba(var(--gold-rgb,201,168,76),.25);
  color:var(--cream2,#ede0c4);
  font-size:14px;
  white-space:nowrap;
  font-family:var(--font,Georgia),serif;
}

/* ── SIDEBAR FIXA ── */
.admin-layout{display:block;margin:0;padding:0}
.sidebar{
  width:285px;min-width:285px;padding:26px 24px;
  background:var(--sidebar-gradient,linear-gradient(180deg,rgba(26,14,4,.98),rgba(13,6,0,.96)));
  border-right:1px solid rgba(var(--gold-rgb,201,168,76),.22);
  position:fixed!important;top:0;left:0;
  height:100vh;overflow-y:auto;overflow-x:hidden;
  z-index:100;display:flex;flex-direction:column;
}
.sidebar::-webkit-scrollbar{width:4px}
.sidebar::-webkit-scrollbar-thumb{background:rgba(201,168,76,.25);border-radius:2px}
.content{margin-left:285px!important;padding:34px 46px;overflow-x:auto;min-height:100vh}
.sidebar .sidebar-logo{display:flex!important;flex-direction:row!important;align-items:center!important;gap:14px!important;margin-bottom:42px!important;flex-shrink:0}
.sidebar .logo-box{width:56px!important;height:56px!important;border-radius:var(--radius,18px)!important;background:var(--grad-primary,linear-gradient(135deg,#c9a84c,#e8c97a))!important;color:#140900!important;display:flex!important;align-items:center!important;justify-content:center!important;font-size:28px!important;font-weight:bold!important;flex-shrink:0!important}
.sidebar .sidebar-logo h2{color:var(--gold-light,#e8c97a)!important;font-size:24px!important;line-height:1!important;margin:0!important}
.sidebar .sidebar-logo span{font-size:12px!important;color:rgba(245,234,216,.55)!important;letter-spacing:2px!important;display:block!important}
.menu-title{font-size:12px;color:rgba(245,234,216,.45);letter-spacing:3px;margin-bottom:16px;flex-shrink:0}
.side-menu{display:flex;flex-direction:column;gap:10px;flex:1}
.side-menu a{padding:14px 16px;border-radius:var(--radius,16px);color:var(--cream2,#ede0c4);text-decoration:none;background:rgba(var(--gold-rgb,201,168,76),.06);border:1px solid rgba(var(--gold-rgb,201,168,76),.12);transition:.22s ease;font-size:var(--fs-base,15px);display:block}
.side-menu a:hover,.side-menu a.active{background:var(--grad-primary,linear-gradient(135deg,#c9a84c,#e8c97a));color:#140900;font-weight:bold;transform:translateX(4px)}
.sidebar .logout{margin-top:18px;flex-shrink:0;display:block;padding:14px;border-radius:var(--radius,14px);text-align:center;color:#fca5a5;text-decoration:none;border:1px solid rgba(239,68,68,.35);background:rgba(239,68,68,.08);font-size:var(--fs-base,15px);font-weight:bold;transition:.2s}
.sidebar .logout:hover{background:rgba(239,68,68,.18)}
@media(max-width:900px){
  .admin-layout{display:block;margin:0;padding:0}
  .sidebar{position:relative!important;width:100%!important;min-width:100%!important;height:auto!important;overflow:visible!important}
  .content,main.content{margin-left:0!important;padding:24px 18px;overflow-x:auto;min-height:auto;width:100%!important}
  .side-menu a{padding:11px 14px}
  .side-menu a:hover,.side-menu a.active{transform:none}
}
/* ── CARD LIMPAR OCUPAÇÕES ── */
.dash-card.danger{border-color:rgba(239,68,68,.35)!important;background:linear-gradient(145deg,rgba(60,10,10,.85),rgba(13,6,0,.94))!important}
.dash-card.danger h3{color:#fca5a5}
.dash-card.danger p{color:rgba(252,165,165,.55)}
.btn-danger-action{
  display:block;
  width:100%;
  padding:14px 20px;
  margin-top:4px;
  border-radius:var(--radius,14px);
  background:linear-gradient(135deg,#dc2626,#ef4444);
  color:#fff;
  font-weight:bold;
  font-size:15px;
  letter-spacing:.3px;
  border:none;
  cursor:pointer;
  font-family:var(--font,Georgia),serif;
  transition:.2s;
  box-shadow:0 6px 20px rgba(239,68,68,.3);
  text-align:center;
}
.btn-danger-action:hover{
  background:linear-gradient(135deg,#b91c1c,#dc2626);
  box-shadow:0 8px 28px rgba(239,68,68,.5);
  transform:translateY(-2px);
}
.reset-msg{
  padding:10px 14px;
  border-radius:10px;
  background:rgba(34,197,94,.12);
  border:1px solid rgba(34,197,94,.3);
  color:#86efac;
  font-size:13px;
  margin-top:12px;
  font-weight:bold;
}
</style>
<link rel="stylesheet" href="assets/sidebar_admin.css">
<link rel="stylesheet" href="assets/responsive_global.css">
</head>

<body>

<div class="admin-layout">

  <?php include "sidebar_admin.php"; ?>

  <main class="content" style="display:block;min-height:100vh;box-sizing:border-box">

    <div class="topbar" style="padding-left:0">

      <div>
        <p class="subtitle">RESTAURANT MANAGEMENT</p>
        <h1>Painel Administrativo</h1>
      </div>

      <div class="topbar-right">

        <div class="notification-wrapper">

          <button class="notification-btn" id="notificationBtn" type="button">
            🔔

            <?php if ($notifCount > 0): ?>
              <span class="notification-badge">
                <?= htmlspecialchars($notifCount) ?>
              </span>
            <?php endif; ?>
          </button>

          <div class="notification-dropdown" id="notificationDropdown">

            <h4>Notificações</h4>

            <?php
            $calls = $conn->query("
                SELECT *
                FROM manager_calls
                WHERE status = 'pendente'
                ORDER BY created_at DESC
                LIMIT 5
            ");
            ?>

            <?php if ($calls && $calls->num_rows > 0): ?>
              <?php while($call = $calls->fetch_assoc()): ?>
                <div class="notification-item">
                  <strong>Gerente chamado</strong>
                  <p>
                    Origem:
                    <?= !empty($call["table_number"])
                        ? "Mesa " . htmlspecialchars($call["table_number"])
                        : "Entrada" ?>
                  </p>
                </div>
              <?php endwhile; ?>
            <?php endif; ?>

            <?php
            $payments = $conn->query("
                SELECT *
                FROM orders
                WHERE status = 'pagamento'
                ORDER BY created_at DESC
                LIMIT 5
            ");
            ?>

            <?php if ($payments && $payments->num_rows > 0): ?>
              <?php while($payment = $payments->fetch_assoc()): ?>
                <div class="notification-item">
                  <strong>Pagamento pendente</strong>
                  <p>Mesa <?= htmlspecialchars($payment["table_number"]) ?></p>
                </div>
              <?php endwhile; ?>
            <?php endif; ?>

            <?php if ($notifCount === 0): ?>
              <div class="notification-empty">
                Sem notificações.
              </div>
            <?php endif; ?>

          </div>

        </div>

        <div class="session-box">
          Sessão iniciada como: <strong><?= htmlspecialchars($name) ?></strong>
        </div>

      </div>

    </div>

    <?php if (!empty($resetMsg)): ?>
      <div class="reset-msg" style="margin-bottom:22px;">
        <?= htmlspecialchars($resetMsg) ?>
      </div>
    <?php endif; ?>

    <section class="dashboard-grid">

      <div class="dash-card">
        <h3>🪑 Gestão de Mesas</h3>
        <p>Adicionar, editar e controlar mesas, lugares, tipo e estados de ocupação.</p>
        <a href="gestao_mesas.php">Abrir</a>
      </div>

      <div class="dash-card">
        <h3>👥 Gestão de Utilizadores</h3>
        <p>Criar e administrar contas para entrada, mesa, empregado de mesa, cozinha e admin.</p>
        <a href="gestao_utilizadores.php">Abrir</a>
      </div>

      <div class="dash-card">
        <h3>🍽️ Gestão de Menus</h3>
        <p>Gerir pratos, bebidas, preços, categorias e disponibilidade.</p>
        <a href="gestao_menus.php">Abrir</a>
      </div>

      <div class="dash-card">
        <h3>💳 Pagamentos</h3>
        <p>Ver contas pendentes, confirmar pagamentos e emitir recibos.</p>
        <a href="pagamento_dashboard.php">Abrir</a>
      </div>

      <div class="dash-card">
        <h3>🎨 Personalização</h3>
        <p>Personalizar tema do sistema e logótipo.</p>
        <a href="personalizacao_dashboard.php">Abrir</a>
      </div>

      <div class="dash-card">
        <h3>📞 Gerente</h3>
        <p>Recebe chamadas feitas pelos clientes e pedidos de assistência.</p>
        <a href="gerente_dashboard.php">Abrir</a>
      </div>

      <div class="dash-card">
        <h3>📋 Atribuir Mesas</h3>
        <p>Escolher quais mesas cada empregado de mesa vai acompanhar no seu painel.</p>
        <a href="atribuir_mesas.php">Abrir</a>
      </div>

      <div class="dash-card">
        <h3>📲 QR Codes das Mesas</h3>
        <p>Gera e descarrega o QR code de cada mesa. O cliente lê com o telemóvel e vai direto ao menu.</p>
        <a href="gestao_qrcodes.php">Abrir</a>
      </div>

      <div class="dash-card">
        <h3>📋 Gestão de Restaurante</h3>
        <p>Alterar a imagem da planta do restaurante e as respetivas informações do estabelecimento.</p>
        <a href="gestao_restaurante.php">Abrir</a>
      </div>

    </section>

  </main>

</div>

<script>
const notificationBtn = document.getElementById("notificationBtn");
const notificationDropdown = document.getElementById("notificationDropdown");

notificationBtn.addEventListener("click", function(){
  notificationDropdown.classList.toggle("active");
});

document.addEventListener("click", function(e){
  if(
    !notificationBtn.contains(e.target) &&
    !notificationDropdown.contains(e.target)
  ){
    notificationDropdown.classList.remove("active");
  }
});
</script>

<script src="assets/keep_session.js"></script>
<script src="assets/notifications.js"></script>
</body>
</html>
<?php
// config/db.php — Ligação à base de dados MySQL

// Definir fuso horário de Portugal — ajusta automaticamente
// entre horário de verão (UTC+1) e inverno (UTC+0)
date_default_timezone_set('Europe/Lisbon');

define('DB_HOST', 'sql113.infinityfree.com');
define('DB_USER', 'if0_41785314');
define('DB_PASS', 'HUmbihlzX4l9');
define('DB_NAME', 'if0_41785314_smarttable');

// Criar ligação MySQLi
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Verificar se a ligação foi bem-sucedida
if ($conn->connect_error) {
    die('Erro de ligação: ' . $conn->connect_error);
}

// Definir conjunto de caracteres para UTF-8
$conn->set_charset('utf8mb4');

// Sincronizar o fuso horário da sessão MySQL com a hora actual de Lisboa
// (calcula automaticamente o offset correto, incluindo horário de verão)
$offset = date('P'); // ex: "+01:00" no verão, "+00:00" no inverno
$conn->query("SET time_zone = '$offset'");
<?php
require_once "error_config.php";

require_once "auth_check.php";

/* Recuperação resiliente da mesa: se a sessão PHP se perder
   (ex: tablet a limpar cookies, recarregar do zero por inatividade),
   tentamos restaurar a mesa a partir de um cookie próprio, separado
   do PHPSESSID, desde que a mesa continue realmente ocupada na BD.
   Isto evita que o cliente seja "expulso" de volta à seleção de mesa
   e perca a noção da sua conta, mesmo que os pedidos continuem
   intactos na base de dados. */
if (!isset($_SESSION["mesa_numero"]) && !empty($_COOKIE["smarttable_mesa"])) {
    $recoveredMesa = intval($_COOKIE["smarttable_mesa"]);
    if ($recoveredMesa > 0) {
        $stmtRecover = $conn->prepare("SELECT status FROM `tables` WHERE number = ? LIMIT 1");
        $stmtRecover->bind_param("i", $recoveredMesa);
        $stmtRecover->execute();
        $recoverInfo = $stmtRecover->get_result()->fetch_assoc();
        if (($recoverInfo["status"] ?? "livre") === "ocupada") {
            $_SESSION["mesa_numero"] = $recoveredMesa;
        }
    }
}

if (!isset($_SESSION["mesa_numero"])) {
    header("Location: mesa_dashboard.php");
    exit;
}

$mesaNumero = intval($_SESSION["mesa_numero"]);

/* Manter o cookie de recuperação sempre atualizado enquanto a mesa
   estiver ativa (90 dias é mais do que suficiente — só serve como
   rede de segurança, a mesa real é controlada pela BD). */
setcookie("smarttable_mesa", (string)$mesaNumero, [
    "expires"  => time() + 90 * 24 * 60 * 60,
    "path"     => "/",
    "secure"   => false,
    "httponly" => true,
    "samesite" => "Lax",
]);

if (!isset($_SESSION["cart"])) {
    $_SESSION["cart"] = [];
}

/* Estado da mesa */
$stmt = $conn->prepare("
    SELECT main_unlocked, dessert_unlocked, main_delivered_at, occupied_seats
    FROM `tables` WHERE number = ? LIMIT 1
");
$stmt->bind_param("i", $mesaNumero);
$stmt->execute();
$tableAccess = $stmt->get_result()->fetch_assoc();

$mainUnlocked    = intval($tableAccess["main_unlocked"]    ?? 0);
$dessertUnlocked = intval($tableAccess["dessert_unlocked"] ?? 0);
$numPessoas      = intval($tableAccess["occupied_seats"]   ?? 0);
$mainDeliveredAt = $tableAccess["main_delivered_at"]       ?? null;
$canRequestPayment = !empty($mainDeliveredAt);
$dessertWarning = false;
if (!empty($mainDeliveredAt)) {
    $minutesAfterMain = floor((time() - strtotime($mainDeliveredAt)) / 60);
    if ($minutesAfterMain < 5) $dessertWarning = true;
}

/* Pedidos já enviados desta mesa */
$sentOrders = [];
$sentTotal  = 0;
try {
    $colCheck2 = $conn->query("SHOW COLUMNS FROM order_items")->fetch_all(MYSQLI_ASSOC);
    $colNames2 = array_column($colCheck2, 'Field');
    $hasCustom = in_array('customization', $colNames2);
    $hasCat    = in_array('category', $colNames2);
    $selCustom = $hasCustom ? "oi.customization" : "'' AS customization";
    $selCat    = $hasCat ? "oi.category" : "'outro' AS category";

    $ss = $conn->prepare("
        SELECT o.id, o.status, o.created_at, oi.name, oi.quantity, oi.subtotal, $selCustom, $selCat
        FROM orders o
        JOIN order_items oi ON oi.order_id = o.id
        WHERE o.table_number = ? AND o.status NOT IN ('pago','cancelado')
        ORDER BY o.created_at ASC, oi.id ASC
    ");
    $ss->bind_param("i", $mesaNumero);
    $ss->execute();
    $sr = $ss->get_result();
    while ($row = $sr->fetch_assoc()) {
        $sentOrders[] = $row;
        $sentTotal   += floatval($row["subtotal"]);
    }
} catch (Exception $e) {
    $sentOrders = [];
    $sentTotal  = 0;
}

/* O pagamento só pode ser pedido depois do prato principal ser
   marcado como entregue pelo empregado de mesa (main_delivered_at definido) */

$staffPin   = "1234"; // TODO: alterar para um PIN próprio antes de usar em produção
$tabletError = "";

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["unlock_tablet"])) {
    $pin = trim($_POST["staff_pin"] ?? "");
    if (hash_equals($staffPin, $pin)) {
        unset($_SESSION["mesa_numero"], $_SESSION["cart"]);
        setcookie("smarttable_mesa", "", ["expires" => time() - 3600, "path" => "/"]);
        header("Location: mesa_dashboard.php");
        exit;
    } else {
        $tabletError = "PIN incorreto.";
    }
}

/* Adicionar item */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["add_item"])) {
    $itemId = intval($_POST["item_id"] ?? 0);
    $stmt = $conn->prepare("SELECT id,name,description,category,price FROM menus WHERE id=? AND status='disponivel' LIMIT 1");
    $stmt->bind_param("i", $itemId);
    $stmt->execute();
    $item = $stmt->get_result()->fetch_assoc();

    if ($item) {
        $category  = strtolower(trim($item["category"]));
        $isMain    = str_contains($category, "prato");
        $isDessert = str_contains($category, "sobremesa");

        if ($isMain    && !$mainUnlocked)    { header("Location: menu_dashboard.php?erro=prato_bloqueado");    exit; }
        if ($isDessert && !$dessertUnlocked) { header("Location: menu_dashboard.php?erro=sobremesa_bloqueada"); exit; }

        $customParts = [];
        $extraCost   = 0.0;
        $opts = $_POST["custom_opts"] ?? [];
        if (is_array($opts)) foreach ($opts as $opt) $customParts[] = trim($opt);

        $extraDefs = [
            "batata_frita"  => ["+ batata frita", 0.50],
            "arroz"         => ["+ arroz", 0.40],
            "salada_extra"  => ["+ salada extra", 0.60],
            "molho_extra"   => ["+ molho extra", 0.30],
            "queijo_extra"  => ["+ queijo extra", 0.50],
            "gelo_extra"    => ["+ gelo extra", 0.00],
            "rodela_limao"  => ["+ rodela limão", 0.00],
            "palinha"       => ["+ palinha", 0.00],
        ];
        $extras = $_POST["extras"] ?? [];
        if (is_array($extras)) {
            foreach ($extras as $ek) {
                if (isset($extraDefs[$ek])) {
                    $customParts[] = $extraDefs[$ek][0];
                    $extraCost    += $extraDefs[$ek][1];
                }
            }
        }

        $customStr  = implode("|", $customParts);
        $finalPrice = floatval($item["price"]) + $extraCost;
        $cartKey    = $itemId . "_" . md5($customStr);

        if (isset($_SESSION["cart"][$cartKey])) {
            $_SESSION["cart"][$cartKey]["quantity"]++;
        } else {
            $_SESSION["cart"][$cartKey] = [
                "id"            => intval($item["id"]),
                "name"          => $item["name"],
                "category"      => $category,
                "price"         => $finalPrice,
                "quantity"      => 1,
                "customization" => $customStr,
            ];
        }
    }

    $activeCategory = trim($_POST["active_category"] ?? "entrada");
    if (!in_array($activeCategory, ["entrada","bebida","prato","sobremesa"])) $activeCategory = "entrada";
    header("Location: menu_dashboard.php?cat=" . urlencode($activeCategory));
    exit;
}

/* Mais quantidade */
if (isset($_GET["plus"])) {
    $key = urldecode($_GET["plus"]);
    if (isset($_SESSION["cart"][$key])) $_SESSION["cart"][$key]["quantity"]++;
    $cat = trim($_GET["cat"] ?? "entrada");
    if (!in_array($cat, ["entrada","bebida","prato","sobremesa"])) $cat = "entrada";
    header("Location: menu_dashboard.php?cat=" . urlencode($cat));
    exit;
}

/* Menos quantidade */
if (isset($_GET["minus"])) {
    $key = urldecode($_GET["minus"]);
    if (isset($_SESSION["cart"][$key])) {
        $_SESSION["cart"][$key]["quantity"]--;
        if ($_SESSION["cart"][$key]["quantity"] <= 0) unset($_SESSION["cart"][$key]);
    }
    $cat = trim($_GET["cat"] ?? "entrada");
    if (!in_array($cat, ["entrada","bebida","prato","sobremesa"])) $cat = "entrada";
    header("Location: menu_dashboard.php?cat=" . urlencode($cat));
    exit;
}

/* Enviar pedido */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["send_order"])) {
    if (!empty($_SESSION["cart"])) {
        $total = 0;
        foreach ($_SESSION["cart"] as $ci) $total += $ci["price"] * $ci["quantity"];

        $colCheck = $conn->query("SHOW COLUMNS FROM order_items")->fetch_all(MYSQLI_ASSOC);
        $colNames = array_column($colCheck, 'Field');
        if (!in_array('customization', $colNames)) $conn->query("ALTER TABLE order_items ADD COLUMN customization TEXT DEFAULT NULL");
        if (!in_array('category',      $colNames)) $conn->query("ALTER TABLE order_items ADD COLUMN category VARCHAR(50) DEFAULT 'outro'");

        $conn->query("CREATE TABLE IF NOT EXISTS bar_orders (
            id INT AUTO_INCREMENT PRIMARY KEY, order_id INT NOT NULL,
            table_number VARCHAR(20) NOT NULL, item_name VARCHAR(255) NOT NULL,
            quantity INT NOT NULL DEFAULT 1, customization TEXT DEFAULT NULL,
            status ENUM('pendente','preparando','pronto') NOT NULL DEFAULT 'pendente',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        )");

        $stmt = $conn->prepare("INSERT INTO orders (table_number,total,status,created_at) VALUES (?,?,'enviado',NOW())");
        $stmt->bind_param("id", $mesaNumero, $total);
        $stmt->execute();
        $orderId = $stmt->insert_id;

        $hasBebida = false;
        foreach ($_SESSION["cart"] as $ci) {
            $name     = $ci["name"];
            $qty      = intval($ci["quantity"]);
            $sub      = $ci["price"] * $qty;
            $custom   = $ci["customization"] ?? "";
            $cat      = $ci["category"] ?? "outro";
            $s = $conn->prepare("INSERT INTO order_items (order_id,name,quantity,subtotal,customization,category) VALUES (?,?,?,?,?,?)");
            $s->bind_param("isidss", $orderId, $name, $qty, $sub, $custom, $cat);
            $s->execute();
            if (str_contains(strtolower($cat), "bebida")) {
                $hasBebida = true;
                $b = $conn->prepare("INSERT INTO bar_orders (order_id,table_number,item_name,quantity,customization) VALUES (?,?,?,?,?)");
                $tn = (string)$mesaNumero;
                $b->bind_param("issis", $orderId, $tn, $name, $qty, $custom);
                $b->execute();
            }
        }

        if ($hasBebida && !$mainUnlocked) {
            $u = $conn->prepare("UPDATE `tables` SET main_unlocked=1, entries_drinks_delivered_at=NOW() WHERE number=?");
            $u->bind_param("i", $mesaNumero);
            $u->execute();
        }

        $_SESSION["cart"] = [];
        header("Location: menu_dashboard.php?ok=pedido_enviado");
        exit;
    }
}

/* Pedir pagamento */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["request_payment"])) {
    if (!$canRequestPayment) { header("Location: menu_dashboard.php?erro=pagamento_bloqueado"); exit; }

    /* Garantir que a coluna payment_code existe na tabela orders */
    $colOrders = $conn->query("SHOW COLUMNS FROM orders")->fetch_all(MYSQLI_ASSOC);
    $colOrdersNames = array_column($colOrders, 'Field');
    if (!in_array('payment_code', $colOrdersNames)) {
        $conn->query("ALTER TABLE orders ADD COLUMN payment_code VARCHAR(50) DEFAULT NULL");
    }

    $paymentCode = "ST-" . $mesaNumero . "-" . rand(1000, 9999);
    $stmt = $conn->prepare("UPDATE orders SET status='pagamento', payment_code=? WHERE table_number=? AND status NOT IN ('pago','cancelado','pagamento')");
    $stmt->bind_param("si", $paymentCode, $mesaNumero);
    $stmt->execute();

    if ($stmt->affected_rows === 0) {
        $stmt2 = $conn->prepare("UPDATE orders SET status='pagamento', payment_code=? WHERE table_number=? AND status NOT IN ('pago','cancelado')");
        $stmt2->bind_param("si", $paymentCode, $mesaNumero);
        $stmt2->execute();
    }

    header("Location: menu_dashboard.php?payment_code=" . urlencode($paymentCode));
    exit;
}

/* Buscar menus */
$menuItems = $conn->query("SELECT * FROM menus WHERE status='disponivel' ORDER BY category ASC, name ASC");

$cartTotal = 0;
$cartCount = 0;
foreach ($_SESSION["cart"] as $ci) {
    $cartTotal += $ci["price"] * $ci["quantity"];
    $cartCount += $ci["quantity"];
}

/* Aviso de quantidade excessiva */
$overOrderWarnings = [];
if ($numPessoas > 0) {
    foreach ($_SESSION["cart"] as $ci) {
        if ($ci["quantity"] > $numPessoas) {
            $overOrderWarnings[] = "\"" . htmlspecialchars($ci["name"]) . "\" — " . $ci["quantity"] . "x para " . $numPessoas . " pessoa(s).";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>SmartTable - Menu</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" type="image/png" href="assets/favicon.png">
<link rel="icon" type="image/x-icon" href="assets/favicon.ico">
<link rel="apple-touch-icon" href="assets/logo.png">
<?php include_once __DIR__ . "/theme.php"; ?>
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:Georgia,"Times New Roman",serif}
body{min-height:100vh;background:linear-gradient(90deg,rgba(201,168,76,.04) 1px,transparent 1px),linear-gradient(rgba(201,168,76,.03) 1px,transparent 1px),radial-gradient(circle at top left,rgba(201,168,76,.18),transparent 35%),linear-gradient(135deg,var(--dark),#080300 70%);background-size:80px 80px,80px 80px,cover,cover;color:var(--cream)}
.header{padding:26px 42px;display:flex;justify-content:space-between;align-items:center;background:rgba(13,6,0,.78);border-bottom:1px solid rgba(201,168,76,.25)}
.brand{display:flex;align-items:center;gap:14px}
.brand span{font-size:11px;letter-spacing:4px;color:var(--gold-light)}
.brand h1{font-size:30px}
.table-box{padding:13px 18px;border-radius:999px;border:1px solid rgba(201,168,76,.25);background:rgba(13,6,0,.65);color:var(--cream2)}
.main{padding:38px}
.subtitle{color:var(--gold-light);letter-spacing:8px;font-size:13px;margin-bottom:8px}
.title{font-size:48px;margin-bottom:24px}
.msg{padding:15px 18px;border-radius:16px;margin-bottom:22px;background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.35);color:#86efac;font-weight:bold}
.msg.error{background:rgba(239,68,68,.12);border-color:rgba(239,68,68,.35);color:#fca5a5}
.flow-info{padding:18px 20px;border-radius:18px;margin-bottom:24px;background:rgba(201,168,76,.10);border:1px solid rgba(201,168,76,.25);color:var(--cream2);line-height:1.6}
.flow-info strong{color:var(--gold-light)}
.layout{display:grid;grid-template-columns:1fr 360px;gap:26px;align-items:start}
.category-buttons{display:flex;flex-wrap:wrap;gap:14px;margin-bottom:26px}
.category-buttons button{padding:14px 22px;border:none;border-radius:16px;background:linear-gradient(135deg,var(--gold),var(--gold-light));color:#140900;font-weight:bold;cursor:pointer;font-size:15px}
.category-buttons button.active{box-shadow:0 0 0 3px rgba(232,201,122,.25);transform:translateY(-2px)}
.menu-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:24px}
.menu-card{border:1px solid rgba(201,168,76,.28);border-radius:24px;background:linear-gradient(145deg,rgba(38,21,8,.82),rgba(13,6,0,.96));overflow:hidden}
.menu-content{padding:22px}
.menu-category{color:var(--gold-light);font-size:12px;letter-spacing:4px;margin-bottom:10px;text-transform:uppercase}
.menu-title{font-size:26px;margin-bottom:10px}
.menu-description{color:rgba(245,234,216,.68);line-height:1.5;margin-bottom:18px}
.menu-bottom{display:flex;justify-content:space-between;align-items:center;gap:14px}
.price{color:var(--gold-light);font-size:22px;font-weight:bold}
.add-btn{padding:12px 18px;border:none;border-radius:14px;background:linear-gradient(135deg,var(--gold),var(--gold-light));color:#140900;font-weight:bold;cursor:pointer}
.item-locked{opacity:.65;position:relative;pointer-events:none}
.item-locked::after{content:'';position:absolute;inset:0;border-radius:inherit;background:rgba(13,6,0,.35)}
.locked-item-btn{display:block;width:100%;padding:10px;text-align:center;font-size:12px;color:rgba(245,234,216,.45);border:1px dashed rgba(201,168,76,.2);border-radius:12px;background:transparent}
/* SIDEBAR */
.cart-sidebar{background:linear-gradient(145deg,rgba(38,21,8,.86),rgba(13,6,0,.96));border:1px solid rgba(201,168,76,.28);border-radius:24px;padding:24px;position:sticky;top:24px}
.cart-header{margin-bottom:16px}
.cart-header h2{font-size:28px;color:var(--gold-light)}
.cart-header p{color:rgba(245,234,216,.6);font-size:13px}
.sent-orders-label{font-size:11px;font-weight:bold;letter-spacing:2px;color:rgba(245,234,216,.45);margin:10px 0 6px;text-transform:uppercase}
.cart-items{display:flex;flex-direction:column;gap:12px}
.cart-item{padding:14px;border-radius:16px;background:rgba(13,6,0,.48);border:1px solid rgba(201,168,76,.14)}
.sent-item{opacity:.8}
.sent-item h4{color:rgba(245,234,216,.75)}
.cart-top{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}
.cart-item h4{font-size:16px;margin-bottom:4px}
.cart-price{color:var(--gold-light);font-size:14px}
.cart-controls{display:flex;align-items:center;gap:8px;flex-shrink:0}
.qty-btn{width:30px;height:30px;border-radius:8px;background:linear-gradient(135deg,var(--gold),var(--gold-light));color:#140900;display:flex;align-items:center;justify-content:center;text-decoration:none;font-weight:bold;font-size:18px}
.qty{color:var(--cream);font-weight:bold;min-width:20px;text-align:center}
.cart-subtotal{margin-top:8px;color:rgba(245,234,216,.6);font-size:13px}
.cart-total{margin-top:16px;padding:14px 18px;border-radius:14px;background:rgba(201,168,76,.12);border:1px solid rgba(201,168,76,.25);display:flex;justify-content:space-between;align-items:center;color:var(--gold-light);font-size:20px;font-weight:bold}
.cart-actions{margin-top:14px;display:grid;gap:10px}
.send-btn,.pay-btn{width:100%;padding:14px;border:none;border-radius:14px;background:linear-gradient(135deg,var(--gold),var(--gold-light));color:#140900;font-weight:bold;cursor:pointer;font-size:15px}
.pay-btn{background:rgba(34,197,94,.16);border:1px solid rgba(34,197,94,.35);color:#86efac}
.pay-btn.locked{opacity:.45;cursor:not-allowed;background:rgba(148,163,184,.14);border:1px solid rgba(148,163,184,.25);color:#cbd5e1}
.empty-cart{padding:28px 10px;text-align:center}
.empty-icon{font-size:44px;margin-bottom:14px}
.empty-cart h3{color:var(--gold-light);margin-bottom:10px}
.empty-cart p{color:rgba(245,234,216,.6);line-height:1.5}
.hidden{display:none !important}
.overorder-warning{margin:10px 0;padding:10px 14px;border-radius:10px;background:rgba(245,158,11,.12);border:1px solid rgba(245,158,11,.35);color:#fbbf24;font-size:12px;line-height:1.5}
.cbadge{padding:2px 7px;border-radius:999px;font-size:10px;font-weight:bold;display:inline-block}
.cbadge.sem{background:rgba(239,68,68,.15);border:1px solid rgba(239,68,68,.3);color:#fca5a5}
.cbadge.com{background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.25);color:#86efac}
.cbadge.extra{background:rgba(245,158,11,.12);border:1px solid rgba(245,158,11,.25);color:#fbbf24}
.cbadge.outro{background:rgba(148,163,184,.1);border:1px solid rgba(148,163,184,.2);color:#cbd5e1}
/* staff modal */
.staff-unlock-box{margin-top:40px;display:flex;justify-content:flex-end}
.staff-unlock-trigger{padding:12px 18px;border-radius:999px;border:1px solid rgba(201,168,76,.22);background:rgba(13,6,0,.55);color:rgba(245,234,216,.55);cursor:pointer}
.staff-modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.72);z-index:9999;align-items:center;justify-content:center;padding:20px}
.staff-modal.active{display:flex}
.staff-modal-card{width:100%;max-width:420px;padding:28px;border-radius:24px;background:linear-gradient(145deg,rgba(38,21,8,.98),rgba(13,6,0,.98));border:1px solid rgba(201,168,76,.28)}
.staff-modal-card h3{color:var(--gold-light);font-size:28px;margin-bottom:12px}
.staff-modal-card p{color:rgba(245,234,216,.65);line-height:1.5;margin-bottom:18px}
.staff-modal-card input{width:100%;padding:14px 16px;border-radius:14px;border:1px solid rgba(201,168,76,.25);background:rgba(13,6,0,.75);color:var(--cream);margin-bottom:14px}
.staff-modal-card button{width:100%;padding:14px;border:none;border-radius:14px;background:linear-gradient(135deg,var(--gold),var(--gold-light));color:#140900;font-weight:bold;cursor:pointer;margin-bottom:10px}
.cancel-btn{background:rgba(239,68,68,.14)!important;border:1px solid rgba(239,68,68,.35)!important;color:#fca5a5!important}
.staff-error{padding:12px 14px;margin-bottom:14px;border-radius:14px;background:rgba(239,68,68,.14);border:1px solid rgba(239,68,68,.35);color:#fca5a5}
/* personalização modal */
.custom-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.72);z-index:1000;align-items:center;justify-content:center;padding:16px}
.custom-overlay.open{display:flex}
.custom-modal{background:linear-gradient(145deg,rgba(38,21,8,.97),rgba(13,6,0,.99));border:1px solid rgba(201,168,76,.3);border-radius:24px;padding:28px;max-width:480px;width:100%;max-height:90vh;overflow-y:auto}
.custom-modal h3{color:var(--gold-light);font-size:24px;margin-bottom:4px}
.custom-modal .item-price{color:rgba(245,234,216,.5);font-size:14px;margin-bottom:22px}
.custom-section{margin-bottom:20px}
.custom-section h4{font-size:12px;letter-spacing:3px;color:rgba(245,234,216,.45);margin-bottom:12px}
.opts-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.opt-label{display:flex;align-items:center;gap:8px;padding:10px 12px;border-radius:10px;border:1px solid rgba(201,168,76,.18);background:rgba(13,6,0,.4);cursor:pointer;font-size:13px;color:var(--cream2)}
.opt-label input{accent-color:var(--gold,#c9a84c)}
.opt-label.sem-opt{border-color:rgba(239,68,68,.2)}
.opt-label.com-opt{border-color:rgba(34,197,94,.2)}
.opt-label.extra-opt{border-color:rgba(245,158,11,.2)}
.opt-label.extra-opt .extra-price{margin-left:auto;color:var(--gold-light);font-size:11px}
.modal-actions{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:24px}
.btn-cancel-modal{padding:13px;border-radius:12px;border:1px solid rgba(201,168,76,.25);background:transparent;color:var(--cream2);cursor:pointer;font-size:14px}
.btn-confirm-modal{padding:13px;border-radius:12px;border:none;background:linear-gradient(135deg,var(--gold,#c9a84c),var(--gold-light,#e8c97a));color:#140900;font-weight:bold;cursor:pointer;font-size:14px}
@media(max-width:1000px){.layout{grid-template-columns:1fr}.cart-sidebar{position:static}}
@media(max-width:760px){.header{flex-direction:column;align-items:flex-start;gap:18px;padding:24px 18px}.main{padding:24px 18px}.title{font-size:36px}.menu-grid{grid-template-columns:1fr}}

@media(max-width:760px){}

</style>
<link rel="stylesheet" href="assets/responsive_global.css">
</head>
<body>

<header class="header">
  <div class="brand">
    <a href="index.php" style="text-decoration:none"><img src="assets/logo.png" alt="SmartTable" style="height:120px;width:auto;object-fit:contain"></a>
    <div>
      <span>RESTAURANT MANAGEMENT</span>
      <h1 data-notranslate="true">SmartTable</h1>
    </div>
  </div></header>

<main class="main">
  <p class="subtitle">MENU DIGITAL</p>
  <h2 class="title">Escolha o seu pedido</h2>

  <?php if (isset($_GET["ok"])): ?><div class="msg">Pedido enviado com sucesso.</div><?php endif; ?>
  <?php if (isset($_GET["payment_code"])): ?>
    <div class="msg">Dirija-se à caixa para pagar.<br>Código: <strong><?= htmlspecialchars($_GET["payment_code"]) ?></strong></div>
  <?php endif; ?>
  <?php if (isset($_GET["erro"])): ?>
    <div class="msg error">
      <?php if ($_GET["erro"]==="prato_bloqueado") echo "O prato principal ainda está bloqueado.";
      elseif ($_GET["erro"]==="sobremesa_bloqueada") echo "A sobremesa ainda está bloqueada.";
      elseif ($_GET["erro"]==="pagamento_bloqueado") echo "Só pode pedir pagamento depois do prato principal ser entregue.";
      else echo "Ocorreu um erro."; ?>
    </div>
  <?php endif; ?>

  <div class="flow-info">
    <?php if (!$mainUnlocked): ?>
      🍹 Peça as suas <strong>entradas e/ou bebidas</strong>. Após enviar o pedido com uma bebida, os pratos ficam disponíveis.
    <?php elseif (!$dessertUnlocked): ?>
      🍽️ <strong>Pratos disponíveis!</strong> A sobremesa ficará disponível depois do prato ser entregue.
    <?php else: ?>
      🍰 <strong>Tudo disponível.</strong> Pode pedir sobremesas.
    <?php endif; ?>
  </div>

  <div class="layout">
    <section>
      <div class="category-buttons">
        <button type="button" data-filter="entrada" onclick="showCategory('entrada')">Entradas</button>
        <button type="button" data-filter="bebida" onclick="showCategory('bebida')">Bebidas</button>
        <button type="button" data-filter="prato" onclick="showCategory('prato')"
          <?= !$mainUnlocked ? 'title="Disponível após escolher bebidas"' : '' ?>>
          Pratos Principais<?= !$mainUnlocked ? ' 🔒' : '' ?>
        </button>
        <button type="button" data-filter="sobremesa" onclick="showCategory('sobremesa')"
          <?= !$dessertUnlocked ? 'title="Disponível após o prato ser entregue"' : '' ?>>
          Sobremesas<?= !$dessertUnlocked ? ' 🔒' : '' ?>
        </button>
      </div>

      <section class="menu-grid">
        <?php if ($menuItems && $menuItems->num_rows > 0): ?>
          <?php while($item = $menuItems->fetch_assoc()):
            $category  = strtolower(trim($item["category"]));
            $isMain    = str_contains($category, "prato");
            $isDessert = str_contains($category, "sobremesa");
            $isLocked  = ($isMain && !$mainUnlocked) || ($isDessert && !$dessertUnlocked);
            if (str_contains($category,"entrada"))       $filterCategory="entrada";
            elseif (str_contains($category,"bebida"))    $filterCategory="bebida";
            elseif (str_contains($category,"prato"))     $filterCategory="prato";
            elseif (str_contains($category,"sobremesa")) $filterCategory="sobremesa";
            else                                         $filterCategory=$category;
          ?>
          <article class="menu-card menu-item<?= $isLocked?' item-locked':'' ?>" data-category="<?= htmlspecialchars($filterCategory) ?>">
            <div class="menu-content">
              <div class="menu-category"><?= htmlspecialchars($item["category"]) ?></div>
              <h3 class="menu-title"><?= htmlspecialchars($item["name"]) ?></h3>
              <p class="menu-description"><?= htmlspecialchars($item["description"]) ?></p>
              <div class="menu-bottom">
                <span class="price"><?= number_format((float)$item["price"],2,",",".") ?> €</span>
                <?php if ($isLocked): ?>
                  <span class="locked-item-btn">🔒 <?= $isDessert?"Disponível depois do prato":"Disponível após bebidas" ?></span>
                <?php else: ?>
                  <button type="button" class="add-btn" onclick="openCustomModal(<?= htmlspecialchars($item['id']) ?>,'<?= addslashes(htmlspecialchars($item['name'])) ?>','<?= addslashes(htmlspecialchars($filterCategory)) ?>','<?= number_format((float)$item['price'],2,',','.') ?>')">+ Adicionar</button>
                <?php endif; ?>
              </div>
            </div>
          </article>
          <?php endwhile; ?>
        <?php endif; ?>
      </section>
    </section>

    <!-- SIDEBAR -->
    <aside class="cart-sidebar">
      <div class="cart-header">
        <h2>Conta da Mesa</h2>
        <?php if ($numPessoas > 0): ?><p><?= $numPessoas ?> pessoa(s)</p><?php endif; ?>
      </div>

      <?php if (!empty($overOrderWarnings)): ?>
        <div class="overorder-warning"><strong>⚠️ Atenção</strong><ul><?php foreach($overOrderWarnings as $w): ?><li><?= $w ?></li><?php endforeach; ?></ul></div>
      <?php endif; ?>

      <?php if (!empty($sentOrders)): ?>
        <div class="sent-orders-label">✅ Pedidos enviados</div>
        <div class="cart-items">
          <?php foreach($sentOrders as $si): ?>
          <div class="cart-item sent-item">
            <div class="cart-top">
              <div>
                <h4><?= htmlspecialchars($si["name"]) ?></h4>
                <?php if (!empty($si["customization"])): ?>
                  <div style="display:flex;flex-wrap:wrap;gap:3px;margin-top:3px">
                    <?php foreach(explode("|",$si["customization"]) as $opt): $opt=trim($opt); if(!$opt) continue;
                      $cls=str_starts_with($opt,"sem ")?"cbadge sem":(str_starts_with($opt,"com ")?"cbadge com":(str_starts_with($opt,"+")?"cbadge extra":"cbadge outro")); ?>
                    <span class="<?= $cls ?>"><?= htmlspecialchars($opt) ?></span>
                    <?php endforeach; ?>
                  </div>
                <?php endif; ?>
              </div>
              <span class="qty" style="flex-shrink:0"><?= intval($si["quantity"]) ?>x</span>
            </div>
            <div class="cart-subtotal">Subtotal: <strong><?= number_format(floatval($si["subtotal"]),2,",",".") ?> €</strong></div>
          </div>
          <?php endforeach; ?>
        </div>
        <div class="cart-total" style="background:rgba(34,197,94,.08);border-color:rgba(34,197,94,.2);font-size:16px">
          <span>Já pedido</span><strong><?= number_format($sentTotal,2,",",".") ?> €</strong>
        </div>
      <?php endif; ?>

      <?php if (!empty($_SESSION["cart"])): ?>
        <div class="sent-orders-label" style="margin-top:14px">🛒 A adicionar ao pedido</div>
        <div class="cart-items">
          <?php foreach($_SESSION["cart"] as $cartKey => $ci):
            $sub = $ci["price"] * $ci["quantity"];
            $enc = urlencode($cartKey); ?>
          <div class="cart-item">
            <div class="cart-top">
              <div>
                <h4><?= htmlspecialchars($ci["name"]) ?></h4>
                <span class="cart-price"><?= number_format($ci["price"],2,",",".") ?> €</span>
              </div>
              <div class="cart-controls">
                <a href="menu_dashboard.php?minus=<?= $enc ?>" class="qty-btn">−</a>
                <span class="qty"><?= htmlspecialchars($ci["quantity"]) ?></span>
                <a href="menu_dashboard.php?plus=<?= $enc ?>" class="qty-btn">+</a>
              </div>
            </div>
            <div class="cart-subtotal">Subtotal: <strong><?= number_format($sub,2,",",".") ?> €</strong></div>
          </div>
          <?php endforeach; ?>
        </div>
        <div class="cart-total"><span>Novo pedido</span><strong><?= number_format($cartTotal,2,",",".") ?> €</strong></div>
      <?php endif; ?>

      <?php if (empty($sentOrders) && empty($_SESSION["cart"])): ?>
        <div class="empty-cart">
          <div class="empty-icon">🍽️</div>
          <h3>Nenhum item selecionado</h3>
          <p>Adicione entradas, bebidas ou pratos para começar o seu pedido.</p>
        </div>
      <?php endif; ?>

      <?php if (!empty($sentOrders) || !empty($_SESSION["cart"])): ?>
        <?php $totalGeral = $sentTotal + $cartTotal; ?>
        <div class="cart-total" style="margin-top:8px;background:rgba(201,168,76,.15)">
          <span>Total geral</span><strong><?= number_format($totalGeral,2,",",".") ?> €</strong>
        </div>
      <?php endif; ?>

      <div class="cart-actions">
        <form method="POST">
          <button type="submit" name="send_order" class="send-btn">Enviar Pedido</button>
        </form>
        <?php if ($canRequestPayment): ?>
          <form method="POST"><button type="submit" name="request_payment" class="pay-btn">Quero Pagar</button></form>
        <?php else: ?>
          <button type="button" class="pay-btn locked" onclick="alert('Só pode pedir pagamento depois do prato principal ser entregue.')">Quero Pagar</button>
        <?php endif; ?>
      </div>
    </aside>
  </div>

  <div class="staff-unlock-box">
    <button type="button" onclick="openStaffUnlock()" class="staff-unlock-trigger">Área do Empregado de Mesa</button>
  </div>

  <div id="staffUnlockModal" class="staff-modal">
    <form method="POST" class="staff-modal-card">
      <h3>Trocar mesa deste tablet</h3>
      <p>Apenas o empregado de mesa pode libertar este tablet e escolher outra mesa.</p>
      <?php if (!empty($tabletError)): ?><div class="staff-error"><?= htmlspecialchars($tabletError) ?></div><?php endif; ?>
      <input type="password" name="staff_pin" placeholder="PIN do empregado de mesa" required>
      <button type="submit" name="unlock_tablet">Libertar tablet</button>
      <button type="button" onclick="closeStaffUnlock()" class="cancel-btn">Cancelar</button>
    </form>
  </div>
</main>

<div class="custom-overlay" id="customOverlay">
  <div class="custom-modal">
    <h3 id="modal-item-name">Item</h3>
    <div class="item-price" id="modal-item-price"></div>
    <form method="POST" id="customForm">
      <input type="hidden" name="item_id" id="modal-item-id">
      <input type="hidden" name="active_category" id="modal-active-cat">
      <input type="hidden" name="add_item" value="1">
      <div class="custom-section" id="section-prato">
        <h4>REMOVER / ALTERAR</h4>
        <div class="opts-grid">
          <label class="opt-label sem-opt"><input type="checkbox" name="custom_opts[]" value="sem batata frita"> sem batata frita</label>
          <label class="opt-label sem-opt"><input type="checkbox" name="custom_opts[]" value="sem arroz"> sem arroz</label>
          <label class="opt-label sem-opt"><input type="checkbox" name="custom_opts[]" value="sem salada"> sem salada</label>
          <label class="opt-label sem-opt"><input type="checkbox" name="custom_opts[]" value="sem molho"> sem molho</label>
          <label class="opt-label com-opt"><input type="checkbox" name="custom_opts[]" value="bem passado"> bem passado</label>
          <label class="opt-label com-opt"><input type="checkbox" name="custom_opts[]" value="mal passado"> mal passado</label>
          <label class="opt-label com-opt"><input type="checkbox" name="custom_opts[]" value="sem glúten"> sem glúten</label>
          <label class="opt-label com-opt"><input type="checkbox" name="custom_opts[]" value="vegetariano"> vegetariano</label>
        </div>
        <h4 style="margin-top:16px">EXTRAS</h4>
        <div class="opts-grid">
          <label class="opt-label extra-opt"><input type="checkbox" name="extras[]" value="batata_frita"> + batata frita <span class="extra-price">+0,50€</span></label>
          <label class="opt-label extra-opt"><input type="checkbox" name="extras[]" value="arroz"> + arroz <span class="extra-price">+0,40€</span></label>
          <label class="opt-label extra-opt"><input type="checkbox" name="extras[]" value="salada_extra"> + salada extra <span class="extra-price">+0,60€</span></label>
          <label class="opt-label extra-opt"><input type="checkbox" name="extras[]" value="molho_extra"> + molho extra <span class="extra-price">+0,30€</span></label>
          <label class="opt-label extra-opt"><input type="checkbox" name="extras[]" value="queijo_extra"> + queijo extra <span class="extra-price">+0,50€</span></label>
        </div>
      </div>
      <div class="custom-section" id="section-bebida" style="display:none">
        <h4>PERSONALIZAR BEBIDA</h4>
        <div class="opts-grid">
          <label class="opt-label sem-opt"><input type="checkbox" name="custom_opts[]" value="sem gelo"> sem gelo</label>
          <label class="opt-label com-opt"><input type="checkbox" name="custom_opts[]" value="com gelo"> com gelo</label>
          <label class="opt-label sem-opt"><input type="checkbox" name="custom_opts[]" value="sem limão"> sem limão</label>
          <label class="opt-label com-opt"><input type="checkbox" name="custom_opts[]" value="com limão"> com limão</label>
          <label class="opt-label sem-opt"><input type="checkbox" name="custom_opts[]" value="sem açúcar"> sem açúcar</label>
          <label class="opt-label com-opt"><input type="checkbox" name="custom_opts[]" value="com açúcar"> com açúcar</label>
          <label class="opt-label com-opt"><input type="checkbox" name="custom_opts[]" value="bem fresca"> bem fresca</label>
          <label class="opt-label com-opt"><input type="checkbox" name="custom_opts[]" value="temperatura ambiente"> temperatura ambiente</label>
        </div>
        <h4 style="margin-top:16px">EXTRAS</h4>
        <div class="opts-grid">
          <label class="opt-label extra-opt"><input type="checkbox" name="extras[]" value="gelo_extra"> + gelo extra <span class="extra-price">grátis</span></label>
          <label class="opt-label extra-opt"><input type="checkbox" name="extras[]" value="rodela_limao"> + rodela limão <span class="extra-price">grátis</span></label>
          <label class="opt-label extra-opt"><input type="checkbox" name="extras[]" value="palinha"> + palinha <span class="extra-price">grátis</span></label>
        </div>
      </div>
      <div class="custom-section" id="section-outro">
        <h4>OBSERVAÇÕES</h4>
        <div class="opts-grid">
          <label class="opt-label sem-opt"><input type="checkbox" name="custom_opts[]" value="sem alergénios"> sem alergénios</label>
          <label class="opt-label com-opt"><input type="checkbox" name="custom_opts[]" value="para partilhar"> para partilhar</label>
        </div>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn-cancel-modal" onclick="closeCustomModal()">Cancelar</button>
        <button type="submit" class="btn-confirm-modal">✓ Adicionar ao pedido</button>
      </div>
    </form>
  </div>
</div>

<script>
function showCategory(cat){
  document.querySelectorAll(".menu-item").forEach(i=>i.classList.toggle("hidden",i.dataset.category!==cat));
  document.querySelectorAll(".category-buttons button").forEach(b=>b.classList.remove("active"));
  const btn=document.querySelector('[data-filter="'+cat+'"]');
  if(btn) btn.classList.add("active");
}
function openStaffUnlock(){document.getElementById("staffUnlockModal").classList.add("active")}
function closeStaffUnlock(){document.getElementById("staffUnlockModal").classList.remove("active")}
document.addEventListener("DOMContentLoaded",function(){
  const cat=new URLSearchParams(window.location.search).get("cat")||"entrada";
  showCategory(cat);
});
document.querySelectorAll(".qty-btn").forEach(function(link){
  link.addEventListener("click",function(e){
    e.preventDefault();
    const cat=new URLSearchParams(window.location.search).get("cat")||"entrada";
    window.location.href=this.getAttribute("href")+"&cat="+encodeURIComponent(cat);
  });
});
function openCustomModal(id,name,category,price){
  document.getElementById('modal-item-id').value=id;
  document.getElementById('modal-active-cat').value=category;
  document.getElementById('modal-item-name').textContent=name;
  document.getElementById('modal-item-price').textContent=price+' €';
  const isPrato=category==='prato', isBebida=category==='bebida';
  document.getElementById('section-prato').style.display=isPrato?'':'none';
  document.getElementById('section-bebida').style.display=isBebida?'':'none';
  document.getElementById('section-outro').style.display=(!isPrato&&!isBebida)?'':'none';
  document.querySelectorAll('#customForm input[type=checkbox]').forEach(c=>c.checked=false);
  document.getElementById('customOverlay').classList.add('open');
}
function closeCustomModal(){document.getElementById('customOverlay').classList.remove('open')}
document.getElementById('customOverlay').addEventListener('click',function(e){if(e.target===this)closeCustomModal()});
document.querySelector('.custom-modal').addEventListener('click',e=>e.stopPropagation());
</script>
<script src="assets/keep_session.js"></script>

</body>
</html>
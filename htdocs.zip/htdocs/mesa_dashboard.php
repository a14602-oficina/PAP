<?php
require_once "error_config.php";

require_once "auth_check.php";
require_once "service_flow.php";

st_ensure_service_flow_columns($conn);
st_reset_service_flow_for_free_tables($conn);

/* Esta página serve para ESCOLHER uma mesa (uso do empregado de mesa
   ao preparar o tablet, ou QR code lido pela primeira vez). Depois de
   uma mesa estar associada à sessão do tablet, o cliente nunca deve
   voltar aqui sozinho — só o empregado de mesa, com PIN, pode trocar
   de mesa (via "Libertar tablet" em menu_dashboard.php).

   Se já existe uma mesa ativa na sessão, qualquer acesso a esta
   página (direto, QR relido, ou re-submissão do formulário) é
   simplesmente reencaminhado para o menu — nunca reprocessado. */
if (!empty($_SESSION["mesa_numero"])) {
    header("Location: menu_dashboard.php");
    exit;
}

/* QR Code: aceitar ?mesa=N via GET (cliente lê QR com telemóvel) */
if (isset($_GET["mesa"]) && intval($_GET["mesa"]) > 0) {
    $novaM = intval($_GET["mesa"]);

    /* Verificar se a mesa está ocupada */
    $stmtQR = $conn->prepare("SELECT status FROM `tables` WHERE number = ? LIMIT 1");
    $stmtQR->bind_param("i", $novaM);
    $stmtQR->execute();
    $infoQR = $stmtQR->get_result()->fetch_assoc();

    if (($infoQR["status"] ?? "livre") !== "ocupada") {
        /* Mesa livre — redirecionar com erro */
        header("Location: mesa_dashboard.php?mesa_erro=" . $novaM);
        exit;
    }

    $_SESSION["mesa_numero"] = $novaM;
    if (!isset($_SESSION["cart"])) {
        $_SESSION["cart"] = [];
    }

    /* Só limpa pedidos anteriores se a mesa NÃO tiver nenhum pedido
       ativo na base de dados — nunca cancela uma conta já em curso,
       mesmo que a sessão do browser se tenha perdido (ex: tablet
       a recarregar a página por inatividade). */
    $stmtHasOrders = $conn->prepare("
        SELECT COUNT(*) AS n FROM orders
        WHERE table_number = ? AND status NOT IN ('pago','cancelado')
    ");
    $stmtHasOrders->bind_param("i", $novaM);
    $stmtHasOrders->execute();
    $hasOrders = intval($stmtHasOrders->get_result()->fetch_assoc()["n"] ?? 0) > 0;

    if (!$hasOrders) {
        $stmtClean = $conn->prepare("UPDATE orders SET status='cancelado' WHERE table_number=? AND status NOT IN ('pago','cancelado','pagamento')");
        $stmtClean->bind_param("i", $novaM);
        $stmtClean->execute();
    }

    header("Location: menu_dashboard.php");
    exit;
}

$mesaErro = "";

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["mesa_numero"])) {
    $novaM = intval($_POST["mesa_numero"]);

    /* Verificar se a mesa está ocupada */
    $stmtCheck = $conn->prepare("SELECT status FROM `tables` WHERE number = ? LIMIT 1");
    $stmtCheck->bind_param("i", $novaM);
    $stmtCheck->execute();
    $mesaInfo = $stmtCheck->get_result()->fetch_assoc();
    $mesaStatus = $mesaInfo["status"] ?? "livre";

    if ($mesaStatus !== "ocupada") {
        /* Mesa não está ocupada — bloquear */
        $mesaErro = $novaM;
    } else {
        /* Mesa ocupada — pode prosseguir */
        $_SESSION["mesa_numero"] = $novaM;
        if (!isset($_SESSION["cart"])) {
            $_SESSION["cart"] = [];
        }

        /* Só limpa pedidos anteriores se a mesa NÃO tiver nenhum pedido
           ativo na base de dados — nunca cancela uma conta já em curso,
           mesmo que a sessão do browser se tenha perdido. */
        $stmtHasOrders = $conn->prepare("
            SELECT COUNT(*) AS n FROM orders
            WHERE table_number = ? AND status NOT IN ('pago','cancelado')
        ");
        $stmtHasOrders->bind_param("i", $novaM);
        $stmtHasOrders->execute();
        $hasOrders = intval($stmtHasOrders->get_result()->fetch_assoc()["n"] ?? 0) > 0;

        if (!$hasOrders) {
            $stmtClean = $conn->prepare("
                UPDATE orders
                SET status = 'cancelado'
                WHERE table_number = ?
                AND status NOT IN ('pago','cancelado','pagamento')
            ");
            $stmtClean->bind_param("i", $novaM);
            $stmtClean->execute();

            $stmtBarClean = $conn->prepare("
                UPDATE bar_orders SET status = 'pronto'
                WHERE table_number = ? AND status IN ('pendente','preparando')
            ");
            $stmtBarClean->bind_param("s", $novaM);
            $stmtBarClean->execute();
        }

        header("Location: menu_dashboard.php");
        exit;
    } /* fecha else */
}

$tables = $conn->query("
    SELECT *
    FROM `tables`
    ORDER BY `number` ASC
");
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>SmartTable - Selecionar Mesa</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="favicon.ico" sizes="any">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="apple-touch-icon" href="assets/logo.png">
<link rel="manifest" href="site.webmanifest">
<meta name="theme-color" content="#0d0600">

<link rel="stylesheet" href="assets/responsive.css">
<link rel="stylesheet" href="assets/responsive_global.css">

<?php include_once __DIR__ . "/theme.php"; ?>

<style>
*{
  margin:0;
  padding:0;
  box-sizing:border-box;
}

body{
  min-height:100vh;
  font-family:"Cormorant Garamond", Georgia, serif;
  background:
    linear-gradient(90deg,rgba(201,168,76,.04) 1px,transparent 1px),
    linear-gradient(rgba(201,168,76,.03) 1px,transparent 1px),
    radial-gradient(circle at top left,rgba(201,168,76,.18),transparent 35%),
    linear-gradient(135deg,var(--dark),#080300 70%);
  background-size:80px 80px,80px 80px,cover,cover;
  color:var(--cream);
}

.header{
  padding:30px 46px;
  border-bottom:1px solid rgba(201,168,76,.2);
  background:rgba(13,6,0,.78);
}

.brand{
  display:flex;
  align-items:center;
  gap:14px;
}

.logo{
  width:58px;
  height:58px;
  border-radius:16px;
  background:linear-gradient(135deg,var(--gold),var(--gold-light));
  color:#140900;
  display:flex;
  align-items:center;
  justify-content:center;
  font-size:30px;
  font-weight:bold;
}

.brand span{
  color:var(--gold-light);
  letter-spacing:5px;
  font-size:12px;
}

.brand h1{
  font-size:32px;
  line-height:1;
}

.main{
  padding:42px;
}

.subtitle{
  color:var(--gold-light);
  letter-spacing:9px;
  font-size:13px;
  margin-bottom:8px;
}

h2{
  font-size:56px;
  margin-bottom:34px;
}

.panel{
  border:1px solid rgba(201,168,76,.28);
  border-radius:28px;
  background:linear-gradient(145deg,rgba(38,21,8,.78),rgba(13,6,0,.94));
  padding:34px;
  box-shadow:0 18px 55px rgba(0,0,0,.35);
}

.room-title{
  color:rgba(245,234,216,.65);
  letter-spacing:5px;
  font-size:14px;
  margin-bottom:34px;
}

.tables-grid{
  display:grid;
  grid-template-columns:repeat(auto-fill,minmax(120px,1fr));
  gap:14px;
}

.table-form{
  width:100%;
}

.table-button{
  width:100%;
  background:none;
  border:none;
  cursor:pointer;
  color:inherit;
  font-family:inherit;
  padding:0;
}

.table-button:disabled{
  cursor:not-allowed;
}

.table-card{
  border-radius:16px;
  border:2px solid rgba(201,168,76,.2);
  background:rgba(13,6,0,.55);
  display:flex;
  flex-direction:column;
  align-items:center;
  justify-content:center;
  gap:3px;
  position:relative;
  padding:14px 10px 12px;
  overflow:hidden;
  text-align:center;
  transition:.22s ease;
  min-height:100px;
}

.table-card:hover{
  transform:translateY(-3px);
  box-shadow:0 12px 32px rgba(0,0,0,.35);
}

.table-card.livre{
  border-color:rgba(34,197,94,.5);
  background:rgba(34,197,94,.06);
}

.table-card.ocupada{
  border-color:rgba(239,68,68,.5);
  background:rgba(239,68,68,.06);
  opacity:.85;
}

.table-card.reservada{
  border-color:rgba(245,158,11,.5);
  background:rgba(245,158,11,.06);
  opacity:.85;
}

.table-card.redonda .mesa-btn-visual,




.table-card.manutencao{
  border-color:rgba(100,116,139,.4);
  background:rgba(100,116,139,.06);
  opacity:.6;
  cursor:not-allowed;
}

.mesa-dot{
  position:absolute;
  top:8px;
  right:8px;
  width:10px;
  height:10px;
  border-radius:50%;
}

.table-card.livre .mesa-dot{
  background:#22c55e;
  box-shadow:0 0 8px rgba(34,197,94,.6);
}

.table-card.ocupada .mesa-dot{
  background:#ef4444;
  box-shadow:0 0 8px rgba(239,68,68,.6);
}

.table-card.reservada .mesa-dot{
  background:#f59e0b;
}

.table-card.manutencao .mesa-dot{
  background:#64748b;
}

.mesa-num{
  font-size:26px;
  font-weight:bold;
  color:var(--cream);
  line-height:1;
}

.mesa-occ{
  font-size:11px;
  color:rgba(245,234,216,.45);
  line-height:1.3;
}

.mesa-lugares{
  font-size:11px;
  color:rgba(245,234,216,.55);
  line-height:1.3;
}

@media(max-width:1400px){
  .tables-grid{
    grid-template-columns:repeat(auto-fill,minmax(110px,1fr));
  }
}

@media(max-width:600px){
  .header{
    padding:24px 18px;
  }

  .main{
    padding:26px 18px;
  }

  h2{
    font-size:38px;
  }

  .panel{
    padding:20px;
  }

  .tables-grid{
    grid-template-columns:repeat(auto-fill,minmax(90px,1fr));
    gap:10px;
  }

  .mesa-num{
    font-size:22px;
  }
}
</style>
</head>

<body>

<header class="header">
  <div class="brand">
    <a href="index.php" style="text-decoration:none"><img src="assets/logo.png" alt="SmartTable" style="height:120px;width:auto;object-fit:contain"></a>

    <div>
      <span>RESTAURANT MANAGEMENT</span>
      <h1>SmartTable</h1>
    </div>
  </div>
</header>

<main class="main">

  <p class="subtitle">TABLET DAS MESAS</p>
  <h2>Escolha a sua mesa</h2>

  <section class="panel">
    <p class="room-title">SALA PRINCIPAL · MAPA DE MESAS</p>

    <div class="tables-grid">

      <?php if ($tables && $tables->num_rows > 0): ?>

        <?php while($mesa = $tables->fetch_assoc()): ?>

          <?php
            $capacity = intval($mesa["capacity"] ?? 0);
            $occupied = intval($mesa["occupied_seats"] ?? 0);
            $status = $mesa["status"] ?? "livre";
            $type = $mesa["type_table"] ?? "quadrada";
            $disabled = $status === "manutencao";
          ?>

          <form method="POST" class="table-form">
            <input type="hidden" name="mesa_numero" value="<?= htmlspecialchars($mesa["number"]) ?>">

            <button
              type="submit"
              class="table-button"
              <?= $disabled ? "disabled" : "" ?>
            >
              <div class="table-card <?= htmlspecialchars($status) ?>">
                <span class="mesa-dot"></span>
                <span class="mesa-num"><?= htmlspecialchars($mesa["number"]) ?></span>
                <span class="mesa-occ"><?= $occupied ?>/<?= $capacity ?> ocupados</span>
                <span class="mesa-lugares"><?= $capacity ?> lugares</span>
              </div>
            </button>
          </form>

        <?php endwhile; ?>

      <?php else: ?>

        <p>Nenhuma mesa encontrada.</p>

      <?php endif; ?>

    </div>
  </section>

</main>

<script src="assets/keep_session.js"></script>

<!-- Modal de mesa não ocupada -->
<div id="mesaErroModal" style="display:<?= ($mesaErro || isset($_GET["mesa_erro"])) ? 'flex' : 'none' ?>;position:fixed;inset:0;background:rgba(0,0,0,.75);z-index:9999;align-items:center;justify-content:center;padding:20px">
  <div style="background:linear-gradient(145deg,rgba(38,21,8,.98),rgba(13,6,0,.99));border:1px solid rgba(239,68,68,.35);border-radius:24px;padding:32px 28px;max-width:420px;width:100%;text-align:center;box-shadow:0 30px 80px rgba(0,0,0,.7)">
    <div style="font-size:52px;margin-bottom:16px">🚫</div>
    <h3 style="color:#fca5a5;font-size:24px;margin-bottom:12px">Mesa não disponível</h3>
    <p style="color:rgba(245,234,216,.65);line-height:1.6;margin-bottom:24px;font-size:14px">
      A <strong style="color:var(--cream)">Mesa <?= $mesaErro ?: htmlspecialchars($_GET["mesa_erro"] ?? "") ?></strong>
      não está ocupada.<br>
      Esta mesa não pode receber pedidos porque ainda não tem clientes sentados.<br>
      Ocupa primeiro a mesa na receção antes de entregar o tablet ao cliente.
    </p>
    <button
      onclick="document.getElementById('mesaErroModal').style.display='none'"
      style="width:100%;padding:14px;border:none;border-radius:14px;background:linear-gradient(135deg,#c9a84c,#e8c97a);color:#140900;font-weight:bold;cursor:pointer;font-size:15px;font-family:Georgia,serif">
      Percebido, voltar atrás
    </button>
  </div>
</div>

</body>
</html>
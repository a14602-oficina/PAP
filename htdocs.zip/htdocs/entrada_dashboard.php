<?php
require_once "error_config.php";

require_once "auth_check.php";

$msg     = "";
$msgType = "success";

function minimoPessoas($capacity){
    if ($capacity == 4) return 3;
    if ($capacity == 6) return 5;
    if ($capacity == 8) return 7;
    return 1;
}

/* Chamar gerente */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["call_manager"])) {
    $stmt = $conn->prepare("INSERT INTO manager_calls (table_number, message, status, created_at) VALUES (NULL, 'Cliente chamou o gerente na entrada', 'pendente', NOW())");
    if ($stmt->execute()) { header("Location: entrada_dashboard.php?msg=gerente"); exit; }
}

/* Escolher mesa */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["mesa_id"])) {
    $mesa_id = intval($_POST["mesa_id"] ?? 0);
    $pessoas = intval($_POST["pessoas"]  ?? 0);

    if ($mesa_id > 0 && $pessoas > 0) {
        $stmt = $conn->prepare("SELECT id, capacity, status FROM `tables` WHERE id = ?");
        $stmt->bind_param("i", $mesa_id);
        $stmt->execute();
        $mesa = $stmt->get_result()->fetch_assoc();

        if (!$mesa) {
            $msg = "Mesa não encontrada."; $msgType = "error";
        } elseif ($mesa["status"] !== "livre") {
            $msg = "Esta mesa já não está livre."; $msgType = "error";
        } else {
            $cap = intval($mesa["capacity"]);
            $min = minimoPessoas($cap);
            if ($pessoas < $min) {
                $msg = "Mínimo de $min pessoas para esta mesa."; $msgType = "error";
            } elseif ($pessoas > $cap) {
                $msg = "Máximo de $cap pessoas para esta mesa."; $msgType = "error";
            } else {
                $upd = $conn->prepare("UPDATE `tables` SET occupied_seats=?, status='ocupada', arrival_time=NOW(), main_unlocked=0, dessert_unlocked=0, entries_drinks_delivered_at=NULL, main_unlocked_at=NULL, main_delivered_at=NULL, dessert_unlocked_at=NULL WHERE id=?");
                $upd->bind_param("ii", $pessoas, $mesa_id);
                if ($upd->execute()) { header("Location: entrada_dashboard.php?msg=ok"); exit; }
            }
        }
    }
}

if (isset($_GET["msg"])) {
    if ($_GET["msg"] === "ok")      { $msg = "Mesa escolhida com sucesso! Dirija-se à sua mesa."; $msgType = "success"; }
    if ($_GET["msg"] === "gerente") { $msg = "Gerente chamado. Aguarde, por favor.";               $msgType = "info"; }
}

$result = $conn->query("SELECT * FROM `tables` ORDER BY `number` ASC");
$mesas  = [];
while ($r = $result->fetch_assoc()) $mesas[] = $r;
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>SmartTable — Entrada</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="favicon.ico" sizes="any">
<?php include_once __DIR__ . "/theme.php"; ?>
<style>
*{box-sizing:border-box;margin:0;padding:0;font-family:Georgia,"Times New Roman",serif}
body{min-height:100vh;color:var(--cream);background:linear-gradient(90deg,rgba(201,168,76,.04) 1px,transparent 1px),linear-gradient(rgba(201,168,76,.03) 1px,transparent 1px),radial-gradient(circle at top left,rgba(201,168,76,.18),transparent 35%),linear-gradient(135deg,var(--dark),#080300 70%);background-size:80px 80px,80px 80px,cover,cover}
.header{padding:22px 42px;display:flex;justify-content:space-between;align-items:center;background:rgba(13,6,0,.78);border-bottom:1px solid rgba(201,168,76,.2)}
.brand{display:flex;align-items:center;gap:14px}
.brand span{font-size:11px;letter-spacing:4px;color:var(--gold-light)}
.brand h1{font-size:26px}
.main{padding:36px 42px}
.subtitle{color:var(--gold-light);letter-spacing:8px;font-size:12px;margin-bottom:6px}
.page-title h2{font-size:44px;margin-bottom:28px}
.msg{padding:14px 18px;border-radius:14px;margin-bottom:24px;font-size:15px;font-weight:bold}
.msg.success{background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.35);color:#86efac}
.msg.error{background:rgba(239,68,68,.12);border:1px solid rgba(239,68,68,.35);color:#fca5a5}
.msg.info{background:rgba(201,168,76,.10);border:1px solid rgba(201,168,76,.28);color:var(--gold-light)}
.map-section{border:1px solid rgba(201,168,76,.25);border-radius:22px;background:linear-gradient(145deg,rgba(38,21,8,.82),rgba(13,6,0,.96));overflow:hidden;margin-bottom:28px}
.map-header{padding:20px 28px;border-bottom:1px solid rgba(201,168,76,.14);display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px}
.map-header h3{color:var(--gold-light);font-size:22px}
.map-img-wrap{padding:24px 28px;display:flex;align-items:center;justify-content:center;background:rgba(13,6,0,.3);min-height:220px}
.map-img-wrap img{max-width:100%;max-height:320px;border-radius:14px;border:1px solid rgba(201,168,76,.18);object-fit:contain}
.map-placeholder{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;color:rgba(245,234,216,.4);min-height:180px;width:100%;border:2px dashed rgba(201,168,76,.15);border-radius:14px}
.map-placeholder p{font-size:14px;letter-spacing:2px}
.legend{display:flex;gap:14px;flex-wrap:wrap;align-items:center}
.legend-item{display:flex;align-items:center;gap:6px;font-size:13px}
.dot{width:10px;height:10px;border-radius:50%;flex-shrink:0;display:inline-block}
.dot.livre{background:#22c55e}
.dot.ocupada{background:#ef4444}
.dot.reservada{background:#f59e0b}
.dot.manutencao{background:#64748b}
.tables-section{border:1px solid rgba(201,168,76,.25);border-radius:22px;background:linear-gradient(145deg,rgba(38,21,8,.82),rgba(13,6,0,.96));overflow:hidden;margin-bottom:28px}
.tables-header{padding:20px 28px;border-bottom:1px solid rgba(201,168,76,.14);display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px}
.tables-header h3{color:var(--gold-light);font-size:22px}
.tables-body{padding:28px}
.tables-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:16px}
.filter-bar{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:18px;align-items:center}
.filter-bar span{font-size:12px;letter-spacing:2px;color:rgba(245,234,216,.45);margin-right:4px}
.filter-btn{padding:8px 18px;border-radius:999px;border:1px solid rgba(201,168,76,.25);background:rgba(13,6,0,.55);color:rgba(245,234,216,.65);cursor:pointer;font-size:13px;font-family:Georgia,serif;transition:.18s}
.filter-btn:hover,.filter-btn.active{background:linear-gradient(135deg,var(--gold,#c9a84c),var(--gold-light,#e8c97a));color:#140900;border-color:transparent;font-weight:bold}
.mesa-btn{min-width:80px;min-height:100px;border-radius:14px;padding:12px;border:2px solid rgba(201,168,76,.2);background:rgba(13,6,0,.55);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;cursor:pointer;transition:.2s;position:relative;width:100%}
.mesa-btn.livre{border-color:rgba(34,197,94,.5);background:rgba(34,197,94,.06)}
.mesa-btn.livre:hover{background:rgba(34,197,94,.14);transform:translateY(-3px);box-shadow:0 12px 32px rgba(34,197,94,.18)}
.mesa-btn.ocupada{border-color:rgba(239,68,68,.45);background:rgba(239,68,68,.06);opacity:.7;cursor:not-allowed}
.mesa-btn.reservada{border-color:rgba(245,158,11,.45);background:rgba(245,158,11,.06);opacity:.7;cursor:not-allowed}
.mesa-btn.manutencao{border-color:rgba(100,116,139,.4);background:rgba(100,116,139,.06);opacity:.5;cursor:not-allowed}
.mesa-num{font-size:32px;font-weight:bold;color:var(--cream);line-height:1}
.mesa-cap{font-size:11px;color:rgba(245,234,216,.55)}
.mesa-occ{font-size:11px;color:rgba(245,234,216,.45)}
.mesa-type-badge{font-size:9px;letter-spacing:1px;color:rgba(201,168,76,.55);text-transform:uppercase}
.mesa-status-dot{position:absolute;top:8px;right:8px;width:10px;height:10px;border-radius:50%}
.livre .mesa-status-dot{background:#22c55e;box-shadow:0 0 8px rgba(34,197,94,.6)}
.ocupada .mesa-status-dot{background:#ef4444;box-shadow:0 0 8px rgba(239,68,68,.6)}
.reservada .mesa-status-dot{background:#f59e0b}
.manutencao .mesa-status-dot{background:#64748b}
.call-section{padding:24px 28px;border:1px solid rgba(239,68,68,.28);border-radius:22px;background:linear-gradient(135deg,rgba(80,10,5,.35),rgba(40,5,3,.5));display:flex;justify-content:space-between;align-items:center;gap:20px;flex-wrap:wrap}
.call-section h4{color:#ffb4ad;font-size:18px;margin-bottom:6px}
.call-section p{font-size:15px}
.manager-btn{padding:15px 28px;border-radius:16px;border:1px solid rgba(255,120,100,.35);background:linear-gradient(135deg,rgba(120,20,10,.95),rgba(90,10,5,.95));color:#ffb4ad;font-size:16px;font-weight:bold;cursor:pointer;font-family:Georgia,serif;transition:.2s;white-space:nowrap}
.manager-btn:hover{transform:translateY(-2px);box-shadow:0 10px 28px rgba(120,20,10,.4)}
.modal-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.75);z-index:9000;align-items:center;justify-content:center;padding:20px}
.modal-overlay.open{display:flex}
.modal{width:100%;max-width:420px;background:linear-gradient(145deg,rgba(38,21,8,.99),rgba(13,6,0,.99));border:1px solid rgba(201,168,76,.3);border-radius:24px;padding:32px;box-shadow:0 30px 80px rgba(0,0,0,.6)}
.modal h3{color:var(--gold-light);font-size:26px;margin-bottom:6px}
.mesa-info{font-size:14px;color:rgba(245,234,216,.55);margin-bottom:24px}
.people-control{display:flex;align-items:center;justify-content:center;gap:20px;margin-bottom:12px}
.ppl-btn{width:48px;height:48px;border-radius:14px;border:none;background:linear-gradient(135deg,var(--gold),var(--gold-light));color:#140900;font-size:28px;font-weight:bold;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:.15s}
.ppl-btn:disabled{opacity:.3;cursor:not-allowed}
.ppl-num{font-size:52px;font-weight:bold;color:var(--cream);min-width:70px;text-align:center;line-height:1}
.ppl-hint{text-align:center;font-size:13px;color:rgba(245,234,216,.45);margin-bottom:22px}
.modal-actions{display:grid;gap:10px}
.btn-confirm{padding:15px;border-radius:14px;border:none;background:linear-gradient(135deg,var(--gold),var(--gold-light));color:#140900;font-weight:bold;font-size:16px;cursor:pointer;font-family:Georgia,serif;transition:.2s}
.btn-confirm:hover{opacity:.9;transform:translateY(-1px)}
.btn-cancel{padding:14px;border-radius:14px;background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.28);color:#fca5a5;font-size:15px;cursor:pointer;font-family:Georgia,serif}
@media(max-width:900px){.header,.main{padding:18px}.page-title h2{font-size:34px}.tables-grid{grid-template-columns:repeat(auto-fill,minmax(90px,1fr));gap:12px}.call-section{flex-direction:column}.manager-btn{width:100%}}
</style>
</head>
<body>

<header class="header">
  <div class="brand">
    <a href="index.php" style="text-decoration:none"><img src="assets/logo.png" alt="SmartTable" style="height:120px;width:auto;object-fit:contain"></a>
    <div>
      <span>RESTAURANT MANAGEMENT</span>
      <h1>SmartTable</h1>
    </div>
  </div>
</header>

<main class="main" id="live-content">
  <div class="page-title">
    <p class="subtitle">TABLET DE ENTRADA</p>
    <h2>Selecione a sua mesa</h2>
  </div>

  <?php if ($msg !== ""): ?>
    <div class="msg <?= $msgType ?>"><?= $msg ?></div>
  <?php endif; ?>

  <!-- MAPA -->
  <div class="map-section">
    <div class="map-header">
      <h3>🗺️ Planta do Restaurante</h3>
      <div class="legend">
        <span class="legend-item"><i class="dot livre"></i> Livre</span>
        <span class="legend-item"><i class="dot ocupada"></i> Ocupada</span>
        <span class="legend-item"><i class="dot reservada"></i> Reservada</span>
        <span class="legend-item"><i class="dot manutencao"></i> Manutenção</span>
      </div>
    </div>
    <div class="map-img-wrap">
      <?php
        $mapFile = null;
        // Buscar a planta activa registada pela gestão do restaurante
        $mapRow = $conn->query("SELECT filename FROM restaurant_map ORDER BY uploaded_at DESC LIMIT 1")->fetch_assoc();
        if ($mapRow && !empty($mapRow['filename'])) {
          $candidate = 'uploads/' . $mapRow['filename'];
          if (file_exists($candidate)) { $mapFile = $candidate; }
        }
        // Fallback para nomes fixos, caso não exista registo na BD
        if (!$mapFile) {
          foreach (['uploads/mapa_restaurante.png','uploads/mapa_restaurante.jpg','uploads/mapa_restaurante.webp','uploads/planta.png','uploads/planta.jpg'] as $f) {
            if (file_exists($f)) { $mapFile = $f; break; }
          }
        }
      ?>
      <?php if ($mapFile): ?>
        <img src="<?= htmlspecialchars($mapFile) ?>" alt="Planta do restaurante">
      <?php else: ?>
        <div class="map-placeholder">
          <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#c9a84c" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/></svg>
          <p>PLANTA DO RESTAURANTE</p>
          <p style="font-size:12px;opacity:.6">Carregue uma imagem com o nome<br><strong>mapa_restaurante.png</strong> na pasta uploads/</p>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- GRID MESAS -->
  <div class="tables-section">
    <div class="tables-header">
      <h3>Mesas Disponíveis</h3>
      <?php
        $livres   = count(array_filter($mesas, fn($m) => $m['status']==='livre'));
        $ocupadas = count(array_filter($mesas, fn($m) => $m['status']==='ocupada'));
      ?>
      <div class="legend">
        <span class="legend-item" style="color:#86efac"><strong><?= $livres ?></strong> livres</span>
        <span class="legend-item" style="color:#fca5a5"><strong><?= $ocupadas ?></strong> ocupadas</span>
      </div>
    </div>
    <div class="tables-body">
      <div class="filter-bar">
        <span>TIPO:</span>
        <button type="button" class="filter-btn active" onclick="filtrarTipo('todos',this)">Todas</button>
        <button type="button" class="filter-btn" onclick="filtrarTipo('quadrada',this)">■ Quadrada</button>
        <button type="button" class="filter-btn" onclick="filtrarTipo('redonda',this)">● Redonda</button>
        <button type="button" class="filter-btn" onclick="filtrarTipo('retangular',this)">▬ Retangular</button>
      </div>

      <div class="tables-grid" id="mesasGrid">
        <?php foreach ($mesas as $mesa):
          $status  = $mesa['status'];
          $cap     = intval($mesa['capacity']);
          $occ     = intval($mesa['occupied_seats']);
          $min     = minimoPessoas($cap);
          $isLivre = $status === 'livre';
          $tipo    = strtolower($mesa['type_table'] ?? 'quadrada');
          $icone   = $tipo === 'redonda' ? '● Redonda' : ($tipo === 'retangular' ? '▬ Retang.' : '■ Quadrada');
        ?>
          <button
            type="button"
            class="mesa-btn <?= htmlspecialchars($status) ?>"
            data-tipo="<?= htmlspecialchars($tipo) ?>"
            <?php if ($isLivre): ?>
            data-id="<?= $mesa['id'] ?>"
            data-num="<?= $mesa['number'] ?>"
            data-cap="<?= $cap ?>"
            data-min="<?= $min ?>"
            onclick="openModal(this)"
            <?php else: ?>
            disabled
            <?php endif; ?>
          >
            <span class="mesa-status-dot"></span>
            <span class="mesa-num"><?= $mesa['number'] ?></span>
            <span class="mesa-occ"><?= $occ ?>/<?= $cap ?> ocupados</span>
            <span class="mesa-type-badge"><?= $icone ?></span>
            <span class="mesa-cap"><?= $cap ?> lugares</span>
          </button>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <!-- CHAMAR GERENTE -->
  <div class="call-section">
    <div>
      <h4>Não encontrou mesa disponível?</h4>
      <p>Chame o gerente para organizar uma alternativa.</p>
    </div>
    <form method="POST">
      <button type="submit" name="call_manager" class="manager-btn">Chamar Gerente</button>
    </form>
  </div>
</main>

<!-- MODAL -->
<div class="modal-overlay" id="modalOverlay">
  <div class="modal">
    <h3>Mesa <span id="modalNum">—</span></h3>
    <p class="mesa-info" id="modalInfo">—</p>
    <div class="people-control">
      <button type="button" class="ppl-btn" id="btnMinus" onclick="changePpl(-1)">−</button>
      <span class="ppl-num" id="pplNum">1</span>
      <button type="button" class="ppl-btn" id="btnPlus" onclick="changePpl(+1)">+</button>
    </div>
    <p class="ppl-hint" id="pplHint">—</p>
    <form method="POST" id="modalForm" class="modal-actions">
      <input type="hidden" name="mesa_id" id="modalMesaId">
      <input type="hidden" name="pessoas" id="modalPessoas">
      <button type="submit" class="btn-confirm">✔ Confirmar Mesa</button>
      <button type="button" class="btn-cancel" onclick="closeModal()">Cancelar</button>
    </form>
  </div>
</div>

<script>
var _min=1,_max=1,_ppl=1;

/* openModal — chamado directamente pelo onclick inline no botão */
function openModal(btn) {
  _min = parseInt(btn.dataset.min);
  _max = parseInt(btn.dataset.cap);
  _ppl = _min;
  document.getElementById('modalNum').textContent  = btn.dataset.num;
  document.getElementById('modalInfo').textContent = 'Capacidade: ' + _max + ' pessoas';
  document.getElementById('modalMesaId').value     = btn.dataset.id;
  document.getElementById('pplHint').textContent   = 'Mínimo ' + _min + ' · Máximo ' + _max + ' pessoas';
  updatePpl();
  document.getElementById('modalOverlay').classList.add('open');
}

function closeModal() {
  document.getElementById('modalOverlay').classList.remove('open');
}

function changePpl(d) {
  _ppl = Math.min(_max, Math.max(_min, _ppl + d));
  updatePpl();
}

function updatePpl() {
  document.getElementById('pplNum').textContent  = _ppl;
  document.getElementById('modalPessoas').value  = _ppl;
  document.getElementById('btnMinus').disabled   = (_ppl <= _min);
  document.getElementById('btnPlus').disabled    = (_ppl >= _max);
}

/* Fechar ao clicar fora */
document.getElementById('modalOverlay').addEventListener('click', function(e){
  if (e.target === this) closeModal();
});

/* Filtro por tipo */
function filtrarTipo(tipo, btn) {
  document.querySelectorAll('.filter-btn').forEach(function(b){ b.classList.remove('active'); });
  if (btn) btn.classList.add('active');
  document.querySelectorAll('.mesa-btn').forEach(function(b){
    b.style.display = (tipo === 'todos' || b.dataset.tipo === tipo) ? '' : 'none';
  });
}
</script>

<script src="assets/auto_refresh.js"></script>
<script src="assets/keep_session.js"></script>

</body>
</html>
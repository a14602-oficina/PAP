<?php
/**
 * SmartTable — Configuração de Sessão estável
 * Cookies sem Secure para funcionar tanto em http como https no InfinityFree.
 * Incluir antes de session_start().
 */
if (session_status() !== PHP_SESSION_NONE) return;

$SMARTTABLE_SESSION_LIFETIME = 7 * 24 * 60 * 60; // 7 dias

@ini_set('session.gc_maxlifetime', (string)$SMARTTABLE_SESSION_LIFETIME);
@ini_set('session.cookie_lifetime', (string)$SMARTTABLE_SESSION_LIFETIME);
@ini_set('session.use_strict_mode', '0');
@ini_set('session.use_only_cookies', '1');

session_set_cookie_params([
    'lifetime' => $SMARTTABLE_SESSION_LIFETIME,
    'path'     => '/',
    'secure'   => false,
    'httponly' => true,
    'samesite' => 'Lax',
]);
?>

<?php
require_once "error_config.php";

require_once "auth_check.php";
require_once "service_flow.php";
st_ensure_service_flow_columns($conn);
st_reset_service_flow_for_free_tables($conn);

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "admin") {
    header("Location: login.php");
    exit;
}

$adminName = $_SESSION["name"] ?? "Administrador";
$msg = "";

/* Verificar colunas existentes */
function columnExists($conn, $table, $column) {
    $table = $conn->real_escape_string($table);
    $column = $conn->real_escape_string($column);

    $result = $conn->query("SHOW COLUMNS FROM `$table` LIKE '$column'");

    return $result && $result->num_rows > 0;
}

/* LIBERTAR TODAS AS MESAS */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["free_all_tables"])) {

    $set = [
        "`status` = 'livre'",
        "`occupied_seats` = 0"
    ];

    $optionalColumns = [
        "people_count" => "0",
        "current_order_id" => "NULL",
        "current_payment_code" => "NULL",
        "selected_at" => "NULL",
        "arrival_time" => "NULL",
        "entries_drinks_delivered_at" => "NULL",
        "main_unlocked" => "0",
        "main_unlocked_at" => "NULL",
        "main_delivered_at" => "NULL",
        "dessert_unlocked" => "0",
        "dessert_unlocked_at" => "NULL"
    ];

    foreach ($optionalColumns as $column => $value) {
        if (columnExists($conn, "tables", $column)) {
            $set[] = "`$column` = $value";
        }
    }

    $sql = "UPDATE `tables` SET " . implode(", ", $set);
    $conn->query($sql);
    st_reset_service_flow_for_all_tables($conn);

    if ($conn->query("SHOW TABLES LIKE 'orders'")->num_rows > 0) {
        $conn->query("
            UPDATE orders
            SET status = 'finalizado'
            WHERE status NOT IN ('pago','cancelado','finalizado')
        ");
    }

    header("Location: gestao_mesas.php?success=mesas_livres");
    exit;
}

/* ADICIONAR MESA */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["add_table"])) {
    $number = intval($_POST["number"] ?? 0);
    $capacity = intval($_POST["capacity"] ?? 0);
    $status = trim($_POST["status"] ?? "livre");
    $type_table = trim($_POST["type_table"] ?? "quadrada");

    if ($number <= 0 || $capacity <= 0) {
        $msg = "Número e capacidade são obrigatórios.";
    } else {
        $check = $conn->prepare("SELECT id FROM `tables` WHERE `number` = ? LIMIT 1");
        $check->bind_param("i", $number);
        $check->execute();
        $exists = $check->get_result()->fetch_assoc();

        if ($exists) {
            $msg = "Já existe uma mesa com o número $number.";
        } else {
            $stmt = $conn->prepare("
                INSERT INTO `tables` 
                (`number`, `capacity`, `occupied_seats`, `status`, `type_table`)
                VALUES (?, ?, 0, ?, ?)
            ");
            $stmt->bind_param("iiss", $number, $capacity, $status, $type_table);

            $msg = $stmt->execute()
                ? "Mesa adicionada com sucesso."
                : "Erro ao adicionar mesa.";
        }
    }
}

/* EDITAR MESA */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["edit_table"])) {
    $id = intval($_POST["id"] ?? 0);
    $number = intval($_POST["number"] ?? 0);
    $capacity = intval($_POST["capacity"] ?? 0);
    $occupied_seats = intval($_POST["occupied_seats"] ?? 0);
    $status = trim($_POST["status"] ?? "livre");
    $type_table = trim($_POST["type_table"] ?? "quadrada");

    if ($id <= 0 || $number <= 0 || $capacity <= 0) {
        $msg = "Dados inválidos.";
    } elseif ($occupied_seats > $capacity) {
        $msg = "O número de ocupados não pode ser maior que a capacidade.";
    } else {
        $check = $conn->prepare("
            SELECT id 
            FROM `tables`
            WHERE `number` = ?
            AND id != ?
            LIMIT 1
        ");
        $check->bind_param("ii", $number, $id);
        $check->execute();
        $exists = $check->get_result()->fetch_assoc();

        if ($exists) {
            $msg = "Já existe uma mesa com o número $number.";
        } else {
            $stmt = $conn->prepare("
                UPDATE `tables`
                SET
                    `number` = ?,
                    `capacity` = ?,
                    `occupied_seats` = ?,
                    `status` = ?,
                    `type_table` = ?
                WHERE id = ?
            ");
            $stmt->bind_param("iiissi", $number, $capacity, $occupied_seats, $status, $type_table, $id);

            if ($stmt->execute()) {
                if ($status === "livre") {
                    st_reset_table_service_flow($conn, $number);
                }
                $msg = "Mesa atualizada com sucesso.";
            } else {
                $msg = "Erro ao atualizar mesa.";
            }
        }
    }
}

/* REMOVER MESA */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["delete_table"])) {
    $id = intval($_POST["id"] ?? 0);

    if ($id > 0) {
        $stmt = $conn->prepare("DELETE FROM `tables` WHERE `id` = ?");
        $stmt->bind_param("i", $id);

        $msg = $stmt->execute()
            ? "Mesa removida com sucesso."
            : "Erro ao remover mesa.";
    }
}

if (isset($_GET["success"]) && $_GET["success"] === "mesas_livres") {
    $msg = "Todas as mesas foram libertadas com sucesso.";
}

/* LISTAR MESAS */
$result = $conn->query("
    SELECT *
    FROM `tables`
    ORDER BY `number` ASC
");
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>SmartTable - Gestão de Mesas</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="favicon.ico" sizes="any">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="apple-touch-icon" href="assets/logo.png">
<link rel="manifest" href="site.webmanifest">
<meta name="theme-color" content="#0d0600">

<?php include_once __DIR__ . "/theme.php"; ?>
<style>

*{
  margin:0;
  padding:0;
  box-sizing:border-box;
  font-family:Georgia,"Times New Roman",serif;
}

body{
  min-height:100vh;
  background:
    linear-gradient(90deg,rgba(201,168,76,.04) 1px,transparent 1px),
    linear-gradient(rgba(201,168,76,.03) 1px,transparent 1px),
    radial-gradient(circle at top left,rgba(201,168,76,.18),transparent 35%),
    linear-gradient(135deg,var(--dark),#080300 70%);
  background-size:80px 80px,80px 80px,cover,cover;
  color:var(--cream);
}

.admin-layout{display:block;margin:0;padding:0}

.brand h2{
  font-size:22px;
  line-height:1;
}

.brand span{
  font-size:11px;
  color:rgba(245,234,216,.55);
  letter-spacing:3px;
}

.content{
  flex:1;
  padding:34px 46px;
  overflow-x:auto;

  margin-left:0;
}

.topbar{
  display:flex;
  align-items:flex-start;
  justify-content:space-between;
  gap:24px;
  margin-bottom:36px;
}

.subtitle{
  color:var(--gold-light);
  letter-spacing:8px;
  font-size:13px;
  margin-bottom:6px;
}

.topbar h1{
  font-size:46px;
  line-height:1;
  color:var(--cream);
}

.session{
  padding:14px 22px;
  border-radius:999px;
  border:1px solid rgba(201,168,76,.25);
  background:rgba(13,6,0,.65);
  color:var(--cream2);
  white-space:nowrap;
}

.msg{
  padding:16px;
  border-radius:14px;
  margin-bottom:24px;
  background:rgba(34,197,94,.12);
  border:1px solid rgba(34,197,94,.35);
  color:#86efac;
  font-weight:bold;
}

.panel{
  border:1px solid rgba(201,168,76,.25);
  border-radius:24px;
  background:linear-gradient(145deg,rgba(38,21,8,.82),rgba(13,6,0,.95));
  overflow:hidden;
  box-shadow:0 18px 55px rgba(0,0,0,.35);
  margin-bottom:28px;
}

.panel-header{
  padding:22px 28px;
  border-bottom:1px solid rgba(201,168,76,.15);
  display:flex;
  justify-content:space-between;
  align-items:center;
  gap:20px;
}

.panel-header h2{
  color:var(--gold-light);
  font-size:28px;
}

.form-grid{
  padding:28px;
  display:grid;
  grid-template-columns:repeat(4,1fr);
  gap:18px;
}

.form-group{
  display:flex;
  flex-direction:column;
}

.form-group.full{
  grid-column:1 / -1;
}

label{
  margin-bottom:8px;
  color:var(--cream2);
  font-size:14px;
}

input,
select{
  padding:12px;
  border-radius:12px;
  border:1px solid rgba(201,168,76,.25);
  background:rgba(13,6,0,.72);
  color:var(--cream);
  outline:none;
}

button{
  padding:12px;
  border:none;
  border-radius:12px;
  background:linear-gradient(135deg,var(--gold),var(--gold-light));
  color:#140900;
  font-weight:bold;
  cursor:pointer;
}

.free-all-btn{
  width:100%;
  margin-bottom:18px;
  padding:14px 18px;
  border-radius:16px;
  background:linear-gradient(135deg,#dc2626,#ef4444);
  color:white;
}

.legend{
  display:flex;
  gap:14px;
  flex-wrap:wrap;
  color:var(--cream2);
  font-size:14px;
}

.legend span{
  display:flex;
  align-items:center;
  gap:7px;
}

.dot{
  width:10px;
  height:10px;
  border-radius:50%;
  display:inline-block;
}

.dot.livre{background:#22c55e}
.dot.ocupada{background:#ef4444}
.dot.reservada{background:#f59e0b}
.dot.manutencao{background:#64748b}

.room{
  margin:28px;
  padding:34px;
  border-radius:22px;
  border:1px solid rgba(201,168,76,.22);
  background:
    radial-gradient(circle at 15% 20%,rgba(201,168,76,.10),transparent 22%),
    linear-gradient(145deg,rgba(13,6,0,.65),rgba(38,21,8,.55));
}

.room-title{
  color:rgba(245,234,216,.6);
  font-size:14px;
  margin-bottom:28px;
  letter-spacing:3px;
}

.tables-grid{
  display:grid;
  grid-template-columns:repeat(auto-fill,minmax(220px,1fr));
  gap:24px;
}

/* ── VISUAL DA MESA (estilo entrada_dashboard) ── */
.table-card{
  border-radius:18px;
  border:1px solid rgba(201,168,76,.16);
  background:rgba(13,6,0,.35);
  display:flex;
  flex-direction:column;
  align-items:center;
  gap:0;
  padding-bottom:16px;
}

.table-visual{
  width:100%;
  display:flex;
  align-items:center;
  justify-content:center;
  padding:20px 8px 14px;
}




.table-card.quadrada .mesa-btn-visual{ border-radius:10px !important; }
.mesa-btn-visual{
  aspect-ratio:1;
  width:110px;
  border-radius:18px;
  border:2px solid rgba(201,168,76,.2);
  background:rgba(13,6,0,.55);
  display:flex;flex-direction:column;align-items:center;justify-content:center;
  gap:3px;position:relative;
  padding:10px;overflow:hidden;text-align:center;
}
.table-card.livre    .mesa-btn-visual{border-color:rgba(34,197,94,.5);background:rgba(34,197,94,.06)}
.table-card.ocupada  .mesa-btn-visual{border-color:rgba(239,68,68,.45);background:rgba(239,68,68,.06)}
.table-card.reservada.mesa-btn-visual,.table-card.reservada .mesa-btn-visual{border-color:rgba(245,158,11,.45);background:rgba(245,158,11,.06)}
.table-card.manutencao .mesa-btn-visual{border-color:rgba(100,116,139,.4);background:rgba(100,116,139,.06)}

.mesa-status-dot{
  position:absolute;top:8px;right:8px;
  width:10px;height:10px;border-radius:50%;
}
.table-card.livre     .mesa-status-dot{background:#22c55e;box-shadow:0 0 8px rgba(34,197,94,.6)}
.table-card.ocupada   .mesa-status-dot{background:#ef4444;box-shadow:0 0 8px rgba(239,68,68,.6)}
.table-card.reservada .mesa-status-dot{background:#f59e0b}
.table-card.manutencao .mesa-status-dot{background:#64748b}

.mesa-num{font-size:26px;font-weight:bold;color:var(--cream);line-height:1}
.mesa-occ{font-size:11px;color:rgba(245,234,216,.45);line-height:1.3;text-align:center}
.mesa-cap{font-size:11px;color:rgba(245,234,216,.55);line-height:1.3}

.table-form{
  width:100%;
  display:flex;
  flex-direction:column;
  gap:10px;
  padding:0 16px;
}

.table-form label{
  font-size:13px;
  color:var(--cream2);
  margin-bottom:2px;
}

.table-form input,
.table-form select{
  width:100%;
  padding:10px 12px;
  border-radius:10px;
}

.actions{
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:8px;
  margin-top:8px;
}

.btn-danger{
  background:rgba(239,68,68,.18);
  color:#fca5a5;
  border:1px solid rgba(239,68,68,.35);
}

@media(max-width:1400px){
  .tables-grid{
    grid-template-columns:repeat(4,1fr);
  }
}

@media(max-width:1000px){
  .admin-layout{display:block;margin:0;padding:0}

  

  .content{
    padding:28px 20px;;margin-left:285px!important}

  .tables-grid{
    grid-template-columns:repeat(2,1fr);
  }

  .form-grid{
    grid-template-columns:1fr 1fr;
  }

  .topbar{
    flex-direction:column;
  }
}

@media(max-width:650px){
  .tables-grid{
    grid-template-columns:1fr;
  }

  .form-grid{
    grid-template-columns:1fr;
  }

  .room{
    margin:16px;
    padding:20px;
  }

  .panel-header{
    flex-direction:column;
    align-items:flex-start;
  }

  .topbar h1{
    font-size:36px;
  }
}
</style>
<style id="sidebar-fixed">
/* ── TOPBAR UNIFICADO ── */
.topbar,.page-topbar{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:32px;flex-wrap:wrap}
.topbar-left,.topbar-right{display:flex;align-items:center;gap:12px}
.page-subtitle,.subtitle{color:var(--gold-light,#e8c97a);letter-spacing:7px;font-size:12px;margin-bottom:6px;display:block}
.session-box,.session,.user-box{
  padding:11px 20px;
  border-radius:999px;
  background:rgba(13,6,0,.65);
  border:1px solid rgba(var(--gold-rgb,201,168,76),.25);
  color:var(--cream2,#ede0c4);
  font-size:14px;
  white-space:nowrap;
  font-family:var(--font,Georgia),serif;
}

/* ── SIDEBAR FIXA ── */
.admin-layout{display:block;margin:0;padding:0}
.sidebar{
  width:285px;min-width:285px;padding:26px 24px;
  background:var(--sidebar-gradient,linear-gradient(180deg,rgba(26,14,4,.98),rgba(13,6,0,.96)));
  border-right:1px solid rgba(var(--gold-rgb,201,168,76),.22);
  position:fixed!important;top:0;left:0;
  height:100vh;overflow-y:auto;overflow-x:hidden;
  z-index:100;display:flex;flex-direction:column;
}
.sidebar::-webkit-scrollbar{width:4px}
.sidebar::-webkit-scrollbar-thumb{background:rgba(201,168,76,.25);border-radius:2px}
.content{margin-left:285px!important;padding:34px 46px;overflow-x:auto;min-height:100vh}
.sidebar .sidebar-logo{display:flex!important;flex-direction:row!important;align-items:center!important;gap:14px!important;margin-bottom:42px!important;flex-shrink:0}
.sidebar .logo-box{width:56px!important;height:56px!important;border-radius:var(--radius,18px)!important;background:var(--grad-primary,linear-gradient(135deg,#c9a84c,#e8c97a))!important;color:#140900!important;display:flex!important;align-items:center!important;justify-content:center!important;font-size:28px!important;font-weight:bold!important;flex-shrink:0!important}
.sidebar .sidebar-logo h2{color:var(--gold-light,#e8c97a)!important;font-size:24px!important;line-height:1!important;margin:0!important}
.sidebar .sidebar-logo span{font-size:12px!important;color:rgba(245,234,216,.55)!important;letter-spacing:2px!important;display:block!important}
.menu-title{font-size:12px;color:rgba(245,234,216,.45);letter-spacing:3px;margin-bottom:16px;flex-shrink:0}
.side-menu{display:flex;flex-direction:column;gap:10px;flex:1}
.side-menu a{padding:14px 16px;border-radius:var(--radius,16px);color:var(--cream2,#ede0c4);text-decoration:none;background:rgba(var(--gold-rgb,201,168,76),.06);border:1px solid rgba(var(--gold-rgb,201,168,76),.12);transition:.22s ease;font-size:var(--fs-base,15px);display:block}
.side-menu a:hover,.side-menu a.active{background:var(--grad-primary,linear-gradient(135deg,#c9a84c,#e8c97a));color:#140900;font-weight:bold;transform:translateX(4px)}
.sidebar .logout{margin-top:18px;flex-shrink:0;display:block;padding:14px;border-radius:var(--radius,14px);text-align:center;color:#fca5a5;text-decoration:none;border:1px solid rgba(239,68,68,.35);background:rgba(239,68,68,.08);font-size:var(--fs-base,15px);font-weight:bold;transition:.2s}
.sidebar .logout:hover{background:rgba(239,68,68,.18)}
@media(max-width:900px){
  .admin-layout{display:block;margin:0;padding:0}
  .sidebar{position:relative!important;width:100%!important;min-width:100%!important;height:auto!important;overflow:visible!important}
  .content,main.content{margin-left:0!important;padding:24px 18px;overflow-x:auto;min-height:auto;width:100%!important}
  .side-menu a{padding:11px 14px}
  .side-menu a:hover,.side-menu a.active{transform:none}
}
</style>
<link rel="stylesheet" href="assets/responsive_global.css">
</head>

<body>

<div class="admin-layout">

  <?php include "sidebar_admin.php"; ?>

  <main class="content" style="display:block;min-height:100vh;box-sizing:border-box">

    <div class="topbar">
      <div>
        <p class="subtitle">RESTAURANT MANAGEMENT</p>
        <h1>Gestão de Mesas</h1>
      </div>

      <div class="session-box">
        Sessão iniciada como: <strong><?= htmlspecialchars($adminName) ?></strong>
      </div>
    </div>

    <?php if($msg !== ""): ?>
      <div class="msg"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>

    <section class="panel">
      <div class="panel-header">
        <h2>➕ Adicionar Mesa</h2>
      </div>

      <form method="POST">
        <div class="form-grid">

          <div class="form-group">
            <label>Número da Mesa</label>
            <input type="number" name="number" required>
          </div>

          <div class="form-group">
            <label>Capacidade</label>
            <input type="number" name="capacity" min="1" required>
          </div>

          <div class="form-group">
            <label>Estado</label>
            <select name="status">
              <option value="livre">Livre</option>
              <option value="ocupada">Ocupada</option>
              <option value="reservada">Reservada</option>
              <option value="manutencao">Manutenção</option>
            </select>
          </div>

          <div class="form-group">
            <label>Tipo</label>
            <select name="type_table">
              <option value="quadrada">Quadrada</option>
              <option value="redonda">Redonda</option>
              <option value="retangular">Retangular</option>
            </select>
          </div>

          <div class="form-group full">
            <button type="submit" name="add_table">Adicionar Mesa</button>
          </div>

        </div>
      </form>
    </section>

    <section class="panel">
      <div class="panel-header">
        <h2>🗺️ Mapa da Sala</h2>

        <div class="legend">
          <span><i class="dot livre"></i> Livre</span>
          <span><i class="dot ocupada"></i> Ocupada</span>
          <span><i class="dot reservada"></i> Reservada</span>
          <span><i class="dot manutencao"></i> Manutenção</span>
        </div>
      </div>

      <div class="room">
        <p class="room-title">SALA PRINCIPAL · MAPA DE MESAS</p>

        <div class="tables-grid">

          <?php if($result && $result->num_rows > 0): ?>
            <?php while($mesa = $result->fetch_assoc()): ?>
              <?php
                $capacity = intval($mesa["capacity"]);
                $occupied = intval($mesa["occupied_seats"]);
                $chairs = min($capacity, 8);
              ?>

              <div class="table-card <?= htmlspecialchars($mesa["status"]) ?>">

                <div class="table-visual">
                  <div class="mesa-btn-visual">
                    <span class="mesa-status-dot"></span>
                    <span class="mesa-num"><?= htmlspecialchars($mesa["number"]) ?></span>
                    <span class="mesa-occ"><?= $occupied ?>/<?= $capacity ?> ocupados</span>
                    <span class="mesa-cap"><?= $capacity ?> lugares</span>
                    <?php
                      $tipo = strtolower($mesa["type_table"] ?? "quadrada");
                      $icone = $tipo === "redonda" ? "●" : ($tipo === "retangular" ? "▬" : "■");
                    ?>
                    <span style="font-size:11px;color:rgba(201,168,76,.6);margin-top:3px;letter-spacing:1px"><?= $icone ?> <?= ucfirst($tipo) ?></span>
                  </div>
                </div>

                <form class="table-form" method="POST">
                  <input type="hidden" name="id" value="<?= htmlspecialchars($mesa["id"]) ?>">

                  <label>Número</label>
                  <input type="number" name="number" value="<?= htmlspecialchars($mesa["number"]) ?>" required>

                  <label>Capacidade</label>
                  <input type="number" name="capacity" min="1" value="<?= htmlspecialchars($mesa["capacity"]) ?>" required>

                  <label>Ocupados</label>
                  <input
                    type="number"
                    name="occupied_seats"
                    min="0"
                    max="<?= htmlspecialchars($mesa["capacity"]) ?>"
                    value="<?= htmlspecialchars($mesa["occupied_seats"]) ?>"
                    required
                  >

                  <label>Estado</label>
                  <select name="status">
                    <option value="livre" <?= $mesa["status"] === "livre" ? "selected" : "" ?>>Livre</option>
                    <option value="ocupada" <?= $mesa["status"] === "ocupada" ? "selected" : "" ?>>Ocupada</option>
                    <option value="reservada" <?= $mesa["status"] === "reservada" ? "selected" : "" ?>>Reservada</option>
                    <option value="manutencao" <?= $mesa["status"] === "manutencao" ? "selected" : "" ?>>Manutenção</option>
                  </select>

                  <label>Tipo</label>
                  <select name="type_table">
                    <option value="quadrada" <?= $mesa["type_table"] === "quadrada" ? "selected" : "" ?>>Quadrada</option>
                    <option value="redonda" <?= $mesa["type_table"] === "redonda" ? "selected" : "" ?>>Redonda</option>
                    <option value="retangular" <?= $mesa["type_table"] === "retangular" ? "selected" : "" ?>>Retangular</option>
                  </select>

                  <div class="actions">
                    <button type="submit" name="edit_table">Guardar</button>

                    <button
                      type="submit"
                      name="delete_table"
                      class="btn-danger"
                      onclick="return confirm('Remover esta mesa?')"
                    >
                      Remover
                    </button>
                  </div>
                </form>

              </div>

            <?php endwhile; ?>
          <?php else: ?>
            <p>Nenhuma mesa encontrada.</p>
          <?php endif; ?>

        </div>
      </div>
    </section>

  </main>

</div>

<script src="assets/keep_session.js"></script>
</body>
</html>
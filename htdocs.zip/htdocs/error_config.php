<?php
/**
 * error_config.php — Configuração centralizada de erros (produção)
 *
 * Nunca mostra erros ao visitante (evita expor caminhos do servidor,
 * queries SQL, nomes de tabelas/colunas, etc.). Os erros continuam a
 * ser registados em php_errors.log para o administrador poder consultar.
 */

ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);

ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/php_errors.log');

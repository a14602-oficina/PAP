<?php
require_once "error_config.php";

require_once "auth_check.php";
require_once "service_flow.php";
st_ensure_service_flow_columns($conn);
st_reset_service_flow_for_free_tables($conn);

if (!isset($_SESSION["user_id"]) || !in_array($_SESSION["role"], ["admin", "empregado_mesa"])) {
    header("Location: login.php");
    exit;
}

$msg = "";
$adminName = $_SESSION["name"] ?? "Administrador";

/* Confirmar pagamento */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["confirmar_pagamento"])) {
    $tableNumber = intval($_POST["table_number"] ?? 0);

    if ($tableNumber > 0) {

        /* Marcar como pagos TODOS os pedidos desta mesa que estão em 'pagamento' */
        $stmt = $conn->prepare("
            UPDATE orders
            SET status = 'pago'
            WHERE table_number = ? AND status = 'pagamento'
        ");
        $stmt->bind_param("i", $tableNumber);
        $stmt->execute();
        st_free_table_after_payment($conn, $tableNumber);

        /* Cancelar quaisquer outros pedidos pendentes desta mesa (slate limpo) */
        $stmtCancel = $conn->prepare("
            UPDATE orders SET status = 'cancelado'
            WHERE table_number = ? AND status NOT IN ('pago','cancelado')
        ");
        $stmtCancel->bind_param("i", $tableNumber);
        $stmtCancel->execute();

        /* Limpar bar_orders pendentes desta mesa */
        $stmtBar = $conn->prepare("
            UPDATE bar_orders SET status = 'pronto'
            WHERE table_number = ? AND status IN ('pendente','preparando')
        ");
        $stmtBar->bind_param("s", $tableNumber);
        $stmtBar->execute();

        header("Location: pagamento_dashboard.php?ok=pago");
        exit;
    }
}

if (isset($_GET["ok"]) && $_GET["ok"] === "pago") {
    $msg = "Pagamento confirmado. Mesa libertada.";
}

/* Buscar contas para pagamento */
$orders = $conn->query("
    SELECT *
    FROM orders
    WHERE status = 'pagamento'
    ORDER BY table_number ASC, created_at ASC
");

/* Agrupar pedidos por mesa numa única conta */
$accounts = [];
if ($orders) {
    while ($o = $orders->fetch_assoc()) {
        $tn = $o["table_number"];
        if (!isset($accounts[$tn])) {
            $accounts[$tn] = [
                "table_number" => $tn,
                "payment_code" => $o["payment_code"] ?? null,
                "payment_requested_at" => $o["payment_requested_at"] ?? null,
                "orders" => [],
                "total" => 0,
            ];
        }
        $accounts[$tn]["orders"][] = $o;
        $accounts[$tn]["total"] += (float)$o["total"];
        if (!empty($o["payment_code"]) && empty($accounts[$tn]["payment_code"])) {
            $accounts[$tn]["payment_code"] = $o["payment_code"];
        }
        if (!empty($o["payment_requested_at"]) &&
            (empty($accounts[$tn]["payment_requested_at"]) || $o["payment_requested_at"] < $accounts[$tn]["payment_requested_at"])) {
            $accounts[$tn]["payment_requested_at"] = $o["payment_requested_at"];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>SmartTable - Pagamentos</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="favicon.ico" sizes="any">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="apple-touch-icon" href="assets/logo.png">
<link rel="manifest" href="site.webmanifest">
<meta name="theme-color" content="#0d0600">
<link rel="stylesheet" href="assets/responsive.css">
<style>
:root{
  --gold:#c9a84c;
  --gold-light:#e8c97a;
  --dark:#0d0600;
  --cream:#f5ead8;
  --cream2:#ede0c4;
}

*{
  box-sizing:border-box;
  margin:0;
  padding:0;
}

body{
  min-height:100vh;
  font-family:Georgia,"Times New Roman",serif;
  background:
    linear-gradient(90deg,rgba(201,168,76,.04) 1px,transparent 1px),
    linear-gradient(rgba(201,168,76,.03) 1px,transparent 1px),
    radial-gradient(circle at top left,rgba(201,168,76,.18),transparent 35%),
    linear-gradient(135deg,var(--dark),#080300 70%);
  background-size:80px 80px,80px 80px,cover,cover;
  color:var(--cream);
}

.header{
  padding:28px 42px;
  display:flex;
  justify-content:space-between;
  align-items:center;
  background:rgba(13,6,0,.78);
  border-bottom:1px solid rgba(201,168,76,.22);
}

.brand{
  display:flex;
  align-items:center;
  gap:14px;
}

.logo{
  width:58px;
  height:58px;
  border-radius:16px;
  background:linear-gradient(135deg,var(--gold),var(--gold-light));
  color:#140900;
  display:flex;
  align-items:center;
  justify-content:center;
  font-size:28px;
  font-weight:bold;
}

.brand span{
  font-size:11px;
  letter-spacing:4px;
  color:var(--gold-light);
}

.brand h1{
  font-size:30px;
}

.header-actions{
  margin-left:auto;
  display:flex;
  align-items:center;
  justify-content:flex-end;
  gap:14px;
}

.session-box{
  padding:14px 18px;
  border-radius:999px;
  background:rgba(13,6,0,.75);
  border:1px solid rgba(201,168,76,.28);
  color:var(--cream2);
  white-space:nowrap;
}

.back-btn{
  padding:14px 24px;
  border-radius:16px;
  text-decoration:none;
  background:rgba(13,6,0,.75);
  color:var(--gold-light);
  font-weight:bold;
  border:1px solid rgba(201,168,76,.28);
  transition:.2s ease;
}

.back-btn:hover{
  background:linear-gradient(135deg,var(--gold),var(--gold-light));
  color:#140900;
  transform:translateY(-2px);
  box-shadow:0 10px 25px rgba(201,168,76,.18);
}

.main{
  padding:40px;
}

.subtitle{
  color:var(--gold-light);
  letter-spacing:8px;
  font-size:13px;
  margin-bottom:8px;
}

h2{
  font-size:48px;
  margin-bottom:34px;
}

.msg{
  padding:15px 18px;
  border-radius:14px;
  background:rgba(34,197,94,.12);
  border:1px solid rgba(34,197,94,.35);
  color:#86efac;
  margin-bottom:24px;
}

.grid{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:24px;
}

.card{
  border:1px solid rgba(201,168,76,.28);
  border-radius:24px;
  background:linear-gradient(145deg,rgba(38,21,8,.82),rgba(13,6,0,.96));
  box-shadow:0 18px 55px rgba(0,0,0,.35);
  overflow:hidden;
}

.card-header{
  padding:22px 24px;
  border-bottom:1px solid rgba(201,168,76,.16);
  display:flex;
  justify-content:space-between;
  align-items:flex-start;
  gap:18px;
}

.card-header h3{
  color:var(--gold-light);
  font-size:28px;
}

.payment-code{
  margin-top:10px;
  color:#fff;
  font-size:22px;
  letter-spacing:3px;
  font-weight:bold;
}

.payment-time{
  color:#fbbf24;
  margin-top:8px;
  font-size:14px;
}

.badge{
  padding:7px 12px;
  border-radius:999px;
  background:rgba(245,158,11,.12);
  border:1px solid rgba(245,158,11,.35);
  color:#fbbf24;
  text-transform:uppercase;
  font-size:12px;
  font-weight:bold;
  white-space:nowrap;
}

.card-body{
  padding:24px;
}

.item-row{
  display:flex;
  justify-content:space-between;
  gap:16px;
  padding:10px 0;
  border-bottom:1px solid rgba(201,168,76,.10);
  color:var(--cream2);
}

.item-row strong{
  color:var(--cream);
}

.total{
  margin-top:18px;
  padding:18px;
  border-radius:16px;
  background:rgba(201,168,76,.12);
  border:1px solid rgba(201,168,76,.25);
  display:flex;
  justify-content:space-between;
  font-size:24px;
  font-weight:bold;
  color:var(--gold-light);
}

.actions{
  padding:24px;
  display:grid;
  gap:12px;
}

button,
.receipt{
  width:100%;
  padding:14px;
  border:none;
  border-radius:14px;
  background:linear-gradient(135deg,var(--gold),var(--gold-light));
  color:#140900;
  font-weight:bold;
  cursor:pointer;
  text-align:center;
  text-decoration:none;
  font-size:15px;
}

.receipt{
  display:block;
}

.empty{
  padding:28px;
  border-radius:24px;
  border:1px solid rgba(201,168,76,.25);
  background:rgba(13,6,0,.45);
  color:rgba(245,234,216,.65);
}

@media(max-width:1200px){
  .grid{
    grid-template-columns:repeat(2,1fr);
  }
}

@media(max-width:750px){
  .header{
    flex-direction:column;
    align-items:flex-start;
    gap:16px;
    padding:24px 18px;
  }

  .header-actions{
    width:100%;
    margin-left:0;
    justify-content:flex-start;
    flex-direction:column;
    align-items:flex-start;
  }

  .main{
    padding:24px 18px;
  }

  .grid{
    grid-template-columns:1fr;
  }

  h2{
    font-size:36px;
  }
}

/* Layout com sidebar */
.admin-layout{display:block;margin:0;padding:0}
.content{flex:1;padding:42px;min-width:0;margin-left:0}
.page-topbar{display:flex;justify-content:space-between;align-items:flex-start;gap:20px;margin-bottom:32px;flex-wrap:wrap}
.page-subtitle{color:var(--gold-light);letter-spacing:8px;font-size:13px;margin-bottom:6px}
.page-title{font-size:44px;color:var(--cream)}
.session-box{padding:14px 18px;border-radius:999px;background:rgba(13,6,0,.75);border:1px solid rgba(201,168,76,.28);color:var(--cream2);white-space:nowrap;font-size:14px}
@media(max-width:900px){.admin-layout{display:block;margin:0;padding:0}.content{padding:24px 18px;margin-left:285px!important}}

</style>
<?php include_once __DIR__ . "/theme.php"; ?>
<style id="sidebar-fixed">
/* ── TOPBAR UNIFICADO ── */
.topbar,.page-topbar{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:32px;flex-wrap:wrap}
.topbar-left,.topbar-right{display:flex;align-items:center;gap:12px}
.page-subtitle,.subtitle{color:var(--gold-light,#e8c97a);letter-spacing:7px;font-size:12px;margin-bottom:6px;display:block}
.session-box,.session,.user-box{
  padding:11px 20px;
  border-radius:999px;
  background:rgba(13,6,0,.65);
  border:1px solid rgba(var(--gold-rgb,201,168,76),.25);
  color:var(--cream2,#ede0c4);
  font-size:14px;
  white-space:nowrap;
  font-family:var(--font,Georgia),serif;
}

/* ── SIDEBAR FIXA ── */
.admin-layout{display:block;margin:0;padding:0}
.sidebar{
  width:285px;min-width:285px;padding:26px 24px;
  background:var(--sidebar-gradient,linear-gradient(180deg,rgba(26,14,4,.98),rgba(13,6,0,.96)));
  border-right:1px solid rgba(var(--gold-rgb,201,168,76),.22);
  position:fixed!important;top:0;left:0;
  height:100vh;overflow-y:auto;overflow-x:hidden;
  z-index:100;display:flex;flex-direction:column;
}
.sidebar::-webkit-scrollbar{width:4px}
.sidebar::-webkit-scrollbar-thumb{background:rgba(201,168,76,.25);border-radius:2px}
.content{margin-left:285px!important;padding:34px 46px;overflow-x:auto;min-height:100vh}
.sidebar .sidebar-logo{display:flex!important;flex-direction:row!important;align-items:center!important;gap:14px!important;margin-bottom:42px!important;flex-shrink:0}
.sidebar .logo-box{width:56px!important;height:56px!important;border-radius:var(--radius,18px)!important;background:var(--grad-primary,linear-gradient(135deg,#c9a84c,#e8c97a))!important;color:#140900!important;display:flex!important;align-items:center!important;justify-content:center!important;font-size:28px!important;font-weight:bold!important;flex-shrink:0!important}
.sidebar .sidebar-logo h2{color:var(--gold-light,#e8c97a)!important;font-size:24px!important;line-height:1!important;margin:0!important}
.sidebar .sidebar-logo span{font-size:12px!important;color:rgba(245,234,216,.55)!important;letter-spacing:2px!important;display:block!important}
.menu-title{font-size:12px;color:rgba(245,234,216,.45);letter-spacing:3px;margin-bottom:16px;flex-shrink:0}
.side-menu{display:flex;flex-direction:column;gap:10px;flex:1}
.side-menu a{padding:14px 16px;border-radius:var(--radius,16px);color:var(--cream2,#ede0c4);text-decoration:none;background:rgba(var(--gold-rgb,201,168,76),.06);border:1px solid rgba(var(--gold-rgb,201,168,76),.12);transition:.22s ease;font-size:var(--fs-base,15px);display:block}
.side-menu a:hover,.side-menu a.active{background:var(--grad-primary,linear-gradient(135deg,#c9a84c,#e8c97a));color:#140900;font-weight:bold;transform:translateX(4px)}
.sidebar .logout{margin-top:18px;flex-shrink:0;display:block;padding:14px;border-radius:var(--radius,14px);text-align:center;color:#fca5a5;text-decoration:none;border:1px solid rgba(239,68,68,.35);background:rgba(239,68,68,.08);font-size:var(--fs-base,15px);font-weight:bold;transition:.2s}
.sidebar .logout:hover{background:rgba(239,68,68,.18)}
@media(max-width:900px){
  .admin-layout{display:block;margin:0;padding:0}
  .sidebar{position:relative!important;width:100%!important;min-width:100%!important;height:auto!important;overflow:visible!important}
  .content,main.content{margin-left:0!important;padding:24px 18px;overflow-x:auto;min-height:auto;width:100%!important}
  .side-menu a{padding:11px 14px}
  .side-menu a:hover,.side-menu a.active{transform:none}
}
</style>
<link rel="stylesheet" href="assets/responsive_global.css">
</head>

<body>
<div class="admin-layout">
<?php include "sidebar_admin.php"; ?>
<main class="content" style="display:block;min-height:100vh;box-sizing:border-box">

  <div class="page-topbar">
    <div>
      <p class="page-subtitle">PAGAMENTOS</p>
      <h1 class="page-title">💳 Contas por pagar</h1>
    </div>
    <div class="session-box">Sessão iniciada como: <strong><?= htmlspecialchars($adminName) ?></strong></div>
  </div>

  <?php if ($msg !== ""): ?>
    <div class="msg"><?= htmlspecialchars($msg) ?></div>
  <?php endif; ?>

  <section id="live-content" class="grid">

    <?php if (!empty($accounts)): ?>
      <?php foreach ($accounts as $account): ?>

        <article class="card">

          <div class="card-header">

            <div>
              <h3>Mesa <?= htmlspecialchars($account["table_number"]) ?></h3>

              <div class="payment-code">
                Código: <?= htmlspecialchars($account["payment_code"] ?? "-") ?>
              </div>

              <?php if (!empty($account["payment_requested_at"])): ?>
                <div class="payment-time">
                  Pedido de pagamento às
                  <?= date("H:i", strtotime($account["payment_requested_at"])) ?>
                </div>
              <?php endif; ?>
            </div>

            <span class="badge">Pagamento</span>

          </div>

          <div class="card-body">

            <?php foreach ($account["orders"] as $order): ?>

              <div class="item-row">
                <strong>Pedido</strong>
                <span>#<?= htmlspecialchars($order["id"]) ?></span>
              </div>

              <?php
                $itemsStmt = $conn->prepare("
                  SELECT *
                  FROM order_items
                  WHERE order_id = ?
                ");
                $itemsStmt->bind_param("i", $order["id"]);
                $itemsStmt->execute();
                $items = $itemsStmt->get_result();
              ?>

              <?php while($item = $items->fetch_assoc()): ?>
                <div class="item-row">
                  <span>
                    <strong><?= htmlspecialchars($item["quantity"]) ?>x</strong>
                    <?= htmlspecialchars($item["name"]) ?>
                  </span>

                  <span>
                    <?= number_format((float)$item["subtotal"], 2, ",", ".") ?> €
                  </span>
                </div>
              <?php endwhile; ?>

            <?php endforeach; ?>

            <div class="total">
              <span>Total</span>
              <span><?= number_format($account["total"], 2, ",", ".") ?> €</span>
            </div>

          </div>

          <div class="actions">

            <a
              href="recibo.php?table_number=<?= htmlspecialchars($account["table_number"]) ?>"
              class="receipt"
              target="_blank"
            >
              Ver Talão / Recibo
            </a>

            <form method="POST" onsubmit="return confirm('Confirmar pagamento desta conta?')">
              <input type="hidden" name="table_number" value="<?= htmlspecialchars($account["table_number"]) ?>">

              <button type="submit" name="confirmar_pagamento">
                Confirmar Pagamento
              </button>
            </form>

          </div>

        </article>

      <?php endforeach; ?>

    <?php else: ?>

      <div class="empty">
        Não existem contas pendentes de pagamento.
      </div>

    <?php endif; ?>

  </section>

</main>

<script src="assets/auto_refresh.js"></script>

<script src="assets/keep_session.js"></script>
</main>
</div>
<script src="assets/notifications.js"></script>
</body>
</html>
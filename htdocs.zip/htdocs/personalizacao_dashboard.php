<?php
require_once "error_config.php";

require_once "auth_check.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "admin") {
    header("Location: login.php");
    exit;
}

$msg = "";
$msgType = "success";
$adminName = $_SESSION["name"] ?? "Administrador";

/* ── Garantir tabela e colunas ── */
$conn->query("
    CREATE TABLE IF NOT EXISTS system_settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        restaurant_name VARCHAR(255) NOT NULL DEFAULT 'SmartTable',
        primary_color VARCHAR(20) NOT NULL DEFAULT '#c9a84c',
        secondary_color VARCHAR(20) NOT NULL DEFAULT '#e8c97a',
        background_color VARCHAR(20) NOT NULL DEFAULT '#0d0600',
        text_color VARCHAR(20) NOT NULL DEFAULT '#f5ead8',
        accent_color VARCHAR(20) NOT NULL DEFAULT '#86efac',
        sidebar_bg VARCHAR(20) NOT NULL DEFAULT '#110800',
        card_bg VARCHAR(20) NOT NULL DEFAULT '#1a0e04',
        border_color VARCHAR(20) NOT NULL DEFAULT '#3a2a10',
        input_bg VARCHAR(20) NOT NULL DEFAULT '#0d0600',
        font_family VARCHAR(255) NOT NULL DEFAULT 'Georgia',
        font_size VARCHAR(10) NOT NULL DEFAULT '15',
        border_radius VARCHAR(10) NOT NULL DEFAULT '14',
        shadow_intensity VARCHAR(20) NOT NULL DEFAULT 'medium',
        sidebar_style VARCHAR(30) NOT NULL DEFAULT 'dark',
        logo VARCHAR(255) DEFAULT NULL,
        background_image VARCHAR(255) DEFAULT NULL,
        show_logo_text TINYINT(1) NOT NULL DEFAULT 1,
        compact_mode TINYINT(1) NOT NULL DEFAULT 0,
        updated_at DATETIME DEFAULT NULL
    )
");

$cols = $conn->query("SHOW COLUMNS FROM system_settings")->fetch_all(MYSQLI_ASSOC);
$existingCols = array_column($cols, 'Field');
$newCols = [
    "accent_color"     => "VARCHAR(20) NOT NULL DEFAULT '#86efac'",
    "sidebar_bg"       => "VARCHAR(20) NOT NULL DEFAULT '#110800'",
    "card_bg"          => "VARCHAR(20) NOT NULL DEFAULT '#1a0e04'",
    "border_color"     => "VARCHAR(20) NOT NULL DEFAULT '#3a2a10'",
    "input_bg"         => "VARCHAR(20) NOT NULL DEFAULT '#0d0600'",
    "font_size"        => "VARCHAR(10) NOT NULL DEFAULT '15'",
    "border_radius"    => "VARCHAR(10) NOT NULL DEFAULT '14'",
    "shadow_intensity" => "VARCHAR(20) NOT NULL DEFAULT 'medium'",
    "sidebar_style"    => "VARCHAR(30) NOT NULL DEFAULT 'dark'",
    "show_logo_text"   => "TINYINT(1) NOT NULL DEFAULT 1",
    "compact_mode"     => "TINYINT(1) NOT NULL DEFAULT 0",
    "updated_at"       => "DATETIME DEFAULT NULL",
];
foreach ($newCols as $col => $def) {
    if (!in_array($col, $existingCols)) {
        $conn->query("ALTER TABLE system_settings ADD COLUMN $col $def");
    }
}

$check = $conn->query("SELECT id FROM system_settings LIMIT 1");
if ($check && $check->num_rows === 0) {
    $conn->query("
        INSERT INTO system_settings
            (restaurant_name,primary_color,secondary_color,background_color,
             text_color,accent_color,sidebar_bg,card_bg,border_color,input_bg,
             font_family,font_size,border_radius,shadow_intensity,sidebar_style,show_logo_text,compact_mode)
        VALUES
            ('SmartTable','#c9a84c','#e8c97a','#0d0600',
             '#f5ead8','#86efac','#110800','#1a0e04','#3a2a10','#0d0600',
             'Georgia','15','14','medium','dark',1,0)
    ");
}

$settings = $conn->query("SELECT * FROM system_settings LIMIT 1")->fetch_assoc();

if (!is_dir("uploads")) mkdir("uploads", 0755, true);

/* ── Repor defaults ── */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["reset_defaults"])) {
    $conn->query("
        UPDATE system_settings SET
            restaurant_name='SmartTable', primary_color='#c9a84c',
            secondary_color='#e8c97a', background_color='#0d0600',
            text_color='#f5ead8', accent_color='#86efac',
            sidebar_bg='#110800', card_bg='#1a0e04',
            border_color='#3a2a10', input_bg='#0d0600',
            font_family='Georgia', font_size='15', border_radius='14',
            shadow_intensity='medium', sidebar_style='dark',
            show_logo_text=1, compact_mode=0, updated_at=NOW()
        WHERE id=" . intval($settings["id"])
    );
    header("Location: personalizacao_dashboard.php?msg=defaults");
    exit;
}

/* ── Guardar ── */
if ($_SERVER["REQUEST_METHOD"] === "POST" && !isset($_POST["reset_defaults"])) {
    $restaurant_name  = trim($_POST["restaurant_name"]  ?? "SmartTable");
    $primary_color    = $_POST["primary_color"]    ?? "#c9a84c";
    $secondary_color  = $_POST["secondary_color"]  ?? "#e8c97a";
    $background_color = $_POST["background_color"] ?? "#0d0600";
    $text_color       = $_POST["text_color"]       ?? "#f5ead8";
    $accent_color     = $_POST["accent_color"]     ?? "#86efac";
    $sidebar_bg       = $_POST["sidebar_bg"]       ?? "#110800";
    $card_bg          = $_POST["card_bg"]          ?? "#1a0e04";
    $border_color     = $_POST["border_color"]     ?? "#3a2a10";
    $input_bg         = $_POST["input_bg"]         ?? "#0d0600";
    $font_family      = $_POST["font_family"]      ?? "Georgia";
    $font_size        = intval($_POST["font_size"]  ?? 15);
    $border_radius    = intval($_POST["border_radius"] ?? 14);
    $shadow_intensity = $_POST["shadow_intensity"] ?? "medium";
    $sidebar_style    = $_POST["sidebar_style"]    ?? "dark";
    $show_logo_text   = isset($_POST["show_logo_text"]) ? 1 : 0;
    $compact_mode     = isset($_POST["compact_mode"])   ? 1 : 0;

    $logo             = $settings["logo"]             ?? null;
    $background_image = $settings["background_image"] ?? null;

    if (!empty($_FILES["logo"]["name"])) {
        $ext = strtolower(pathinfo($_FILES["logo"]["name"], PATHINFO_EXTENSION));
        if (in_array($ext, ["jpg","jpeg","png","webp","gif","svg"])) {
            $newName = "logo_" . time() . "." . $ext;
            if (move_uploaded_file($_FILES["logo"]["tmp_name"], "uploads/" . $newName))
                $logo = "uploads/" . $newName;
        }
    }
    if (isset($_POST["remove_logo"])) $logo = null;

    if (!empty($_FILES["background_image"]["name"])) {
        $ext = strtolower(pathinfo($_FILES["background_image"]["name"], PATHINFO_EXTENSION));
        if (in_array($ext, ["jpg","jpeg","png","webp","gif"])) {
            $newName = "bg_" . time() . "." . $ext;
            if (move_uploaded_file($_FILES["background_image"]["tmp_name"], "uploads/" . $newName))
                $background_image = "uploads/" . $newName;
        }
    }
    if (isset($_POST["remove_bg"])) $background_image = null;

    $stmt = $conn->prepare("
        UPDATE system_settings SET
            restaurant_name=?, primary_color=?, secondary_color=?,
            background_color=?, text_color=?, accent_color=?,
            sidebar_bg=?, card_bg=?, border_color=?, input_bg=?,
            font_family=?, font_size=?, border_radius=?,
            shadow_intensity=?, sidebar_style=?,
            show_logo_text=?, compact_mode=?,
            logo=?, background_image=?, updated_at=NOW()
        WHERE id=?
    ");
    $id = intval($settings["id"]);
    $stmt->bind_param(
        "sssssssssssssssiissi",
        $restaurant_name, $primary_color, $secondary_color,
        $background_color, $text_color, $accent_color,
        $sidebar_bg, $card_bg, $border_color, $input_bg,
        $font_family, $font_size, $border_radius,
        $shadow_intensity, $sidebar_style,
        $show_logo_text, $compact_mode,
        $logo, $background_image, $id
    );

    if ($stmt->execute()) {
        header("Location: personalizacao_dashboard.php?msg=saved");
        exit;
    } else {
        $msg = "Erro ao guardar: " . $conn->error;
        $msgType = "error";
    }
}

if (isset($_GET["msg"])) {
    if ($_GET["msg"] === "saved")    { $msg = "Personalização guardada com sucesso."; $msgType = "success"; }
    if ($_GET["msg"] === "defaults") { $msg = "Valores predefinidos restaurados.";    $msgType = "info"; }
    $settings = $conn->query("SELECT * FROM system_settings LIMIT 1")->fetch_assoc();
}

function sel($a, $b) { return $a === $b ? "selected" : ""; }
function chk($v)     { return $v ? "checked" : ""; }
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>SmartTable — Personalização</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="favicon.ico" sizes="any">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="apple-touch-icon" href="assets/logo.png">
<link rel="manifest" href="site.webmanifest">
<meta name="theme-color" content="#0d0600">
<?php include_once __DIR__ . "/theme.php"; ?>
<link rel="stylesheet" href="assets/responsive.css">
<style>
/* ── PAGE LAYOUT ── */
body { margin: 0; }
.page-title .subtitle { color:var(--gold-light);letter-spacing:7px;font-size:12px;margin-bottom:6px }
.page-title h1 { font-size:44px;line-height:1;color:var(--cream) }
.topbar { display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:32px;flex-wrap:wrap }
.topbar-left { display:flex;align-items:center;gap:18px }
.topbar-right { display:flex;align-items:center;gap:12px }
.session-box { padding:11px 18px;border-radius:999px;background:rgba(13,6,0,.65);border:1px solid rgba(var(--gold-rgb),.25);color:var(--cream2);font-size:14px;white-space:nowrap }

/* ── MSG ── */
.msg { padding:14px 18px;border-radius:var(--radius);margin-bottom:24px;font-size:15px;font-weight:bold }
.msg.success { background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.35);color:#86efac }
.msg.error   { background:rgba(239,68,68,.12);border:1px solid rgba(239,68,68,.35);color:#fca5a5 }
.msg.info    { background:rgba(var(--gold-rgb),.10);border:1px solid rgba(var(--gold-rgb),.30);color:var(--gold-light) }

/* ── LAYOUT ── */
.layout { display:grid;grid-template-columns:1fr 360px;gap:26px;align-items:start }

/* ── PANEL ── */
.panel { border:1px solid var(--border-color);border-radius:var(--radius-lg);background:var(--card-bg);box-shadow:var(--shadow-card);overflow:hidden;margin-bottom:22px }
.panel-header { padding:20px 26px;border-bottom:1px solid var(--border-color);display:flex;align-items:center;justify-content:space-between }
.panel-header h2 { color:var(--gold-light);font-size:24px }
.panel-header .section-icon { font-size:20px }
.panel-body { padding:24px 26px }

/* ── FORM ── */
.form-grid { display:grid;grid-template-columns:1fr 1fr;gap:16px }
.form-group { display:flex;flex-direction:column;gap:7px }
.form-group.full { grid-column:1/-1 }
label { font-size:13px;color:var(--cream2) }
input[type=text],input[type=number],select {
  padding:11px 14px;border-radius:var(--radius-sm);
  border:1px solid var(--border-color);
  background:var(--input-bg);color:var(--cream);
  font-size:14px;width:100%;outline:none;
}
input[type=text]:focus,input[type=number]:focus,select:focus {
  border-color:var(--gold);box-shadow:0 0 0 3px rgba(var(--gold-rgb),.13)
}
input[type=file] { padding:10px 14px;border-radius:var(--radius-sm);border:1px solid var(--border-color);background:var(--input-bg);color:var(--cream);cursor:pointer;width:100%;font-size:13px }
input[type=file]::file-selector-button { background:var(--grad-primary);color:#140900;border:none;padding:6px 12px;border-radius:var(--radius-sm);cursor:pointer;font-size:13px;margin-right:10px }

/* Color pickers */
.color-row { display:grid;grid-template-columns:1fr 1fr;gap:16px }
.color-group { display:flex;flex-direction:column;gap:7px }
.color-input-wrap { display:flex;align-items:center;gap:10px;padding:8px 12px;border-radius:var(--radius-sm);border:1px solid var(--border-color);background:var(--input-bg) }
.color-input-wrap input[type=color] { width:36px;height:36px;padding:3px;border:none;background:transparent;cursor:pointer;border-radius:8px }
.color-hex { flex:1;background:transparent;border:none;color:var(--cream);font-size:14px;outline:none;padding:0 }
.color-hint { font-size:11px;color:rgba(245,234,216,.4) }

/* Range */
input[type=range] { -webkit-appearance:none;width:100%;height:5px;background:rgba(var(--gold-rgb),.2);border-radius:3px;border:none;padding:0;cursor:pointer }
input[type=range]::-webkit-slider-thumb { -webkit-appearance:none;width:18px;height:18px;border-radius:50%;background:var(--grad-primary);cursor:pointer }
.range-row { display:flex;align-items:center;gap:12px }
.range-val { min-width:44px;text-align:center;padding:6px 8px;border-radius:var(--radius-sm);background:rgba(var(--gold-rgb),.10);border:1px solid rgba(var(--gold-rgb),.22);color:var(--gold-light);font-size:13px }

/* Toggle */
.toggle-row { display:flex;align-items:center;justify-content:space-between;gap:12px;padding:13px 15px;border-radius:var(--radius-sm);background:rgba(var(--gold-rgb),.05);border:1px solid rgba(var(--gold-rgb),.12) }
.toggle-label { font-size:14px;color:var(--cream2) }
.toggle-desc { font-size:11px;color:rgba(245,234,216,.45);margin-top:2px }
.switch { position:relative;display:inline-block;width:46px;height:24px;flex-shrink:0 }
.switch input { opacity:0;width:0;height:0 }
.slider-sw { position:absolute;inset:0;background:rgba(var(--gold-rgb),.18);border-radius:12px;cursor:pointer;transition:.3s;border:1px solid rgba(var(--gold-rgb),.2) }
.slider-sw:before { content:"";position:absolute;height:16px;width:16px;left:3px;bottom:3px;background:rgba(245,234,216,.6);border-radius:50%;transition:.3s }
input:checked+.slider-sw { background:var(--grad-primary) }
input:checked+.slider-sw:before { transform:translateX(22px);background:#140900 }

/* File preview */
.file-preview { display:flex;align-items:center;gap:12px;padding:9px 13px;border-radius:var(--radius-sm);background:rgba(34,197,94,.07);border:1px solid rgba(34,197,94,.2);margin-top:6px }
.file-preview img { width:40px;height:40px;object-fit:cover;border-radius:8px;border:1px solid rgba(var(--gold-rgb),.2) }
.file-preview-name { font-size:12px;color:rgba(245,234,216,.65);flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap }
.btn-remove { padding:4px 9px;border-radius:var(--radius-sm);font-size:12px;background:rgba(239,68,68,.12);border:1px solid rgba(239,68,68,.3);color:#fca5a5;cursor:pointer }

/* Action buttons */
.btn { padding:12px 20px;border-radius:var(--radius);background:var(--grad-primary);color:#140900;font-weight:bold;border:none;cursor:pointer;font-size:14px;transition:.2s }
.btn:hover { opacity:.88;transform:translateY(-1px) }
.btn-danger { padding:11px 18px;border-radius:var(--radius);background:rgba(239,68,68,.10);color:#fca5a5;border:1px solid rgba(239,68,68,.28);cursor:pointer;font-size:13px }
.form-actions { display:flex;gap:12px;margin-top:22px;flex-wrap:wrap;align-items:center }
.last-saved { font-size:12px;color:rgba(245,234,216,.4);margin-top:10px;text-align:right }

/* ── PREVIEW PANEL ── */
.preview-panel { border:1px solid var(--border-color);border-radius:var(--radius-lg);overflow:hidden;position:sticky;top:24px;box-shadow:var(--shadow-card) }
.preview-header { padding:16px 20px;border-bottom:1px solid var(--border-color);background:rgba(13,6,0,.85);display:flex;align-items:center;gap:10px }
.preview-header h3 { color:var(--gold-light);font-size:16px }
.preview-dots { display:flex;gap:6px }
.preview-dots span { width:10px;height:10px;border-radius:50% }
.dot-red{background:#ff5f56}.dot-yellow{background:#ffbd2e}.dot-green{background:#27c93f}
.preview-body { padding:22px;min-height:380px;transition:.35s }
.prev-logo-wrap { display:flex;align-items:center;gap:12px;margin-bottom:18px }
.prev-logo-box { width:42px;height:42px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:bold;flex-shrink:0;transition:.3s }
.prev-brand-name { font-size:20px;font-weight:bold;line-height:1;transition:.3s }
.prev-brand-sub { font-size:10px;letter-spacing:3px;margin-top:3px;opacity:.55;transition:.3s }
.prev-section-title { font-size:10px;letter-spacing:3px;margin-bottom:14px;opacity:.5;transition:.3s }
.prev-cards { display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px }
.prev-card { padding:12px;border-radius:10px;transition:.3s }
.prev-card-label { font-size:9px;opacity:.55;margin-bottom:3px;transition:.3s }
.prev-card-val { font-size:18px;font-weight:bold;transition:.3s }
.prev-btn { display:inline-block;padding:9px 16px;border-radius:10px;font-size:13px;font-weight:bold;text-decoration:none;transition:.3s;color:#140900;margin-right:8px }
.prev-tag { display:inline-block;padding:4px 10px;border-radius:999px;font-size:10px;font-weight:bold;transition:.3s }
.prev-sidebar { display:flex;flex-direction:column;gap:5px;margin-top:14px }
.prev-sidebar-item { padding:6px 10px;border-radius:7px;font-size:10px;transition:.3s }

@media(max-width:1200px){.layout{grid-template-columns:1fr}.preview-panel{position:relative;top:0}}
@media(max-width:900px){.form-grid{grid-template-columns:1fr}.color-row{grid-template-columns:1fr}}
</style>
<style id="sidebar-fixed">
/* ── TOPBAR UNIFICADO ── */
.topbar,.page-topbar{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:32px;flex-wrap:wrap}
.topbar-left,.topbar-right{display:flex;align-items:center;gap:12px}
.page-subtitle,.subtitle{color:var(--gold-light,#e8c97a);letter-spacing:7px;font-size:12px;margin-bottom:6px;display:block}
.session-box,.session,.user-box{
  padding:11px 20px;
  border-radius:999px;
  background:rgba(13,6,0,.65);
  border:1px solid rgba(var(--gold-rgb,201,168,76),.25);
  color:var(--cream2,#ede0c4);
  font-size:14px;
  white-space:nowrap;
  font-family:var(--font,Georgia),serif;
}

/* ── SIDEBAR FIXA ── */
.admin-layout{display:block;margin:0;padding:0}
.sidebar{
  width:285px;min-width:285px;padding:26px 24px;
  background:var(--sidebar-gradient,linear-gradient(180deg,rgba(26,14,4,.98),rgba(13,6,0,.96)));
  border-right:1px solid rgba(var(--gold-rgb,201,168,76),.22);
  position:fixed!important;top:0;left:0;
  height:100vh;overflow-y:auto;overflow-x:hidden;
  z-index:100;display:flex;flex-direction:column;
}
.sidebar::-webkit-scrollbar{width:4px}
.sidebar::-webkit-scrollbar-thumb{background:rgba(201,168,76,.25);border-radius:2px}
.content{margin-left:285px!important;padding:34px 46px;overflow-x:auto;min-height:100vh}
.sidebar .sidebar-logo{display:flex!important;flex-direction:row!important;align-items:center!important;gap:14px!important;margin-bottom:42px!important;flex-shrink:0}
.sidebar .logo-box{width:56px!important;height:56px!important;border-radius:var(--radius,18px)!important;background:var(--grad-primary,linear-gradient(135deg,#c9a84c,#e8c97a))!important;color:#140900!important;display:flex!important;align-items:center!important;justify-content:center!important;font-size:28px!important;font-weight:bold!important;flex-shrink:0!important}
.sidebar .sidebar-logo h2{color:var(--gold-light,#e8c97a)!important;font-size:24px!important;line-height:1!important;margin:0!important}
.sidebar .sidebar-logo span{font-size:12px!important;color:rgba(245,234,216,.55)!important;letter-spacing:2px!important;display:block!important}
.menu-title{font-size:12px;color:rgba(245,234,216,.45);letter-spacing:3px;margin-bottom:16px;flex-shrink:0}
.side-menu{display:flex;flex-direction:column;gap:10px;flex:1}
.side-menu a{padding:14px 16px;border-radius:var(--radius,16px);color:var(--cream2,#ede0c4);text-decoration:none;background:rgba(var(--gold-rgb,201,168,76),.06);border:1px solid rgba(var(--gold-rgb,201,168,76),.12);transition:.22s ease;font-size:var(--fs-base,15px);display:block}
.side-menu a:hover,.side-menu a.active{background:var(--grad-primary,linear-gradient(135deg,#c9a84c,#e8c97a));color:#140900;font-weight:bold;transform:translateX(4px)}
.sidebar .logout{margin-top:18px;flex-shrink:0;display:block;padding:14px;border-radius:var(--radius,14px);text-align:center;color:#fca5a5;text-decoration:none;border:1px solid rgba(239,68,68,.35);background:rgba(239,68,68,.08);font-size:var(--fs-base,15px);font-weight:bold;transition:.2s}
.sidebar .logout:hover{background:rgba(239,68,68,.18)}
@media(max-width:900px){
  .admin-layout{display:block;margin:0;padding:0}
  .sidebar{position:relative!important;width:100%!important;min-width:100%!important;height:auto!important;overflow:visible!important}
  .content,main.content{margin-left:0!important;padding:24px 18px;overflow-x:auto;min-height:auto;width:100%!important}
  .side-menu a{padding:11px 14px}
  .side-menu a:hover,.side-menu a.active{transform:none}
}
</style>
<link rel="stylesheet" href="assets/responsive_global.css">
</head>

<body>
<div class="admin-layout">
  <?php include "sidebar_admin.php"; ?>

  <main class="content" style="display:block;min-height:100vh;box-sizing:border-box">
    <div class="topbar">
      <div class="topbar-left">
        <div class="page-title">
          <p class="subtitle">RESTAURANT MANAGEMENT</p>
          <h1>Personalização</h1>
        </div>
      </div>
      <div class="topbar-right">
        <div class="session-box">Sessão iniciada como: <strong><?= htmlspecialchars($adminName) ?></strong></div>
        
      </div>
    </div>

    <?php if ($msg !== ""): ?>
      <div class="msg <?= $msgType ?>"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data" id="settingsForm">
      <div class="layout">

        <!-- COLUNA ESQUERDA -->
        <div>

          <!-- Identidade -->
          <div class="panel">
            <div class="panel-header"><h2>Identidade</h2><span class="section-icon">🏷️</span></div>
            <div class="panel-body">
              <div class="form-grid">
                <div class="form-group full">
                  <label>Nome do Restaurante</label>
                  <input type="text" name="restaurant_name" id="inp_name"
                    value="<?= htmlspecialchars($settings["restaurant_name"] ?? "SmartTable") ?>"
                    oninput="updatePreview()">
                </div>
                <div class="form-group">
                  <label>Logotipo (PNG, JPG, SVG)</label>
                  <input type="file" name="logo" accept="image/*">
                  <?php if (!empty($settings["logo"])): ?>
                    <div class="file-preview">
                      <img src="<?= htmlspecialchars($settings["logo"]) ?>" alt="Logo">
                      <span class="file-preview-name"><?= basename($settings["logo"]) ?></span>
                      <button type="submit" name="remove_logo" value="1" class="btn-remove" onclick="return confirm('Remover logotipo?')">Remover</button>
                    </div>
                  <?php endif; ?>
                </div>
                <div class="form-group">
                  <label>Imagem de Fundo</label>
                  <input type="file" name="background_image" accept="image/*">
                  <?php if (!empty($settings["background_image"])): ?>
                    <div class="file-preview">
                      <img src="<?= htmlspecialchars($settings["background_image"]) ?>" alt="Fundo">
                      <span class="file-preview-name"><?= basename($settings["background_image"]) ?></span>
                      <button type="submit" name="remove_bg" value="1" class="btn-remove" onclick="return confirm('Remover fundo?')">Remover</button>
                    </div>
                  <?php endif; ?>
                </div>
              </div>
            </div>
          </div>

          <!-- Cores Principais -->
          <div class="panel">
            <div class="panel-header"><h2>Cores Principais</h2><span class="section-icon">🎨</span></div>
            <div class="panel-body">
              <div class="color-row">
                <?php
                $colorFields = [
                  "primary_color"    => ["Cor Principal",   "#c9a84c", "Botões, links ativos, destaques"],
                  "secondary_color"  => ["Cor Secundária",  "#e8c97a", "Hover, gradientes"],
                  "background_color" => ["Cor de Fundo",    "#0d0600", "Fundo geral do sistema"],
                  "text_color"       => ["Cor do Texto",    "#f5ead8", "Texto em todo o sistema"],
                  "accent_color"     => ["Cor de Destaque", "#86efac", "Badges, confirmações"],
                ];
                foreach ($colorFields as $fname => [$label, $default, $hint]):
                  $val = htmlspecialchars($settings[$fname] ?? $default);
                ?>
                <div class="color-group">
                  <label><?= $label ?></label>
                  <div class="color-input-wrap">
                    <input type="color" name="<?= $fname ?>" id="color_<?= $fname ?>"
                      value="<?= $val ?>" oninput="syncHex(this,'hex_<?= $fname ?>');updatePreview()">
                    <input type="text" id="hex_<?= $fname ?>" class="color-hex"
                      value="<?= $val ?>" maxlength="7"
                      oninput="syncColor(this,'color_<?= $fname ?>');updatePreview()">
                  </div>
                  <span class="color-hint"><?= $hint ?></span>
                </div>
                <?php endforeach; ?>
              </div>
            </div>
          </div>

          <!-- Cores de Superfície -->
          <div class="panel">
            <div class="panel-header"><h2>Cores de Superfície</h2><span class="section-icon">🖼️</span></div>
            <div class="panel-body">
              <div class="color-row">
                <?php
                $surfaceFields = [
                  "sidebar_bg"   => ["Fundo da Sidebar",  "#110800", "Cor de fundo do menu lateral"],
                  "card_bg"      => ["Fundo dos Cards",   "#1a0e04", "Painéis, cards, secções"],
                  "border_color" => ["Cor das Bordas",    "#3a2a10", "Linhas divisórias e contornos"],
                  "input_bg"     => ["Fundo dos Inputs",  "#0d0600", "Campos de texto e selects"],
                ];
                foreach ($surfaceFields as $fname => [$label, $default, $hint]):
                  $val = htmlspecialchars($settings[$fname] ?? $default);
                ?>
                <div class="color-group">
                  <label><?= $label ?></label>
                  <div class="color-input-wrap">
                    <input type="color" name="<?= $fname ?>" id="color_<?= $fname ?>"
                      value="<?= $val ?>" oninput="syncHex(this,'hex_<?= $fname ?>');updatePreview()">
                    <input type="text" id="hex_<?= $fname ?>" class="color-hex"
                      value="<?= $val ?>" maxlength="7"
                      oninput="syncColor(this,'color_<?= $fname ?>');updatePreview()">
                  </div>
                  <span class="color-hint"><?= $hint ?></span>
                </div>
                <?php endforeach; ?>
              </div>
            </div>
          </div>

          <!-- Tipografia e Layout -->
          <div class="panel">
            <div class="panel-header"><h2>Tipografia &amp; Layout</h2><span class="section-icon">✏️</span></div>
            <div class="panel-body">
              <div class="form-grid">
                <div class="form-group">
                  <label>Tipo de Letra</label>
                  <select name="font_family" id="inp_font" onchange="updatePreview()">
                    <?php
                    $fonts = ["Georgia"=>"Georgia (padrão)","'Times New Roman'"=>"Times New Roman","Arial"=>"Arial","Verdana"=>"Verdana","Trebuchet MS"=>"Trebuchet MS","'Courier New'"=>"Courier New","Palatino"=>"Palatino","Garamond"=>"Garamond"];
                    foreach ($fonts as $val => $label):
                      echo "<option value=\"$val\" " . sel(($settings["font_family"] ?? "Georgia"), $val) . ">$label</option>";
                    endforeach;
                    ?>
                  </select>
                </div>
                <div class="form-group">
                  <label>Estilo da Sidebar</label>
                  <select name="sidebar_style" id="inp_sidebar" onchange="updatePreview()">
                    <option value="dark"    <?= sel($settings["sidebar_style"] ?? "dark","dark")    ?>>Escuro (padrão)</option>
                    <option value="gold"    <?= sel($settings["sidebar_style"] ?? "dark","gold")    ?>>Dourado</option>
                    <option value="neutral" <?= sel($settings["sidebar_style"] ?? "dark","neutral") ?>>Neutro</option>
                  </select>
                </div>
                <div class="form-group">
                  <label>Intensidade das Sombras</label>
                  <select name="shadow_intensity" id="inp_shadow" onchange="updatePreview()">
                    <option value="none"   <?= sel($settings["shadow_intensity"] ?? "medium","none")   ?>>Sem sombras</option>
                    <option value="subtle" <?= sel($settings["shadow_intensity"] ?? "medium","subtle") ?>>Subtil</option>
                    <option value="medium" <?= sel($settings["shadow_intensity"] ?? "medium","medium") ?>>Médio (padrão)</option>
                    <option value="strong" <?= sel($settings["shadow_intensity"] ?? "medium","strong") ?>>Forte</option>
                  </select>
                </div>
                <div class="form-group" style="justify-content:flex-end"><!-- espaço --></div>
                <div class="form-group full">
                  <label>Tamanho do Texto Base — <span id="fs_val"><?= $settings["font_size"] ?? 15 ?></span>px</label>
                  <div class="range-row">
                    <input type="range" name="font_size" id="inp_fs" min="12" max="20" step="1"
                      value="<?= intval($settings["font_size"] ?? 15) ?>"
                      oninput="document.getElementById('fs_val').textContent=this.value;document.getElementById('fs_badge').textContent=this.value+'px';updatePreview()">
                    <div class="range-val" id="fs_badge"><?= $settings["font_size"] ?? 15 ?>px</div>
                  </div>
                </div>
                <div class="form-group full">
                  <label>Arredondamento dos Cantos — <span id="br_val"><?= $settings["border_radius"] ?? 14 ?></span>px</label>
                  <div class="range-row">
                    <input type="range" name="border_radius" id="inp_br" min="0" max="28" step="1"
                      value="<?= intval($settings["border_radius"] ?? 14) ?>"
                      oninput="document.getElementById('br_val').textContent=this.value;document.getElementById('br_badge').textContent=this.value+'px';updatePreview()">
                    <div class="range-val" id="br_badge"><?= $settings["border_radius"] ?? 14 ?>px</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Opções de Interface -->
          <div class="panel">
            <div class="panel-header"><h2>Opções de Interface</h2><span class="section-icon">⚙️</span></div>
            <div class="panel-body" style="display:flex;flex-direction:column;gap:10px">
              <div class="toggle-row">
                <div>
                  <div class="toggle-label">Mostrar nome junto ao logotipo</div>
                  <div class="toggle-desc">Exibe o nome na barra lateral</div>
                </div>
                <label class="switch">
                  <input type="checkbox" name="show_logo_text" id="tog_logotext"
                    <?= chk($settings["show_logo_text"] ?? 1) ?> onchange="updatePreview()">
                  <span class="slider-sw"></span>
                </label>
              </div>
              <div class="toggle-row">
                <div>
                  <div class="toggle-label">Modo compacto</div>
                  <div class="toggle-desc">Reduz espaçamentos em todo o sistema</div>
                </div>
                <label class="switch">
                  <input type="checkbox" name="compact_mode" id="tog_compact"
                    <?= chk($settings["compact_mode"] ?? 0) ?> onchange="updatePreview()">
                  <span class="slider-sw"></span>
                </label>
              </div>
            </div>
          </div>

          <!-- Ações -->
          <div class="form-actions">
            <button type="submit" class="btn">💾 Guardar Personalização</button>
            <button type="submit" name="reset_defaults" value="1" class="btn-danger"
              onclick="return confirm('Repor todos os valores predefinidos?')">↺ Repor Predefinições</button>
          </div>
          <?php if (!empty($settings["updated_at"])): ?>
            <p class="last-saved">Última gravação: <?= htmlspecialchars($settings["updated_at"]) ?></p>
          <?php endif; ?>

        </div><!-- /left col -->

        <!-- COLUNA DIREITA: preview -->
        <div>
          <div class="preview-panel">
            <div class="preview-header">
              <div class="preview-dots">
                <span class="dot-red"></span><span class="dot-yellow"></span><span class="dot-green"></span>
              </div>
              <h3>Pré-visualização em tempo real</h3>
            </div>
            <div class="preview-body" id="previewBody">
              <div class="prev-logo-wrap">
                <img src="assets/logo.png" alt="SmartTable" style="height:72px;width:auto;object-fit:contain">
                <div id="prev_brand_wrap">
                  <div class="prev-brand-name" id="prev_name"><?= htmlspecialchars($settings["restaurant_name"] ?? "SmartTable") ?></div>
                  <div class="prev-brand-sub">ADMIN PANEL</div>
                </div>
              </div>
              <div class="prev-section-title" id="prev_subtitle">RESTAURANT MANAGEMENT</div>
              <div class="prev-cards">
                <div class="prev-card" id="prev_card1">
                  <div class="prev-card-label">Mesas Ativas</div>
                  <div class="prev-card-val" id="prev_card1_val">12</div>
                </div>
                <div class="prev-card" id="prev_card2">
                  <div class="prev-card-label">Pedidos Hoje</div>
                  <div class="prev-card-val" id="prev_card2_val">48</div>
                </div>
              </div>
              <div style="margin-bottom:12px">
                <a href="#" class="prev-btn" id="prev_btn">Abrir Dashboard</a>
                <span class="prev-tag" id="prev_tag">Admin</span>
              </div>
              <div class="prev-sidebar" id="prev_sidebar">
                <div class="prev-sidebar-item" id="ps1">Gestão de Mesas</div>
                <div class="prev-sidebar-item" id="ps2">Personalização</div>
                <div class="prev-sidebar-item" id="ps3">Pagamentos</div>
              </div>
            </div>
          </div>
        </div>

      </div><!-- /layout -->
    </form>
  </main>
</div>

<script>
function syncHex(picker, hexId) { document.getElementById(hexId).value = picker.value; }
function syncColor(hexInput, colorId) {
  if (/^#[0-9A-Fa-f]{6}$/.test(hexInput.value)) {
    document.getElementById(colorId).value = hexInput.value;
    updatePreview();
  }
}

function updatePreview() {
  const pb = document.getElementById("previewBody");
  if (!pb) return;

  const primary   = document.getElementById("color_primary_color")?.value   || "#c9a84c";
  const secondary = document.getElementById("color_secondary_color")?.value || "#e8c97a";
  const bg        = document.getElementById("color_background_color")?.value || "#0d0600";
  const text      = document.getElementById("color_text_color")?.value      || "#f5ead8";
  const accent    = document.getElementById("color_accent_color")?.value    || "#86efac";
  const sidebarBg = document.getElementById("color_sidebar_bg")?.value      || "#110800";
  const cardBg    = document.getElementById("color_card_bg")?.value         || "#1a0e04";
  const borderCol = document.getElementById("color_border_color")?.value    || "#3a2a10";
  const font      = document.getElementById("inp_font")?.value              || "Georgia";
  const fs        = document.getElementById("inp_fs")?.value                || "15";
  const br        = document.getElementById("inp_br")?.value                || "14";
  const name      = document.getElementById("inp_name")?.value              || "SmartTable";
  const showText  = document.getElementById("tog_logotext")?.checked;
  const compact   = document.getElementById("tog_compact")?.checked;
  const shadow    = document.getElementById("inp_shadow")?.value            || "medium";

  // fundo
  pb.style.background = bg;
  pb.style.fontFamily = font + ", Georgia, serif";
  pb.style.fontSize = fs + "px";

  // nome
  const pname = document.getElementById("prev_name");
  if (pname) { pname.textContent = name; pname.style.color = text; pname.style.fontSize = compact ? "16px" : "20px"; }

  const pbwrap = document.getElementById("prev_brand_wrap");
  if (pbwrap) pbwrap.style.display = showText ? "block" : "none";

  // logo box
  const lb = document.getElementById("prev_logo_box");
  if (lb) { lb.style.background = `linear-gradient(135deg,${primary},${secondary})`; lb.style.borderRadius = br + "px"; }

  // subtitle
  const st = document.getElementById("prev_subtitle");
  if (st) st.style.color = primary;

  // cards
  [["prev_card1","prev_card1_val"],["prev_card2","prev_card2_val"]].forEach(([cid,vid]) => {
    const c = document.getElementById(cid);
    if (c) { c.style.background = cardBg; c.style.border = `1px solid ${borderCol}`; c.style.borderRadius = Math.max(4,parseInt(br)-2)+"px"; c.style.padding = compact ? "9px" : "12px"; }
    const v = document.getElementById(vid);
    if (v) { v.style.color = text; v.style.fontFamily = font; }
  });

  // botão
  const btn = document.getElementById("prev_btn");
  if (btn) { btn.style.background = `linear-gradient(135deg,${primary},${secondary})`; btn.style.borderRadius = br+"px"; btn.style.fontFamily = font; btn.style.padding = compact ? "7px 13px" : "9px 16px"; }

  // tag
  const tag = document.getElementById("prev_tag");
  if (tag) { tag.style.background = accent+"22"; tag.style.color = accent; tag.style.border = `1px solid ${accent}55`; tag.style.fontFamily = font; }

  // sidebar preview
  const shadowVal = { none:"none", subtle:"0 2px 8px rgba(0,0,0,.2)", medium:"0 8px 24px rgba(0,0,0,.35)", strong:"0 14px 40px rgba(0,0,0,.55)" }[shadow] || "none";
  ["ps1","ps2","ps3"].forEach((id, i) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.style.background = i === 1 ? `linear-gradient(135deg,${primary},${secondary})` : sidebarBg;
    el.style.color = i === 1 ? "#140900" : text;
    el.style.borderRadius = br + "px";
    el.style.fontFamily = font;
    el.style.fontSize = Math.max(10, parseInt(fs)-3) + "px";
    el.style.boxShadow = i === 1 ? shadowVal : "none";
  });

  // badges
  document.getElementById("fs_badge").textContent = fs + "px";
  document.getElementById("br_badge").textContent = br + "px";
}

document.addEventListener("DOMContentLoaded", updatePreview);
</script>
<script src="assets/keep_session.js"></script>
</body>
</html>
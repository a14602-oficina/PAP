<?php
/**
 * theme.php — Tema dinâmico do SmartTable
 * Incluir dentro do <head>
<link rel="icon" href="favicon.ico" sizes="any">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="apple-touch-icon" href="assets/logo.png">
<link rel="manifest" href="site.webmanifest">
<meta name="theme-color" content="#0d0600">
 */
if (!isset($conn)) require_once __DIR__ . "/config/db.php";

$_theme = [];
$_tRes  = $conn->query("SELECT * FROM system_settings LIMIT 1");
if ($_tRes && $_tRes->num_rows > 0) {
    $_theme = $_tRes->fetch_assoc();
}

$_t = [
    'primary_color'    => $_theme['primary_color']    ?? '#c9a84c',
    'secondary_color'  => $_theme['secondary_color']  ?? '#e8c97a',
    'background_color' => $_theme['background_color'] ?? '#0d0600',
    'text_color'       => $_theme['text_color']       ?? '#f5ead8',
    'accent_color'     => $_theme['accent_color']     ?? '#86efac',
    'sidebar_bg'       => $_theme['sidebar_bg']       ?? '#110800',
    'card_bg'          => $_theme['card_bg']          ?? '#1a0e04',
    'border_color'     => $_theme['border_color']     ?? '#3a2a10',
    'input_bg'         => $_theme['input_bg']         ?? '#0d0600',
    'font_family'      => $_theme['font_family']      ?? 'Georgia',
    'font_size'        => intval($_theme['font_size']  ?? 15),
    'border_radius'    => intval($_theme['border_radius'] ?? 14),
    'shadow_intensity' => $_theme['shadow_intensity'] ?? 'medium',
    'restaurant_name'  => $_theme['restaurant_name']  ?? 'SmartTable',
    'logo'             => $_theme['logo']             ?? null,
    'compact_mode'     => intval($_theme['compact_mode'] ?? 0),
    'sidebar_style'    => $_theme['sidebar_style']    ?? 'dark',
];

if (!function_exists('_lighten')) {
    function _lighten($hex, $pct = 20) {
        $hex = ltrim($hex, '#');
        if (strlen($hex) === 3) $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
        $r = min(255, max(0, hexdec(substr($hex,0,2)) + round(255*$pct/100)));
        $g = min(255, max(0, hexdec(substr($hex,2,2)) + round(255*$pct/100)));
        $b = min(255, max(0, hexdec(substr($hex,4,2)) + round(255*$pct/100)));
        return sprintf('#%02x%02x%02x', $r, $g, $b);
    }
}

if (!function_exists('_hex2rgb')) {
    function _hex2rgb($hex) {
        $hex = ltrim($hex, '#');
        if (strlen($hex) === 3) $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
        return implode(',', [hexdec(substr($hex,0,2)), hexdec(substr($hex,2,2)), hexdec(substr($hex,4,2))]);
    }
}

$_secondary   = !empty($_theme['secondary_color']) ? $_theme['secondary_color'] : _lighten($_t['primary_color'], 15);
$_pad         = $_t['compact_mode'] ? '0.6em' : '1em';
$_padSm       = $_t['compact_mode'] ? '0.4em' : '0.7em';
$_br          = $_t['border_radius'] . 'px';
$_brSm        = max(4, $_t['border_radius'] - 4) . 'px';
$_brLg        = ($_t['border_radius'] + 6) . 'px';
$_font        = htmlspecialchars($_t['font_family']);
$_fs          = $_t['font_size'] . 'px';
$_fsSm        = max(11, $_t['font_size'] - 2) . 'px';
$_fsLg        = ($_t['font_size'] + 4) . 'px';
$_primRgb     = _hex2rgb($_t['primary_color']);
$_bgRgb       = _hex2rgb($_t['background_color']);
$_accentRgb   = _hex2rgb($_t['accent_color']);

// Shadow intensity
$_shadows = [
    'none'   => ['card' => 'none', 'btn' => 'none', 'modal' => 'none'],
    'subtle' => ['card' => '0 4px 16px rgba(0,0,0,.2)',  'btn' => '0 2px 8px rgba(0,0,0,.15)',  'modal' => '0 8px 32px rgba(0,0,0,.3)'],
    'medium' => ['card' => '0 12px 40px rgba(0,0,0,.35)', 'btn' => '0 4px 16px rgba(0,0,0,.25)', 'modal' => '0 20px 60px rgba(0,0,0,.5)'],
    'strong' => ['card' => '0 20px 60px rgba(0,0,0,.55)', 'btn' => '0 6px 24px rgba(0,0,0,.4)',  'modal' => '0 30px 80px rgba(0,0,0,.7)'],
];
$_sh = $_shadows[$_t['shadow_intensity']] ?? $_shadows['medium'];

// Sidebar colors based on style
$_sidebarBg = match($_t['sidebar_style']) {
    'gold'    => "linear-gradient(180deg,rgba(80,55,5,.98),rgba(50,32,2,.96))",
    'neutral' => "linear-gradient(180deg,rgba(30,25,20,.98),rgba(18,14,10,.96))",
    default   => "linear-gradient(180deg,rgba(26,14,4,.98),rgba(13,6,0,.96))",
};
?>
<style id="smarttable-theme">
:root {
  /* Cores principais */
  --gold:           <?= $_t['primary_color'] ?>;
  --gold-light:     <?= $_secondary ?>;
  --gold-rgb:       <?= $_primRgb ?>;
  --dark:           <?= $_t['background_color'] ?>;
  --dark-rgb:       <?= $_bgRgb ?>;
  --cream:          <?= $_t['text_color'] ?>;
  --cream2:         <?= _lighten($_t['text_color'], -8) ?>;
  --cream3:         <?= _lighten($_t['text_color'], -20) ?>;
  --accent:         <?= $_t['accent_color'] ?>;
  --accent-rgb:     <?= $_accentRgb ?>;

  /* Cores de superfície */
  --sidebar-bg:     <?= htmlspecialchars($_t['sidebar_bg']) ?>;
  --card-bg:        <?= htmlspecialchars($_t['card_bg']) ?>;
  --border-color:   <?= htmlspecialchars($_t['border_color']) ?>;
  --input-bg:       <?= htmlspecialchars($_t['input_bg']) ?>;

  /* Tipografia */
  --font:           <?= $_font ?>, Georgia, "Times New Roman", serif;
  --fs-base:        <?= $_fs ?>;
  --fs-sm:          <?= $_fsSm ?>;
  --fs-lg:          <?= $_fsLg ?>;

  /* Layout */
  --radius:         <?= $_br ?>;
  --radius-sm:      <?= $_brSm ?>;
  --radius-lg:      <?= $_brLg ?>;
  --pad:            <?= $_pad ?>;
  --pad-sm:         <?= $_padSm ?>;

  /* Sombras */
  --shadow-card:    <?= $_sh['card'] ?>;
  --shadow-btn:     <?= $_sh['btn'] ?>;
  --shadow-modal:   <?= $_sh['modal'] ?>;

  /* Gradientes prontos */
  --grad-primary:   linear-gradient(135deg, var(--gold), var(--gold-light));
  --grad-bg:        linear-gradient(135deg, var(--dark), #080300 70%);
  --sidebar-gradient: <?= $_sidebarBg ?>;
}

*, *::before, *::after {
  font-family: var(--font) !important;
  box-sizing: border-box;
}
body {
  font-size: var(--fs-base);
  color: var(--cream);
  background:
    linear-gradient(90deg, rgba(<?= $_primRgb ?>,.04) 1px, transparent 1px),
    linear-gradient(rgba(<?= $_primRgb ?>,.03) 1px, transparent 1px),
    radial-gradient(circle at top left, rgba(<?= $_primRgb ?>,.18), transparent 35%),
    linear-gradient(135deg, <?= $_t['background_color'] ?>, #080300 70%);
  background-size: 80px 80px, 80px 80px, cover, cover;
  background-attachment: fixed;
}

/* Sidebar dinâmica */
.sidebar { background: var(--sidebar-gradient) !important; }
.sidebar .logo-box,
.prev-logo-box { background: var(--grad-primary) !important; border-radius: var(--radius) !important; }
.side-menu a {
  border-radius: var(--radius) !important;
  font-size: var(--fs-base) !important;
  border-color: rgba(var(--gold-rgb), .12) !important;
}
.side-menu a:hover, .side-menu a.active {
  background: var(--grad-primary) !important;
  box-shadow: var(--shadow-btn) !important;
}
.sidebar .logout { border-radius: var(--radius) !important; font-size: var(--fs-base) !important; }

/* Cards */
.panel, .card, [class*="-card"] {
  background: var(--card-bg) !important;
  border-color: var(--border-color) !important;
  border-radius: var(--radius-lg) !important;
  box-shadow: var(--shadow-card) !important;
}

/* Botões principais */
.btn, .add-btn, .send-btn, button[type=submit]:not(.btn-danger):not(.btn-remove):not(.cancel-btn) {
  border-radius: var(--radius) !important;
}

/* Inputs */
input[type=text], input[type=password], input[type=email],
input[type=number], input[type=search], select, textarea {
  background: var(--input-bg) !important;
  border-color: var(--border-color) !important;
  border-radius: var(--radius-sm) !important;
  color: var(--cream) !important;
  font-size: var(--fs-base) !important;
}

/* Badges e tags de estado */
.badge, .status-badge, [class*="badge-"] {
  border-radius: 999px !important;
}
</style>
<?php
/* sidebar_admin.php — sidebar global do painel administrativo */
$currentPage = basename($_SERVER['PHP_SELF']);
?>

<style id="smarttable-sidebar-fix">
/* FIX GLOBAL DA SIDEBAR — impede que CSS das páginas altere logo/botões */
.admin-layout{
  display:flex !important;
  min-height:100vh !important;
}

.admin-layout > .content,
main.content{
  flex:1 !important;
  min-width:0 !important;
  width:auto !important;
  margin-left:285px !important;
  padding:38px 42px !important;
  overflow-x:hidden !important;
}

.sidebar{
  width:285px !important;
  min-width:285px !important;
  max-width:285px !important;
  height:100vh !important;
  position:fixed !important;
  top:0 !important;
  left:0 !important;
  padding:26px 24px !important;
  background:linear-gradient(180deg,rgba(26,14,4,.98),rgba(13,6,0,.96)) !important;
  border-right:1px solid rgba(201,168,76,.22) !important;
  display:flex !important;
  flex-direction:column !important;
  overflow-y:auto !important;
  overflow-x:hidden !important;
  font-family:Georgia,"Times New Roman",serif !important;
  z-index:100 !important;
}

.sidebar-logo{
  width:100% !important;
  display:flex !important;
  flex-direction:row !important;
  align-items:center !important;
  justify-content:flex-start !important;
  gap:14px !important;
  margin:0 0 42px 0 !important;
  padding:0 !important;
  flex-shrink:0 !important;
}

.sidebar-logo a{
  display:block !important;
  width:72px !important;
  height:72px !important;
  min-width:72px !important;
  max-width:72px !important;
  text-decoration:none !important;
  overflow:hidden !important;
  flex-shrink:0 !important;
}

.sidebar-logo img{
  width:72px !important;
  height:72px !important;
  min-width:72px !important;
  max-width:72px !important;
  min-height:72px !important;
  max-height:72px !important;
  object-fit:contain !important;
  display:block !important;
  border-radius:0 !important;
}

.sidebar-logo-text{
  min-width:0 !important;
  display:flex !important;
  flex-direction:column !important;
  justify-content:center !important;
}

.sidebar-logo-text h2{
  margin:0 !important;
  padding:0 !important;
  font-size:24px !important;
  line-height:1 !important;
  color:#e8c97a !important;
  white-space:nowrap !important;
}

.sidebar-logo-text span{
  display:block !important;
  margin-top:5px !important;
  font-size:12px !important;
  line-height:1 !important;
  letter-spacing:2.5px !important;
  color:rgba(245,234,216,.62) !important;
  white-space:nowrap !important;
}

.sidebar .menu-title{
  margin:0 0 16px 0 !important;
  padding:0 !important;
  font-size:12px !important;
  letter-spacing:3px !important;
  color:rgba(245,234,216,.45) !important;
  flex-shrink:0 !important;
}

.sidebar .side-menu{
  display:flex !important;
  flex-direction:column !important;
  gap:10px !important;
  margin:0 !important;
  padding:0 !important;
  flex:0 0 auto !important;
  min-height:0 !important;
}

.sidebar .side-menu a{
  width:100% !important;
  display:block !important;
  padding:14px 16px !important;
  border-radius:14px !important;
  color:#ede0c4 !important;
  text-decoration:none !important;
  background:rgba(201,168,76,.08) !important;
  border:1px solid rgba(201,168,76,.13) !important;
  font-size:15px !important;
  line-height:1.2 !important;
  font-weight:400 !important;
  text-align:left !important;
  transition:.22s ease !important;
  box-shadow:none !important;
}

.sidebar .side-menu a:hover,
.sidebar .side-menu a.active{
  background:linear-gradient(135deg,#c9a84c,#e8c97a) !important;
  color:#140900 !important;
  font-weight:bold !important;
  transform:none !important;
  box-shadow:0 10px 24px rgba(201,168,76,.18) !important;
}

.sidebar .quick-action-wrap{
  flex-shrink:0 !important;
  margin-top:auto !important;
  padding-top:24px !important;
  border-top:1px solid rgba(201,168,76,.12) !important;
}

.sidebar .quick-action-title{
  margin:0 0 10px 0 !important;
  padding:0 !important;
  font-size:12px !important;
  letter-spacing:3px !important;
  color:rgba(245,234,216,.55) !important;
}

.sidebar .sidebar-danger-form{
  width:100% !important;
  margin:0 0 12px 0 !important;
  padding:0 !important;
}

.sidebar .sidebar-danger-btn{
  width:100% !important;
  height:52px !important;
  padding:0 14px !important;
  border-radius:14px !important;
  border:1px solid rgba(239,68,68,.42) !important;
  background:rgba(80,18,12,.38) !important;
  color:#fca5a5 !important;
  font-family:Georgia,"Times New Roman",serif !important;
  font-size:15px !important;
  font-weight:bold !important;
  text-align:center !important;
  cursor:pointer !important;
  box-shadow:none !important;
  display:flex !important;
  align-items:center !important;
  justify-content:center !important;
  transition:.2s ease !important;
}

.sidebar .sidebar-danger-btn:hover{
  background:rgba(127,29,29,.55) !important;
  color:#fff !important;
  border-color:rgba(239,68,68,.68) !important;
}

.sidebar .logout{
  width:100% !important;
  height:52px !important;
  margin:0 !important;
  padding:0 14px !important;
  border-radius:14px !important;
  border:1px solid rgba(239,68,68,.35) !important;
  background:rgba(239,68,68,.08) !important;
  color:#fca5a5 !important;
  text-decoration:none !important;
  font-size:15px !important;
  font-weight:bold !important;
  display:flex !important;
  align-items:center !important;
  justify-content:center !important;
  text-align:center !important;
  flex-shrink:0 !important;
}

.sidebar .logout:hover{
  background:rgba(239,68,68,.16) !important;
}

@media(max-width:900px){
  .admin-layout{display:block !important; flex-direction:column !important;}
  .sidebar{
    width:100% !important;
    min-width:100% !important;
    max-width:100% !important;
    height:auto !important;
    max-height:none !important;
    position:relative !important;
    overflow:visible !important;
    overflow-y:visible !important;
  }
  .admin-layout > .content,
  main.content{
    display:block !important;
    flex:none !important;
    width:100% !important;
    margin-left:0 !important;
    padding:24px 18px !important;
  }
  .sidebar .quick-action-wrap{margin-top:18px !important;}
}
</style>

<aside class="sidebar">
  <div class="sidebar-logo">
    <a href="admin_dashboard.php" aria-label="SmartTable Admin">
      <img src="assets/logo.png" alt="SmartTable">
    </a>

    <div class="sidebar-logo-text">
      <h2>SmartTable</h2>
      <span>ADMIN PANEL</span>
    </div>
  </div>

  <p class="menu-title">MENU</p>

  <nav class="side-menu">
    <a href="gestao_mesas.php"             class="<?= $currentPage==='gestao_mesas.php'             ? 'active':'' ?>">Gestão de Mesas</a>
    <a href="gestao_utilizadores.php"      class="<?= $currentPage==='gestao_utilizadores.php'      ? 'active':'' ?>">Gestão de Utilizadores</a>
    <a href="gestao_menus.php"             class="<?= $currentPage==='gestao_menus.php'             ? 'active':'' ?>">Gestão de Menus</a>
    <a href="pagamento_dashboard.php"      class="<?= $currentPage==='pagamento_dashboard.php'      ? 'active':'' ?>">Pagamentos</a>
    <a href="personalizacao_dashboard.php" class="<?= $currentPage==='personalizacao_dashboard.php' ? 'active':'' ?>">Personalização</a>
    <a href="gerente_dashboard.php"        class="<?= $currentPage==='gerente_dashboard.php'        ? 'active':'' ?>">Gerente</a>
    <a href="atribuir_mesas.php"           class="<?= $currentPage==='atribuir_mesas.php'           ? 'active':'' ?>">Atribuir Mesas</a>
    <a href="gestao_qrcodes.php"           class="<?= $currentPage==='gestao_qrcodes.php'           ? 'active':'' ?>">QR Codes</a>
    <a href="gestao_restaurante.php"       class="<?= $currentPage==='gestao_restaurante.php'       ? 'active':'' ?>">Restaurante</a>
  </nav>

  <div class="quick-action-wrap">
    <p class="quick-action-title">AÇÃO RÁPIDA</p>

    <form
      method="POST"
      action="admin_dashboard.php"
      class="sidebar-danger-form"
      onsubmit="return confirm('Tem a certeza que pretende libertar todas as mesas e eliminar pedidos/pagamentos? Esta ação deve ser usada apenas no fecho do serviço ou em testes.')"
    >
      <button type="submit" name="clear_occupations" class="sidebar-danger-btn">
        Libertar Mesas
      </button>
    </form>

    <a href="logout.php" class="logout">Terminar Sessão</a>
  </div>
</aside>
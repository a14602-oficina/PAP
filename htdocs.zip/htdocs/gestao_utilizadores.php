<?php
require_once "auth_check.php";
require_once "service_flow.php";
st_ensure_service_flow_columns($conn);

require_once "error_config.php";

require_once "config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "admin") {
    header("Location: login.php");
    exit;
}

/* Garantir que existe a coluna active */
$colCheck = $conn->query("SHOW COLUMNS FROM users LIKE 'active'");
if ($colCheck && $colCheck->num_rows === 0) {
    $conn->query("ALTER TABLE users ADD active TINYINT(1) NOT NULL DEFAULT 1 AFTER role");
}

$msg = "";
$editUser = null;

/* ── LIMPAR PEDIDOS DE UM GARÇOM ── */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["limpar_pedidos_empregado_mesa"])) {
    $empregadoMesaId = intval($_POST["empregado_mesa_id"] ?? 0);
    if ($empregadoMesaId > 0) {
        // Buscar mesas atribuídas a este empregado de mesa
        $stmtMesas = $conn->prepare("SELECT table_number FROM waiter_tables WHERE waiter_id = ?");
        $stmtMesas->bind_param("i", $empregadoMesaId);
        $stmtMesas->execute();
        $mesasRes = $stmtMesas->get_result();

        while ($row = $mesasRes->fetch_assoc()) {
            $tn = intval($row["table_number"]);
            // Cancelar pedidos não pagos dessas mesas
            $stmtCancel = $conn->prepare("UPDATE orders SET status='cancelado' WHERE table_number=? AND status NOT IN ('pago','cancelado')");
            $stmtCancel->bind_param("i", $tn);
            $stmtCancel->execute();
            // Limpar bar_orders
            $stmtBar = $conn->prepare("UPDATE bar_orders SET status='pronto' WHERE table_number=? AND status IN ('pendente','preparando')");
            $stmtBar->bind_param("s", $tn);
            $stmtBar->execute();
            // Reset service flow
            st_reset_table_service_flow($conn, $tn);
        }
        $msg = "✓ Pedidos do empregado de mesa limpos com sucesso.";
    }
}

/* ATIVAR / DESATIVAR UTILIZADOR - TEM DE VIR ANTES DO POST DE CRIAR/EDITAR */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["toggle_user"])) {
    $id = intval($_POST["id"] ?? 0);

    if ($id <= 0) {
        $msg = "Utilizador inválido.";
    } elseif ($id === intval($_SESSION["user_id"])) {
        $msg = "Não podes desativar a tua própria conta.";
    } else {
        $stmt = $conn->prepare("SELECT active FROM users WHERE id = ? LIMIT 1");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $userStatus = $stmt->get_result()->fetch_assoc();

        if (!$userStatus) {
            $msg = "Utilizador não encontrado.";
        } else {
            $newStatus = intval($userStatus["active"]) === 1 ? 0 : 1;

            $update = $conn->prepare("UPDATE users SET active = ? WHERE id = ?");
            $update->bind_param("ii", $newStatus, $id);

            if ($update->execute()) {
                header("Location: gestao_utilizadores.php?msg=" . urlencode($newStatus === 1 ? "Utilizador ativado com sucesso." : "Utilizador desativado com sucesso."));
                exit;
            } else {
                $msg = "Erro ao alterar estado do utilizador.";
            }
        }
    }
}

/* ELIMINAR */
if (isset($_GET["delete"])) {
    $id = intval($_GET["delete"]);

    if ($id !== intval($_SESSION["user_id"])) {
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $msg = "Utilizador eliminado com sucesso.";
    } else {
        $msg = "Não podes eliminar a tua própria conta.";
    }
}

/* BUSCAR PARA EDITAR */
if (isset($_GET["edit"])) {
    $id = intval($_GET["edit"]);
    $stmt = $conn->prepare("SELECT id, username, name, email, role, rfid_code, active FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $editUser = $stmt->get_result()->fetch_assoc();
}

/* CRIAR / ATUALIZAR */
if ($_SERVER["REQUEST_METHOD"] === "POST" && !isset($_POST["toggle_user"])) {
    $id       = intval($_POST["id"] ?? 0);
    $username = trim($_POST["username"] ?? "");
    $password = trim($_POST["password"] ?? "");
    $name     = trim($_POST["name"] ?? "");
    $email    = trim($_POST["email"] ?? "");
    $role     = trim($_POST["role"] ?? "");
    $rfid_code  = trim($_POST["rfid_code"] ?? "");

    if ($username === "" || $name === "" || $email === "" || $role === "" || $rfid_code === "") {
        $msg = "Preenche todos os campos obrigatórios.";
    } else {
        if ($id > 0) {

            $check = $conn->prepare("SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ? LIMIT 1");
            $check->bind_param("ssi", $username, $email, $id);
            $check->execute();
            $exists = $check->get_result();

            if ($exists->num_rows > 0) {
                $msg = "Username ou email já existe.";
            } else {
                if ($password !== "") {
                    $hash = password_hash($password, PASSWORD_DEFAULT);

                    $stmt = $conn->prepare("
                        UPDATE users 
                        SET username=?, password=?, name=?, email=?, role=?, rfid_code=? 
                        WHERE id=?
                    ");
                    $stmt->bind_param("ssssssi", $username, $hash, $name, $email, $role, $rfid_code, $id);
                } else {
                    $stmt = $conn->prepare("
                        UPDATE users 
                        SET username=?, name=?, email=?, role=?, rfid_code=? 
                        WHERE id=?
                    ");
                    $stmt->bind_param("sssssi", $username, $name, $email, $role, $rfid_code, $id);
                }

                $stmt->execute();
                header("Location: gestao_utilizadores.php?msg=" . urlencode("Utilizador atualizado com sucesso."));
                exit;
            }

        } else {
            if ($password === "") {
                $msg = "A password é obrigatória para criar utilizador.";
            } else {
                $check = $conn->prepare("SELECT id FROM users WHERE username=? OR email=? LIMIT 1");
                $check->bind_param("ss", $username, $email);
                $check->execute();
                $exists = $check->get_result();

                if ($exists->num_rows > 0) {
                    $msg = "Username ou email já existe.";
                } else {
                    $hash = password_hash($password, PASSWORD_DEFAULT);

                    $stmt = $conn->prepare("
                        INSERT INTO users (username, password, role, active, name, email, rfid_code)
                        VALUES (?, ?, ?, 1, ?, ?, ?)
                    ");
                    $stmt->bind_param("ssssss", $username, $hash, $role, $name, $email, $rfid_code);
                    $stmt->execute();

                    header("Location: gestao_utilizadores.php?msg=" . urlencode("Utilizador criado com sucesso."));
                    exit;
                }
            }
        }
    }
}

if (isset($_GET["msg"])) {
    $msg = htmlspecialchars($_GET["msg"]);
}

$result = $conn->query("SELECT id, username, name, email, role, active, IFNULL(rfid_code,'') as rfid_code FROM users ORDER BY id DESC");
$adminName = $_SESSION["name"] ?? "Administrador";
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>Gestão de Utilizadores</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="favicon.ico" sizes="any">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="apple-touch-icon" href="assets/logo.png">
<link rel="manifest" href="site.webmanifest">
<meta name="theme-color" content="#0d0600">
<link rel="stylesheet" href="assets/responsive.css">    
<link rel="stylesheet" href="assets/style.css">
<?php include_once __DIR__ . "/theme.php"; ?>
<style>

*{box-sizing:border-box;margin:0;padding:0}
body{
  min-height:100vh;
  font-family:Georgia,"Times New Roman",serif;
  background:
    linear-gradient(90deg,rgba(201,168,76,.04) 1px,transparent 1px),
    linear-gradient(rgba(201,168,76,.03) 1px,transparent 1px),
    radial-gradient(circle at top left,rgba(201,168,76,.18),transparent 35%),
    linear-gradient(135deg,var(--dark),#080300 70%);
  background-size:80px 80px,80px 80px,cover,cover;
  color:var(--cream);
}
.admin-layout{display:block;margin:0;padding:0}

.content{flex:1;padding:34px 46px;margin-left:0}
.topbar{display:flex;align-items:flex-start;justify-content:space-between;gap:24px;margin-bottom:36px}
.subtitle{color:var(--gold-light);letter-spacing:8px;font-size:13px;margin-bottom:6px}
.topbar h1{font-size:46px;line-height:1;color:var(--cream)}
.session{
  padding:14px 22px;border-radius:999px;border:1px solid rgba(201,168,76,.25);
  background:rgba(13,6,0,.65);color:var(--cream2);white-space:nowrap;
}
.panel{
  border:1px solid rgba(201,168,76,.28);border-radius:22px;
  background:linear-gradient(145deg,rgba(38,21,8,.78),rgba(13,6,0,.94));
  box-shadow:0 18px 55px rgba(0,0,0,.35);overflow:hidden;margin-bottom:28px;
}
.panel-header{
  padding:24px 28px;display:flex;justify-content:space-between;align-items:center;
  border-bottom:1px solid rgba(201,168,76,.16);
}
.panel-header h2{color:var(--gold-light);font-size:28px}
.form-body{padding:28px}
.form-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}
.form-group{display:flex;flex-direction:column}
label{font-size:14px;color:var(--cream2);margin-bottom:8px}
input,select{
  padding:14px 15px;border-radius:13px;border:1px solid rgba(201,168,76,.25);
  background:rgba(13,6,0,.72);color:var(--cream);outline:none;
}
input:focus,select:focus{border-color:var(--gold);box-shadow:0 0 0 3px rgba(201,168,76,.13)}
.btn{
  padding:13px 18px;border-radius:14px;background:linear-gradient(135deg,var(--gold),var(--gold-light));
  color:#140900;text-decoration:none;font-weight:bold;border:none;cursor:pointer;display:inline-block;
}
.btn-secondary{
  padding:13px 18px;border-radius:14px;background:rgba(201,168,76,.09);
  color:var(--gold-light);text-decoration:none;border:1px solid rgba(201,168,76,.22);display:inline-block;
}
.form-actions{margin-top:22px;display:flex;gap:12px}
.msg{
  padding:14px 18px;margin-bottom:24px;border-radius:14px;
  background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.35);
  color:#86efac;
}
.table-wrap{overflow-x:auto}
table{width:100%;border-collapse:collapse;min-width:1000px}
th,td{padding:17px 20px;text-align:left;border-bottom:1px solid rgba(201,168,76,.12);font-size:15px}
th{color:var(--gold-light);background:rgba(201,168,76,.10);font-size:14px;letter-spacing:1px}
td{color:var(--cream2)}
tr:hover td{background:rgba(201,168,76,.045)}
.badge{
  display:inline-block;padding:7px 11px;border-radius:999px;
  background:rgba(201,168,76,.13);border:1px solid rgba(201,168,76,.25);
  color:var(--gold-light);text-transform:uppercase;font-size:12px;
}
.btn-clear-empregado-mesa{padding:5px 10px;border:1px solid rgba(239,68,68,.35);border-radius:8px;background:rgba(239,68,68,.08);color:#fca5a5;font-size:12px;cursor:pointer;font-family:inherit;white-space:nowrap;transition:.2s}
.btn-clear-empregado-mesa:hover{background:rgba(239,68,68,.18)}
.actions{white-space:nowrap}
.actions a{
  display:inline-block;padding:8px 11px;margin-right:7px;border-radius:10px;text-decoration:none;
  color:var(--gold-light);background:rgba(201,168,76,.08);border:1px solid rgba(201,168,76,.18);
}
.actions a:hover{background:linear-gradient(135deg,var(--gold),var(--gold-light));color:#140900}
.delete-link{color:#fca5a5!important;border-color:rgba(239,68,68,.28)!important;background:rgba(239,68,68,.08)!important}
.empty{padding:28px;color:rgba(245,234,216,.65)}
@media(max-width:1100px){.form-grid{grid-template-columns:1fr 1fr}}
@media(max-width:900px){
  .admin-layout{display:block;margin:0;padding:0}
  
  .content{padding:28px 20px;margin-left:285px!important}
  .topbar{flex-direction:column}
  .topbar h1{font-size:36px}
  .session{white-space:normal}
  .form-grid{grid-template-columns:1fr}
}

.status-active{
  display:inline-block;
  padding:6px 10px;
  border-radius:999px;
  background:rgba(34,197,94,.12);
  border:1px solid rgba(34,197,94,.35);
  color:#86efac;
  font-size:12px;
  text-transform:uppercase;
  font-weight:bold;
}

.status-inactive{
  display:inline-block;
  padding:6px 10px;
  border-radius:999px;
  background:rgba(239,68,68,.12);
  border:1px solid rgba(239,68,68,.35);
  color:#fca5a5;
  font-size:12px;
  text-transform:uppercase;
  font-weight:bold;
}

.action-form{
  display:inline-block;
  margin:0 6px 0 0;
}

.action-button{
  display:inline-block;
  padding:8px 10px;
  border-radius:10px;
  color:var(--gold-light);
  background:rgba(201,168,76,.10);
  border:1px solid rgba(201,168,76,.22);
  text-decoration:none;
  font-size:14px;
  cursor:pointer;
  margin:0;
  width:auto;
}

.action-button:hover{
  background:linear-gradient(135deg,var(--gold),var(--gold-light));
  color:#140900;
}

.action-button.danger{
  color:#fca5a5;
  background:rgba(239,68,68,.10);
  border-color:rgba(239,68,68,.35);
}

.action-button.danger:hover{
  background:rgba(239,68,68,.25);
  color:#fff;
}
</style>
<style id="sidebar-fixed">
/* ── TOPBAR UNIFICADO ── */
.topbar,.page-topbar{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:32px;flex-wrap:wrap}
.topbar-left,.topbar-right{display:flex;align-items:center;gap:12px}
.page-subtitle,.subtitle{color:var(--gold-light,#e8c97a);letter-spacing:7px;font-size:12px;margin-bottom:6px;display:block}
.session-box,.session,.user-box{
  padding:11px 20px;
  border-radius:999px;
  background:rgba(13,6,0,.65);
  border:1px solid rgba(var(--gold-rgb,201,168,76),.25);
  color:var(--cream2,#ede0c4);
  font-size:14px;
  white-space:nowrap;
  font-family:var(--font,Georgia),serif;
}

/* ── SIDEBAR FIXA ── */
.admin-layout{display:block;margin:0;padding:0}
.sidebar{
  width:285px;min-width:285px;padding:26px 24px;
  background:var(--sidebar-gradient,linear-gradient(180deg,rgba(26,14,4,.98),rgba(13,6,0,.96)));
  border-right:1px solid rgba(var(--gold-rgb,201,168,76),.22);
  position:fixed!important;top:0;left:0;
  height:100vh;overflow-y:auto;overflow-x:hidden;
  z-index:100;display:flex;flex-direction:column;
}
.sidebar::-webkit-scrollbar{width:4px}
.sidebar::-webkit-scrollbar-thumb{background:rgba(201,168,76,.25);border-radius:2px}
.content{margin-left:285px!important;padding:34px 46px;overflow-x:auto;min-height:100vh}
.sidebar .sidebar-logo{display:flex!important;flex-direction:row!important;align-items:center!important;gap:14px!important;margin-bottom:42px!important;flex-shrink:0}
.sidebar .logo-box{width:56px!important;height:56px!important;border-radius:var(--radius,18px)!important;background:var(--grad-primary,linear-gradient(135deg,#c9a84c,#e8c97a))!important;color:#140900!important;display:flex!important;align-items:center!important;justify-content:center!important;font-size:28px!important;font-weight:bold!important;flex-shrink:0!important}
.sidebar .sidebar-logo h2{color:var(--gold-light,#e8c97a)!important;font-size:24px!important;line-height:1!important;margin:0!important}
.sidebar .sidebar-logo span{font-size:12px!important;color:rgba(245,234,216,.55)!important;letter-spacing:2px!important;display:block!important}
.menu-title{font-size:12px;color:rgba(245,234,216,.45);letter-spacing:3px;margin-bottom:16px;flex-shrink:0}
.side-menu{display:flex;flex-direction:column;gap:10px;flex:1}
.side-menu a{padding:14px 16px;border-radius:var(--radius,16px);color:var(--cream2,#ede0c4);text-decoration:none;background:rgba(var(--gold-rgb,201,168,76),.06);border:1px solid rgba(var(--gold-rgb,201,168,76),.12);transition:.22s ease;font-size:var(--fs-base,15px);display:block}
.side-menu a:hover,.side-menu a.active{background:var(--grad-primary,linear-gradient(135deg,#c9a84c,#e8c97a));color:#140900;font-weight:bold;transform:translateX(4px)}
.sidebar .logout{margin-top:18px;flex-shrink:0;display:block;padding:14px;border-radius:var(--radius,14px);text-align:center;color:#fca5a5;text-decoration:none;border:1px solid rgba(239,68,68,.35);background:rgba(239,68,68,.08);font-size:var(--fs-base,15px);font-weight:bold;transition:.2s}
.sidebar .logout:hover{background:rgba(239,68,68,.18)}
@media(max-width:900px){
  .admin-layout{display:block;margin:0;padding:0}
  .sidebar{position:relative!important;width:100%!important;min-width:100%!important;height:auto!important;overflow:visible!important}
  .content,main.content{margin-left:0!important;padding:24px 18px;overflow-x:auto;min-height:auto;width:100%!important}
  .side-menu a{padding:11px 14px}
  .side-menu a:hover,.side-menu a.active{transform:none}
}
</style>
<link rel="stylesheet" href="assets/responsive_global.css">
</head>

<body>

<div class="admin-layout">

  <?php include "sidebar_admin.php"; ?>

  <main class="content" style="display:block;min-height:100vh;box-sizing:border-box">

    <div class="topbar">
      <div>
        <p class="subtitle">RESTAURANT MANAGEMENT</p>
        <h1>Gestão de Utilizadores</h1>
      </div>

      <div class="session-box">
        Sessão iniciada como: <strong><?= htmlspecialchars($adminName) ?></strong>
      </div>
    </div>

    <?php if ($msg !== ""): ?>
      <div class="msg"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>

    <section class="panel">
      <div class="panel-header">
        <h2><?= $editUser ? "Editar Utilizador" : "Criar Utilizador" ?></h2>
      </div>

      <div class="form-body">
        <form method="POST" action="gestao_utilizadores.php">
          <input type="hidden" name="id" value="<?= htmlspecialchars($editUser["id"] ?? "") ?>">

          <div class="form-grid">
            <div class="form-group">
              <label>Utilizador</label>
              <input type="text" name="username" required value="<?= htmlspecialchars($editUser["username"] ?? "") ?>">
            </div>

            <div class="form-group">
              <label>Password <?= $editUser ? "(deixa vazio para manter)" : "" ?></label>
              <input type="password" name="password" <?= $editUser ? "" : "required" ?>>
            </div>

            <div class="form-group">
              <label>Nome</label>
              <input type="text" name="name" required value="<?= htmlspecialchars($editUser["name"] ?? "") ?>">
            </div>

            <div class="form-group">
              <label>Email</label>
              <input type="email" name="email" required value="<?= htmlspecialchars($editUser["email"] ?? "") ?>">
            </div>

            <div class="form-group">
              <label>Função</label>
              <select name="role" required>
                <?php
                $roles = ["entrada", "mesa", "empregado_mesa", "cozinha", "bar", "admin"];
                $roleLabels = ["empregado_mesa" => "Empregado de Mesa"];
                foreach ($roles as $role):
                    $selected = (($editUser["role"] ?? "") === $role) ? "selected" : "";
                    $label = $roleLabels[$role] ?? ucfirst($role);
                ?>
                  <option value="<?= $role ?>" <?= $selected ?>><?= $label ?></option>
                <?php endforeach; ?>
              </select>
            </div>

            <div class="form-group">
              <label>RFID / Código</label>
              <input type="text" name="rfid_code" required value="<?= htmlspecialchars($editUser["rfid_code"] ?? "") ?>">
            </div>
          </div>

          <div class="form-actions">
            <button type="submit" class="btn">
              <?= $editUser ? "Guardar Alterações" : "Criar Utilizador" ?>
            </button>

            <?php if ($editUser): ?>
              <a href="gestao_utilizadores.php" class="btn-secondary">Cancelar edição</a>
            <?php endif; ?>
          </div>
        </form>
      </div>
    </section>

    <section class="panel">
      <div class="panel-header">
        <h2>👥 Lista de Utilizadores</h2>
      </div>

      <?php if ($result && $result->num_rows > 0): ?>
        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Utilizador</th>
                <th>Nome</th>
                <th>Email</th>
                <th>Função</th>
                <th>Estado</th>
                <th>RFID</th>
                <th>Ações</th>
              </tr>
            </thead>

            <tbody>
              <?php while($u = $result->fetch_assoc()): ?>
              <tr>
                <td><?= htmlspecialchars($u["id"]) ?></td>
                <td><?= htmlspecialchars($u["username"]) ?></td>
                <td><?= htmlspecialchars($u["name"]) ?></td>
                <td><?= htmlspecialchars($u["email"]) ?></td>
                <td><span class="badge"><?= ($u["role"] === "empregado_mesa") ? "Empregado de Mesa" : htmlspecialchars($u["role"]) ?></span></td>

                <td>
                  <?php if (intval($u["active"]) === 1): ?>
                    <span class="status-active">Ativo</span>
                  <?php else: ?>
                    <span class="status-inactive">Desativado</span>
                  <?php endif; ?>
                </td>

                <td><?= htmlspecialchars($u["rfid_code"] ?? "") ?></td>

                <td class="actions">
                  <a href="gestao_utilizadores.php?edit=<?= urlencode($u["id"]) ?>">Editar</a>

                  <?php if (intval($u["id"]) !== intval($_SESSION["user_id"])): ?>
                    <form method="POST" class="action-form">
                      <input type="hidden" name="id" value="<?= htmlspecialchars($u["id"]) ?>">
                      <button
                        type="submit"
                        name="toggle_user"
                        class="action-button <?= intval($u["active"]) === 1 ? 'danger' : '' ?>"
                        onclick="return confirm('Alterar estado deste utilizador?')"
                      >
                        <?= intval($u["active"]) === 1 ? "Desativar" : "Ativar" ?>
                      </button>
                    </form>

                    <?php if (strtolower($u["role"]) === "empregado_mesa"): ?>
                    <form method="POST" class="action-form"
                          onsubmit="return confirm('Limpar todos os pedidos das mesas deste empregado de mesa?')">
                      <input type="hidden" name="empregado_mesa_id" value="<?= htmlspecialchars($u["id"]) ?>">
                      <button type="submit" name="limpar_pedidos_empregado_mesa" class="btn-clear-empregado-mesa">
                        🗑️ Limpar pedidos
                      </button>
                    </form>
                    <?php endif; ?>

                    <a class="delete-link" href="gestao_utilizadores.php?delete=<?= urlencode($u["id"]) ?>" onclick="return confirm('Eliminar este utilizador?')">Eliminar</a>
                  <?php else: ?>
                    <span class="status-active">A tua conta</span>
                  <?php endif; ?>
                </td>
              </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      <?php else: ?>
        <p class="empty">Nenhum utilizador encontrado.</p>
      <?php endif; ?>
    </section>

  </main>

</div>

<script src="assets/keep_session.js"></script>
</body>
</html>
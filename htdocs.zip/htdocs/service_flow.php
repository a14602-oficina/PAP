<?php
/**
 * service_flow.php — Funções globais do fluxo de refeição.
 * Mantém o prato principal e sobremesa bloqueados por defeito.
 */

function st_column_exists(mysqli $conn, string $table, string $column): bool {
    $table = $conn->real_escape_string($table);
    $column = $conn->real_escape_string($column);
    $result = $conn->query("SHOW COLUMNS FROM `$table` LIKE '$column'");
    return $result && $result->num_rows > 0;
}

function st_ensure_service_flow_columns(mysqli $conn): void {
    $cols = [
        'entries_drinks_delivered_at' => 'DATETIME NULL',
        'main_unlocked' => 'TINYINT(1) NOT NULL DEFAULT 0',
        'main_unlocked_at' => 'DATETIME NULL',
        'main_delivered_at' => 'DATETIME NULL',
        'dessert_unlocked' => 'TINYINT(1) NOT NULL DEFAULT 0',
        'dessert_unlocked_at' => 'DATETIME NULL'
    ];

    foreach ($cols as $col => $def) {
        if (!st_column_exists($conn, 'tables', $col)) {
            $conn->query("ALTER TABLE `tables` ADD COLUMN `$col` $def");
        }
    }
}

function st_reset_table_service_flow(mysqli $conn, int $tableNumber): void {
    st_ensure_service_flow_columns($conn);

    $stmt = $conn->prepare("
        UPDATE `tables`
        SET
            main_unlocked = 0,
            dessert_unlocked = 0,
            entries_drinks_delivered_at = NULL,
            main_unlocked_at = NULL,
            main_delivered_at = NULL,
            dessert_unlocked_at = NULL
        WHERE number = ?
    ");
    $stmt->bind_param('i', $tableNumber);
    $stmt->execute();
}

function st_free_table_after_payment(mysqli $conn, int $tableNumber): void {
    st_ensure_service_flow_columns($conn);

    $stmt = $conn->prepare("
        UPDATE `tables`
        SET
            status = 'livre',
            occupied_seats = 0,
            arrival_time = NULL,
            main_unlocked = 0,
            dessert_unlocked = 0,
            entries_drinks_delivered_at = NULL,
            main_unlocked_at = NULL,
            main_delivered_at = NULL,
            dessert_unlocked_at = NULL
        WHERE number = ?
    ");
    $stmt->bind_param('i', $tableNumber);
    $stmt->execute();
}

function st_reset_service_flow_for_all_tables(mysqli $conn): void {
    st_ensure_service_flow_columns($conn);

    $conn->query("
        UPDATE `tables`
        SET
            main_unlocked = 0,
            dessert_unlocked = 0,
            entries_drinks_delivered_at = NULL,
            main_unlocked_at = NULL,
            main_delivered_at = NULL,
            dessert_unlocked_at = NULL
    ");
}


function st_reset_service_flow_for_free_tables(mysqli $conn): void {
    st_ensure_service_flow_columns($conn);

    $conn->query("
        UPDATE `tables`
        SET
            main_unlocked = 0,
            dessert_unlocked = 0,
            entries_drinks_delivered_at = NULL,
            main_unlocked_at = NULL,
            main_delivered_at = NULL,
            dessert_unlocked_at = NULL
        WHERE status = 'livre'
    ");
}

function st_normalize_menu_category(string $category): string {
    $category = strtolower(trim($category));

    if (str_contains($category, 'entrada')) return 'entrada';
    if (str_contains($category, 'bebida')) return 'bebida';
    if (str_contains($category, 'prato')) return 'prato';
    if (str_contains($category, 'principal')) return 'prato';
    if (str_contains($category, 'sobremesa')) return 'sobremesa';

    return $category;
}

function st_table_access(mysqli $conn, int $tableNumber): array {
    st_ensure_service_flow_columns($conn);

    $stmt = $conn->prepare("
        SELECT main_unlocked, dessert_unlocked, main_delivered_at
        FROM `tables`
        WHERE number = ?
        LIMIT 1
    ");
    $stmt->bind_param('i', $tableNumber);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc() ?: [];

    return [
        'main_unlocked' => intval($row['main_unlocked'] ?? 0),
        'dessert_unlocked' => intval($row['dessert_unlocked'] ?? 0),
        'main_delivered_at' => $row['main_delivered_at'] ?? null,
    ];
}

<?php
require_once "error_config.php";

require_once "auth_check.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "admin") {
    header("Location: login.php");
    exit;
}

$adminName = $_SESSION["name"] ?? $_SESSION["username"] ?? "Administrador";

/* Criar tabela caso não exista */
$conn->query("
    CREATE TABLE IF NOT EXISTS manager_calls (
        id INT AUTO_INCREMENT PRIMARY KEY,
        table_number INT NULL,
        message VARCHAR(255) DEFAULT 'Cliente chamou o gerente',
        status VARCHAR(30) NOT NULL DEFAULT 'pendente',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        resolved_at DATETIME NULL
    )
");

/* Resolver chamada */
if (isset($_GET["resolver"])) {
    $id = intval($_GET["resolver"]);

    if ($id > 0) {
        $stmt = $conn->prepare("
            UPDATE manager_calls
            SET status = 'resolvido',
                resolved_at = NOW()
            WHERE id = ?
        ");
        $stmt->bind_param("i", $id);
        $stmt->execute();
    }

    header("Location: gerente_dashboard.php");
    exit;
}

/* Apenas chamadas pendentes */
$calls = $conn->query("
    SELECT *
    FROM manager_calls
    WHERE status = 'pendente'
    ORDER BY created_at DESC
");
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>SmartTable - 📞 Chamadas do Gerente</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="favicon.ico" sizes="any">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="apple-touch-icon" href="assets/logo.png">
<link rel="manifest" href="site.webmanifest">
<meta name="theme-color" content="#0d0600">

<style>
:root{
    --gold:#c9a84c;
    --gold-light:#e8c97a;
    --dark:#0d0600;
    --cream:#f5ead8;
    --cream2:#ede0c4;
}

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Georgia,"Times New Roman",serif;
}

body{
    min-height:100vh;
    background:
        linear-gradient(90deg,rgba(201,168,76,.04) 1px,transparent 1px),
        linear-gradient(rgba(201,168,76,.03) 1px,transparent 1px),
        radial-gradient(circle at top left,rgba(201,168,76,.18),transparent 35%),
        linear-gradient(135deg,var(--dark),#080300 70%);
    background-size:80px 80px,80px 80px,cover,cover;
    color:var(--cream);
}

/* HEADER */
.header{
    width:100%;
    padding:26px 42px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    background:rgba(13,6,0,.82);
    border-bottom:1px solid rgba(201,168,76,.22);
}

.brand{
    display:flex;
    align-items:center;
    gap:14px;
}

.logo{
    width:58px;
    height:58px;
    border-radius:16px;
    background:linear-gradient(135deg,var(--gold),var(--gold-light));
    color:#140900;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:28px;
    font-weight:bold;
}

.brand span{
    display:block;
    font-size:11px;
    letter-spacing:4px;
    color:var(--gold-light);
}

.brand h1{
    font-size:30px;
    line-height:1;
}

.header-right{
    display:flex;
    align-items:center;
    gap:14px;
}

.user-box{
    padding:13px 18px;
    border-radius:999px;
    border:1px solid rgba(201,168,76,.25);
    background:rgba(13,6,0,.65);
    color:var(--cream2);
    white-space:nowrap;
}

.back-btn{
    padding:13px 18px;
    border-radius:14px;
    border:1px solid rgba(201,168,76,.25);
    background:rgba(13,6,0,.65);
    color:var(--gold-light);
    text-decoration:none;
    font-weight:bold;
}

.back-btn:hover{
    background:linear-gradient(135deg,var(--gold),var(--gold-light));
    color:#140900;
}

/* MAIN */
.main{
    width:100%;
    padding:42px;
}

.subtitle{
    color:var(--gold-light);
    letter-spacing:8px;
    font-size:13px;
    margin-bottom:8px;
}

.title{
    font-size:54px;
    line-height:1.05;
    margin-bottom:34px;
}

/* GRID */
.calls-grid{
    display:grid;
    grid-template-columns:repeat(auto-fill,minmax(340px,1fr));
    gap:24px;
}

/* CARD */
.call-card{
    border:1px solid rgba(201,168,76,.28);
    border-radius:24px;
    background:linear-gradient(145deg,rgba(38,21,8,.82),rgba(13,6,0,.96));
    box-shadow:0 18px 55px rgba(0,0,0,.35);
    overflow:hidden;
}

.call-header{
    padding:22px 24px;
    border-bottom:1px solid rgba(201,168,76,.16);
    display:flex;
    justify-content:space-between;
    align-items:flex-start;
    gap:14px;
}

.call-header h3{
    color:var(--gold-light);
    font-size:28px;
}

.badge{
    padding:7px 12px;
    border-radius:999px;
    font-size:12px;
    font-weight:bold;
    text-transform:uppercase;
    color:#fbbf24;
    background:rgba(245,158,11,.14);
    border:1px solid rgba(245,158,11,.4);
    white-space:nowrap;
}

.call-body{
    padding:24px;
}

.info{
    margin-bottom:14px;
    color:var(--cream2);
    line-height:1.5;
}

.info strong{
    color:var(--cream);
}

.resolve-btn{
    display:block;
    width:100%;
    margin-top:18px;
    padding:15px;
    border-radius:14px;
    background:linear-gradient(135deg,var(--gold),var(--gold-light));
    color:#140900;
    text-align:center;
    text-decoration:none;
    font-weight:bold;
    transition:.2s ease;
}

.resolve-btn:hover{
    transform:translateY(-2px);
    box-shadow:0 10px 28px rgba(201,168,76,.22);
}

.empty{
    max-width:520px;
    padding:28px;
    border-radius:24px;
    border:1px solid rgba(201,168,76,.25);
    background:rgba(13,6,0,.45);
    color:rgba(245,234,216,.65);
}

/* MOBILE */
@media(max-width:800px){
    .header{
        flex-direction:column;
        align-items:flex-start;
        gap:18px;
        padding:24px 18px;
    }

    .header-right{
        width:100%;
        flex-direction:column;
        align-items:stretch;
    }

    .user-box,
    .back-btn{
        width:100%;
        text-align:center;
    }

    .main{
        padding:28px 18px;
    }

    .title{
        font-size:38px;
    }

    .calls-grid{
        grid-template-columns:1fr;
    }
}

.admin-layout{display:block;margin:0;padding:0}
.content{flex:1;padding:42px;min-width:0;margin-left:0}
.page-topbar{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:32px;flex-wrap:wrap}
.page-subtitle{color:var(--gold-light);letter-spacing:8px;font-size:13px;margin-bottom:6px}
.page-title{font-size:46px;color:var(--cream)}
.user-box{padding:14px 18px;border-radius:999px;background:rgba(13,6,0,.65);border:1px solid rgba(201,168,76,.25);color:var(--cream2);font-size:14px;white-space:nowrap}
@media(max-width:900px){.admin-layout{display:block;margin:0;padding:0}.content{padding:24px 18px;margin-left:285px!important}.page-title{font-size:32px}}

</style>
<?php include_once __DIR__ . "/theme.php"; ?>
<style id="sidebar-fixed">
/* ── TOPBAR UNIFICADO ── */
.topbar,.page-topbar{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:32px;flex-wrap:wrap}
.topbar-left,.topbar-right{display:flex;align-items:center;gap:12px}
.page-subtitle,.subtitle{color:var(--gold-light,#e8c97a);letter-spacing:7px;font-size:12px;margin-bottom:6px;display:block}
.session-box,.session,.user-box{
  padding:11px 20px;
  border-radius:999px;
  background:rgba(13,6,0,.65);
  border:1px solid rgba(var(--gold-rgb,201,168,76),.25);
  color:var(--cream2,#ede0c4);
  font-size:14px;
  white-space:nowrap;
  font-family:var(--font,Georgia),serif;
}

/* ── SIDEBAR FIXA ── */
.admin-layout{display:block;margin:0;padding:0}
.sidebar{
  width:285px;min-width:285px;padding:26px 24px;
  background:var(--sidebar-gradient,linear-gradient(180deg,rgba(26,14,4,.98),rgba(13,6,0,.96)));
  border-right:1px solid rgba(var(--gold-rgb,201,168,76),.22);
  position:fixed!important;top:0;left:0;
  height:100vh;overflow-y:auto;overflow-x:hidden;
  z-index:100;display:flex;flex-direction:column;
}
.sidebar::-webkit-scrollbar{width:4px}
.sidebar::-webkit-scrollbar-thumb{background:rgba(201,168,76,.25);border-radius:2px}
.content{margin-left:285px!important;padding:34px 46px;overflow-x:auto;min-height:100vh}
.sidebar .sidebar-logo{display:flex!important;flex-direction:row!important;align-items:center!important;gap:14px!important;margin-bottom:42px!important;flex-shrink:0}
.sidebar .logo-box{width:56px!important;height:56px!important;border-radius:var(--radius,18px)!important;background:var(--grad-primary,linear-gradient(135deg,#c9a84c,#e8c97a))!important;color:#140900!important;display:flex!important;align-items:center!important;justify-content:center!important;font-size:28px!important;font-weight:bold!important;flex-shrink:0!important}
.sidebar .sidebar-logo h2{color:var(--gold-light,#e8c97a)!important;font-size:24px!important;line-height:1!important;margin:0!important}
.sidebar .sidebar-logo span{font-size:12px!important;color:rgba(245,234,216,.55)!important;letter-spacing:2px!important;display:block!important}
.menu-title{font-size:12px;color:rgba(245,234,216,.45);letter-spacing:3px;margin-bottom:16px;flex-shrink:0}
.side-menu{display:flex;flex-direction:column;gap:10px;flex:1}
.side-menu a{padding:14px 16px;border-radius:var(--radius,16px);color:var(--cream2,#ede0c4);text-decoration:none;background:rgba(var(--gold-rgb,201,168,76),.06);border:1px solid rgba(var(--gold-rgb,201,168,76),.12);transition:.22s ease;font-size:var(--fs-base,15px);display:block}
.side-menu a:hover,.side-menu a.active{background:var(--grad-primary,linear-gradient(135deg,#c9a84c,#e8c97a));color:#140900;font-weight:bold;transform:translateX(4px)}
.sidebar .logout{margin-top:18px;flex-shrink:0;display:block;padding:14px;border-radius:var(--radius,14px);text-align:center;color:#fca5a5;text-decoration:none;border:1px solid rgba(239,68,68,.35);background:rgba(239,68,68,.08);font-size:var(--fs-base,15px);font-weight:bold;transition:.2s}
.sidebar .logout:hover{background:rgba(239,68,68,.18)}
@media(max-width:900px){
  .admin-layout{display:block;margin:0;padding:0}
  .sidebar{position:relative!important;width:100%!important;min-width:100%!important;height:auto!important;overflow:visible!important}
  .content,main.content{margin-left:0!important;padding:24px 18px;overflow-x:auto;min-height:auto;width:100%!important}
  .side-menu a{padding:11px 14px}
  .side-menu a:hover,.side-menu a.active{transform:none}
}
</style>
<link rel="stylesheet" href="assets/responsive_global.css">
</head>

<body>
<div class="admin-layout">
<?php include "sidebar_admin.php"; ?>
<main class="content" style="display:block;min-height:100vh;box-sizing:border-box">

  <div class="page-topbar">
    <div>
      <p class="page-subtitle">RESTAURANT MANAGEMENT</p>
      <h1 class="page-title">📞 Chamadas do Gerente</h1>
    </div>
    <div class="session-box">Sessão iniciada como: <strong><?= htmlspecialchars($adminName) ?></strong></div>
  </div>

    <section id="live-content" class="calls-grid">

        <?php if ($calls && $calls->num_rows > 0): ?>

            <?php while($call = $calls->fetch_assoc()): ?>

                <article class="call-card">

                    <div class="call-header">
                        <h3>Chamada #<?= htmlspecialchars($call["id"]) ?></h3>

                        <span class="badge">
                            Pendente
                        </span>
                    </div>

                    <div class="call-body">

                        <div class="info">
                            <strong>Origem:</strong>
                            <?= !empty($call["table_number"])
                                ? "Mesa " . htmlspecialchars($call["table_number"])
                                : "Entrada" ?>
                        </div>

                        <div class="info">
                            <strong>Mensagem:</strong>
                            <?= htmlspecialchars($call["message"]) ?>
                        </div>

                        <div class="info">
                            <strong>Hora:</strong>
                            <?= date("H:i", strtotime($call["created_at"])) ?>
                        </div>

                        <a
                            href="gerente_dashboard.php?resolver=<?= htmlspecialchars($call["id"]) ?>"
                            class="resolve-btn"
                            onclick="return confirm('Marcar esta chamada como resolvida?')"
                        >
                            Marcar como resolvido
                        </a>

                    </div>

                </article>

            <?php endwhile; ?>

        <?php else: ?>

            <div class="empty">
                Ainda não existem chamadas pendentes do gerente.
            </div>

        <?php endif; ?>

    </section>

</main>

<script src="assets/auto_refresh.js"></script>

<script src="assets/keep_session.js"></script>
</main>
</div>
<script src="assets/notifications.js"></script>
</body>
</html>
<?php
require_once __DIR__ . "/session_config.php";
require_once __DIR__ . "/config/db.php";
require_once __DIR__ . "/session_handler.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function smarttable_column_exists($conn, $table, $column) {
    $table = $conn->real_escape_string($table);
    $column = $conn->real_escape_string($column);
    $res = $conn->query("SHOW COLUMNS FROM `$table` LIKE '$column'");
    return $res && $res->num_rows > 0;
}

if (!smarttable_column_exists($conn, "users", "remember_token")) {
    @$conn->query("ALTER TABLE users ADD remember_token VARCHAR(255) NULL");
}
if (!smarttable_column_exists($conn, "users", "remember_expires")) {
    @$conn->query("ALTER TABLE users ADD remember_expires DATETIME NULL");
}

function smarttable_set_remember_cookie($token) {
    setcookie("remember_token", $token, [
        "expires" => time() + (7 * 24 * 60 * 60),
        "path" => "/",
        "secure" => false,
        "httponly" => true,
        "samesite" => "Lax",
    ]);
}

/* Recuperar sessão por cookie persistente */
if (!isset($_SESSION["user_id"]) && !empty($_COOKIE["remember_token"])) {
    $token = trim($_COOKIE["remember_token"]);
    $activeCondition = smarttable_column_exists($conn, "users", "active") ? "AND active = 1" : "";

    $stmt = $conn->prepare("
        SELECT *
        FROM users
        WHERE remember_token = ?
        AND remember_expires > NOW()
        $activeCondition
        LIMIT 1
    ");

    if ($stmt) {
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();

        if ($user) {
            $_SESSION["user_id"] = $user["id"];
            $_SESSION["username"] = $user["username"] ?? "";
            $_SESSION["name"] = $user["name"] ?? ($user["username"] ?? "Utilizador");
            $_SESSION["role"] = $user["role"] ?? "";
            $_SESSION["last_restore"] = time();

            /* Não rotacionamos o token a cada restauro — isso causava uma
               condição de corrida com o auto-refresh AJAX (a cada 6s):
               dois pedidos quase simultâneos podiam invalidar o token um
               ao outro antes do browser atualizar o cookie, expulsando o
               utilizador para o login a meio do uso normal. Em vez disso,
               mantemos o mesmo token e só prolongamos a validade (sliding
               expiration), o que é igualmente seguro e elimina a corrida. */
            $uid = intval($user["id"]);
            $upd = $conn->prepare("
                UPDATE users
                SET remember_expires = DATE_ADD(NOW(), INTERVAL 7 DAY)
                WHERE id = ?
            ");
            if ($upd) {
                $upd->bind_param("i", $uid);
                $upd->execute();
            }
            /* Reenviar o cookie só para renovar o tempo de vida no browser,
               mantendo o mesmo valor de token. */
            smarttable_set_remember_cookie($token);
        }
    }
}
?>
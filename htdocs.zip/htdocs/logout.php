<?php
require_once "error_config.php";
require_once "session_config.php";
require_once "config/db.php";
require_once "session_handler.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION["user_id"])) {
    $uid = intval($_SESSION["user_id"]);
    $stmt = $conn->prepare("UPDATE users SET remember_token = NULL, remember_expires = NULL WHERE id = ?");
    if ($stmt) {
        $stmt->bind_param("i", $uid);
        $stmt->execute();
    }
}

$_SESSION = [];

if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $params["path"], $params["domain"] ?? '', false, true);
}

setcookie("remember_token", "", [
    "expires" => time() - 3600,
    "path" => "/",
    "secure" => false,
    "httponly" => true,
    "samesite" => "Lax",
]);

session_destroy();
header("Location: login.php");
exit;
?>

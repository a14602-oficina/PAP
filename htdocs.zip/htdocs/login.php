<?php
require_once "error_config.php";
require_once "session_config.php";
require_once "config/db.php";
require_once "session_handler.php";
session_start();


$erro = "";


function smarttable_column_exists($conn, $table, $column) {
    $table = $conn->real_escape_string($table);
    $column = $conn->real_escape_string($column);
    $res = $conn->query("SHOW COLUMNS FROM `$table` LIKE '$column'");
    return $res && $res->num_rows > 0;
}

function smarttable_ensure_remember_columns($conn) {
    if (!smarttable_column_exists($conn, "users", "remember_token")) {
        @$conn->query("ALTER TABLE users ADD remember_token VARCHAR(255) NULL");
    }
    if (!smarttable_column_exists($conn, "users", "remember_expires")) {
        @$conn->query("ALTER TABLE users ADD remember_expires DATETIME NULL");
    }
}

function smarttable_create_remember_login($conn, $userId) {
    smarttable_ensure_remember_columns($conn);

    $rememberToken = bin2hex(random_bytes(32));
    $userId = intval($userId);

    $stmtRemember = $conn->prepare("
        UPDATE users
        SET remember_token = ?,
            remember_expires = DATE_ADD(NOW(), INTERVAL 7 DAY)
        WHERE id = ?
    ");

    if ($stmtRemember) {
        $stmtRemember->bind_param("si", $rememberToken, $userId);
        $stmtRemember->execute();

        setcookie("remember_token", $rememberToken, [
            "expires" => time() + (7 * 24 * 60 * 60),
            "path" => "/",
            "secure" => false,
            "httponly" => true,
            "samesite" => "Lax",
        ]);
    }
}

smarttable_ensure_remember_columns($conn);


if ($_SERVER["REQUEST_METHOD"] === "POST") {

/* LOGIN RFID */
if (isset($_POST["rfid_code"])) {

    $rfid = trim($_POST["rfid_code"] ?? "");
    if ($rfid === "") {
        $erro = "Cartão RFID inválido.";
    } else {

        $stmt = $conn->prepare("
            SELECT *
            FROM users
            WHERE rfid_code = ?
            AND active = 1
            LIMIT 1
        ");

        $stmt->bind_param("s", $rfid);
        $stmt->execute();

        $user = $stmt->get_result()->fetch_assoc();

        if (!$user) {
            $erro = "Cartão RFID não autorizado.";
        } else {

            $_SESSION["user_id"] = $user["id"];
            $_SESSION["username"] = $user["username"];
            $_SESSION["name"] = $user["name"];
            $_SESSION["role"] = $user["role"];

            smarttable_create_remember_login($conn, $user["id"]);

            if ($user["role"] === "admin") {
                header("Location: admin_dashboard.php");
                exit;
            }

            if ($user["role"] === "empregado_mesa") {
                header("Location: empregado_mesa_dashboard.php");
                exit;
            }

            if ($user["role"] === "cozinha") {
                header("Location: cozinha_dashboard.php");
                exit;
            }

            if ($user["role"] === "bar") {
                header("Location: bar_dashboard.php");
                exit;
            }

            if ($user["role"] === "entrada") {
                header("Location: entrada_dashboard.php");
                exit;
            }

            if ($user["role"] === "mesa") {
                header("Location: mesa_dashboard.php");
                exit;
            }
            


            $erro = "Função inválida para este cartão.";
        }
    }
}

/* LOGIN NORMAL */
if (!isset($_POST["rfid_code"])) {

 $username = trim($_POST["username"] ?? "");
    $password = trim($_POST["password"] ?? "");
    $software = trim($_POST["software"] ?? "");

    if ($username === "" || $password === "") {//} || $software === "") {
        $erro = "Preenche todos os campos.";
    } else {

        $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? LIMIT 1");
        $stmt->bind_param("s", $username);
        $stmt->execute();

        $user = $stmt->get_result()->fetch_assoc();

        if (!$user) {
            $erro = "Utilizador não encontrado.";
        } elseif (isset($user["active"]) && intval($user["active"]) !== 1) {
            $erro = "Este utilizador está desativado. Contacte o administrador.";
        } elseif (!password_verify($password, $user["password"])) {
            $erro = "Palavra-passe incorreta.";
        /*} elseif ($software !== $user["role"]) {
            $erro = "Este utilizador não pertence a este software.";*/
        } else {

            $_SESSION["user_id"] = $user["id"];
            $_SESSION["username"] = $user["username"];
            $_SESSION["name"] = $user["name"];
            $_SESSION["role"] = $user["role"];

            smarttable_create_remember_login($conn, $user["id"]);

            switch ($user["role"]) {
                case "admin":
                    header("Location: admin_dashboard.php");
                    exit;

                case "entrada":
                    header("Location: entrada_dashboard.php");
                    exit;

                case "mesa":
                    header("Location: mesa_dashboard.php");
                    exit;

                case "empregado_mesa":
                    header("Location: empregado_mesa_dashboard.php");
                    exit;

                case "bar":
                    header("Location: bar_dashboard.php");
                    exit;
                case "cozinha":
                    header("Location: cozinha_dashboard.php");
                    exit;

                default:
                    $erro = "Função inválida.";
            }
        }
    }
}

}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>SmartTable - Login</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="favicon.ico" sizes="any">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="apple-touch-icon" href="assets/logo.png">
<link rel="manifest" href="site.webmanifest">
<meta name="theme-color" content="#0d0600">

<style>
:root{
  --gold:#c9a84c;
  --gold-light:#e8c97a;
  --dark:#0d0600;
  --cream:#f5ead8;
  --cream2:#ede0c4;
}

*{
  box-sizing:border-box;
  margin:0;
  padding:0;
}

body{
  min-height:100vh;
  font-family:Georgia,"Times New Roman",serif;
  background:
    linear-gradient(90deg,rgba(201,168,76,.04) 1px,transparent 1px),
    linear-gradient(rgba(201,168,76,.03) 1px,transparent 1px),
    radial-gradient(circle at top left,rgba(201,168,76,.18),transparent 35%),
    linear-gradient(135deg,var(--dark),#080300 70%);
  background-size:80px 80px,80px 80px,cover,cover;
  color:var(--cream);
  overflow-x:hidden;
}

.auth-page{
  min-height:100vh;
  width:100%;
  display:flex;
  flex-direction:column;
  align-items:center;
  justify-content:center;
  padding:36px 18px;
}

.brand{
  display:flex;
  align-items:center;
  justify-content:center;
  gap:18px;
  margin-bottom:26px;
}

.logo-box{
  width:74px;
  height:74px;
  border-radius:20px;
  background:linear-gradient(135deg,var(--gold),var(--gold-light));
  color:#140900;
  display:flex;
  align-items:center;
  justify-content:center;
  font-size:36px;
  font-weight:bold;
  flex-shrink:0;
}

.subtitle{
  color:var(--gold-light);
  letter-spacing:7px;
  font-size:12px;
  margin-bottom:5px;
}

.brand h1{
  font-size:56px;
  line-height:1;
}

.description{
  margin-top:8px;
  font-size:17px;
  color:var(--cream2);
  text-align:center;
}

.auth-card{
  width:100%;
  max-width:580px;
  border:1px solid rgba(201,168,76,.28);
  border-radius:26px;
  background:linear-gradient(145deg,rgba(38,21,8,.82),rgba(13,6,0,.96));
  box-shadow:0 18px 55px rgba(0,0,0,.35);
  padding:24px 30px;
}

.auth-card h2{
  font-size:32px;
  margin-bottom:6px;
  text-align:center;
  color:var(--gold-light);
}

.card-text{
  color:var(--cream2);
  font-size:14px;
  margin-bottom:14px;
  text-align:center;
}

form{
  display:flex;
  flex-direction:column;
  gap:10px;
}

label{
    display:block;
    margin-bottom:5px;
    font-size:13px;
    color:rgba(245,234,216,.75);
    font-weight:500;
    letter-spacing:.3px;
}

input,
select{
    width:100%;
    padding:10px 14px;
    margin-bottom:6px;
    border-radius:14px;
    border:1px solid rgba(201,168,76,.22);

    background:rgba(13,6,0,.75);

    color:#fff;

    font-size:17px;

    outline:none;

    transition:.3s;
}

button{
  width:100%;
  margin-top:10px;
  padding:15px;
  border:none;
  border-radius:14px;
  background:linear-gradient(135deg,var(--gold),var(--gold-light));
  color:#140900;
  font-weight:bold;
  font-size:16px;
  cursor:pointer;
  font-family:Georgia,"Times New Roman",serif;
}

.switch-link{
  margin-top:18px;
  text-align:center;
  color:var(--cream2);
  font-size:15px;
}

.switch-link a{
  color:var(--gold-light);
  text-decoration:none;
  font-weight:bold;
}

@media(max-width:600px){
  .auth-page{
    padding:28px 18px;
  }

  .brand{
    gap:14px;
    margin-bottom:24px;
  }

  .logo-box{
    width:62px;
    height:62px;
    border-radius:18px;
    font-size:31px;
    padding:48px 40px;
  }

  .subtitle{
    font-size:10px;
    letter-spacing:4px;
  }

  .brand h1{
    font-size:42px;
  }

  .description{
    font-size:16px;
  }

  .auth-card{
    max-width:100%;
    padding:28px 22px;
  }

  .auth-card h2{
    font-size:38px;
  }
}
    
    .rfid-area{
    margin-top:16px;
}

.rfid-btn{
    width:100%;
    padding:14px;
    border:none;
    border-radius:16px;
    background:transparent;
    border:1px solid rgba(201,168,76,.35);
    color:#e8c97a;
    font-weight:bold;
    cursor:pointer;
    transition:.3s;
}

.rfid-btn:hover{
    background:rgba(201,168,76,.12);
}

.rfid-modal{
    position:fixed;
    inset:0;
    background:rgba(0,0,0,.78);
    display:none;
    align-items:center;
    justify-content:center;
    z-index:9999;
}

.rfid-modal.active{
    display:flex;
}

.rfid-box{
    width:420px;
    max-width:92%;
    padding:40px;
    border-radius:28px;
    text-align:center;

    background:
    linear-gradient(145deg,
    rgba(38,21,8,.96),
    rgba(13,6,0,.98));

    border:1px solid rgba(201,168,76,.24);

    box-shadow:
    0 30px 80px rgba(0,0,0,.45);
}

.rfid-icon{
    font-size:60px;
    margin-bottom:18px;
}

.rfid-box h2{
    font-size:36px;
    color:#f5ead8;
    margin-bottom:12px;
}

.rfid-box p{
    color:rgba(245,234,216,.72);
    margin-bottom:24px;
    line-height:1.5;
}

#rfidInput{
    opacity:0;
    position:absolute;
    pointer-events:none;
}

.cancel-rfid{
    width:100%;
    margin-top:14px;
    padding:14px;
    border:none;
    border-radius:16px;

    background:rgba(239,68,68,.12);

    border:1px solid rgba(239,68,68,.35);

    color:#fca5a5;
    font-weight:bold;
    cursor:pointer;
}
    
</style>
<?php include_once __DIR__ . "/theme.php"; ?>
<link rel="stylesheet" href="assets/responsive_global.css">
</head>

<body>

<main class="auth-page">

  <section class="brand">
    <img src="assets/logo.png" alt="SmartTable" style="height:140px;width:auto;object-fit:contain">

    <div>
      <p class="subtitle">RESTAURANT MANAGEMENT</p>
      <h1>SmartTable</h1>
      <p class="description">Acesso ao sistema</p>
    </div>
  </section>

  <section class="auth-card">

    <h2>Login</h2>
    <p class="card-text">Introduz os teus dados</p>

    <?php if ($erro !== ""): ?>
      <div class="msg" style="padding:12px 16px;border-radius:12px;background:rgba(239,68,68,.12);border:1px solid rgba(239,68,68,.35);color:#fca5a5;margin-bottom:16px;font-size:14px">
        <?= htmlspecialchars($erro) ?>
      </div>
    <?php endif; ?>

    <form method="POST" action="login.php">

      <label>Utilizador</label>
      <input
        type="text"
        name="username"
        placeholder="Introduz o utilizador"
        required
        autocomplete="username"
      >

      <label>Palavra-passe</label>
      <input
        type="password"
        name="password"
        placeholder="Introduz a palavra-passe"
        required
        autocomplete="current-password"
      >

      <button type="submit">
        Entrar
      </button>

      <div class="rfid-area">
        <button type="button" class="rfid-btn" onclick="openRFIDModal()">
          Entrar com Cartão RFID
        </button>
      </div>

    </form>

  </section>

</main>
<div id="rfidModal" class="rfid-modal">

    <div class="rfid-box">

        <div class="rfid-icon">
            <img src="assets/rfid_icon.svg" alt="RFID" style="width:80px;height:80px">
        </div>

        <h2>Aproxime o cartão</h2>

        <p>
            Passe o cartão RFID no leitor para iniciar sessão.
        </p>

        <form method="POST" id="rfidForm">

            <input
                type="text"
                name="rfid_code"
                id="rfidInput"
                autocomplete="off"
            >

        </form>

        <button
            class="cancel-rfid"
            onclick="closeRFIDModal()"
            type="button"
        >
            Cancelar
        </button>

    </div>

</div>
    
    <script>

function openRFIDModal(){

    const modal = document.getElementById("rfidModal");

    modal.classList.add("active");

    const input = document.getElementById("rfidInput");

    input.value = "";

    setTimeout(() => {
        input.focus();
    }, 100);
}

function closeRFIDModal(){

    document
    .getElementById("rfidModal")
    .classList
    .remove("active");
}

setInterval(() => {

    const modal = document.getElementById("rfidModal");

    if(modal.classList.contains("active")){

        document
        .getElementById("rfidInput")
        .focus();
    }

}, 500);

document
.getElementById("rfidInput")
.addEventListener("input", function(){

    if(this.value.length >= 6){

        document
        .getElementById("rfidForm")
        .submit();
    }
});

</script>
<script src="assets/keep_session.js"></script>
</body>
</html>
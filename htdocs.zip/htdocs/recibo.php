<?php
require_once "session_config.php";
require_once "config/db.php";
require_once "session_handler.php";
if (session_status() === PHP_SESSION_NONE) session_start();
require_once "error_config.php";

require_once "config/db.php";

/* Apenas admin ou empregado de mesa podem consultar recibos */
if (!isset($_SESSION["user_id"]) || !in_array($_SESSION["role"] ?? "", ["admin", "empregado_mesa"])) {
    header("Location: login.php");
    exit;
}

$orderId = intval($_GET["order_id"] ?? 0);
$tableNumber = intval($_GET["table_number"] ?? 0);

if ($orderId <= 0 && $tableNumber <= 0) {
    die("Recibo inválido.");
}

if ($tableNumber > 0) {
    /* Combinar todos os pedidos em pagamento/pagos desta mesa numa única conta */
    $stmt = $conn->prepare("
        SELECT *
        FROM orders
        WHERE table_number = ? AND status IN ('pagamento','pago')
        ORDER BY created_at ASC
    ");
    $stmt->bind_param("i", $tableNumber);
    $stmt->execute();
    $ordersResult = $stmt->get_result();

    $orders = [];
    $total = 0;
    $firstOrder = null;
    while ($o = $ordersResult->fetch_assoc()) {
        $orders[] = $o;
        $total += (float)$o["total"];
        if ($firstOrder === null) $firstOrder = $o;
    }

    if (empty($orders)) {
        die("Conta não encontrada.");
    }

    $order = [
        "id" => implode(", #", array_column($orders, "id")),
        "table_number" => $tableNumber,
        "created_at" => $firstOrder["created_at"],
        "total" => $total,
    ];
    $order["id"] = "#" . $order["id"];

    $orderIds = array_column($orders, "id");
} else {
    $stmt = $conn->prepare("
        SELECT *
        FROM orders
        WHERE id = ?
    ");
    $stmt->bind_param("i", $orderId);
    $stmt->execute();
    $order = $stmt->get_result()->fetch_assoc();

    if (!$order) {
        die("Pedido não encontrado.");
    }

    $order["id"] = "#" . $order["id"];
    $orderIds = [$orderId];
}

$items = [];
foreach ($orderIds as $oid) {
    $itemsStmt = $conn->prepare("
        SELECT *
        FROM order_items
        WHERE order_id = ?
    ");
    $itemsStmt->bind_param("i", $oid);
    $itemsStmt->execute();
    $r = $itemsStmt->get_result();
    while ($row = $r->fetch_assoc()) {
        $items[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<link rel="icon" href="favicon.ico" sizes="any">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="apple-touch-icon" href="assets/logo.png">
<link rel="manifest" href="site.webmanifest">
<meta name="theme-color" content="#0d0600">
<meta charset="UTF-8">
<title>Recibo Pedido <?= htmlspecialchars($order["id"]) ?></title>
<link rel="stylesheet" href="assets/responsive.css">
<style>
body{
  font-family:Arial, sans-serif;
  background:#f4f4f4;
  padding:30px;
}

.receipt{
  width:360px;
  margin:auto;
  background:white;
  padding:22px;
  border-radius:10px;
  color:#111;
}

h1{
  text-align:center;
  font-size:24px;
  margin-bottom:4px;
}

.subtitle{
  text-align:center;
  font-size:12px;
  color:#555;
  margin-bottom:20px;
}

.line{
  border-top:1px dashed #999;
  margin:14px 0;
}

.row{
  display:flex;
  justify-content:space-between;
  gap:12px;
  font-size:14px;
  margin:8px 0;
}

.total{
  font-size:20px;
  font-weight:bold;
}

.print{
  margin:20px auto;
  display:block;
  padding:12px 18px;
  border:none;
  border-radius:8px;
  background:#111;
  color:white;
  cursor:pointer;
}

@media print{
  body{
    background:white;
    padding:0;
  }

  .print{
    display:none;
  }

  .receipt{
    box-shadow:none;
    width:100%;
  }
}
</style>
</head>

<body>

<div class="receipt">

  <h1>SmartTable</h1>
  <div class="subtitle">Talão / Recibo</div>

  <div class="line"></div>

  <div class="row">
    <span>Pedido</span>
    <strong><?= htmlspecialchars($order["id"]) ?></strong>
  </div>

  <div class="row">
    <span>Mesa</span>
    <strong><?= htmlspecialchars($order["table_number"]) ?></strong>
  </div>

  <div class="row">
    <span>Data</span>
    <strong><?= htmlspecialchars($order["created_at"]) ?></strong>
  </div>

  <div class="line"></div>

  <?php foreach ($items as $item): ?>
    <div class="row">
      <span>
        <?= htmlspecialchars($item["quantity"]) ?>x
        <?= htmlspecialchars($item["name"]) ?>
      </span>

      <strong>
        <?= number_format((float)$item["subtotal"], 2, ",", ".") ?> €
      </strong>
    </div>
  <?php endforeach; ?>

  <div class="line"></div>

  <div class="row total">
    <span>Total</span>
    <span><?= number_format((float)$order["total"], 2, ",", ".") ?> €</span>
  </div>

  <div class="line"></div>

  <p style="text-align:center;font-size:12px;color:#555;">
    Obrigado pela preferência.
  </p>

</div>

<button class="print" onclick="window.print()">Imprimir Recibo</button>

</body>
</html>
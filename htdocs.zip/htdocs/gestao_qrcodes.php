<?php
require_once "session_config.php";
require_once "config/db.php";
require_once "session_handler.php";
session_start();
require_once "auth_check.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "admin") {
    header("Location: login.php"); exit;
}

$adminName = $_SESSION["name"] ?? "Administrador";

// Detectar URL base actual do servidor
$protocol   = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https" : "http";
$currentBase = $protocol . "://" . $_SERVER['HTTP_HOST'] . "/mesa_dashboard.php";

// Regenerar QR codes: actualiza qr_data.php com novo URL
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["regenerar_qr"])) {
    $urlBase = rtrim(trim($_POST["url_base"] ?? $currentBase), "/");
    header("Location: gestao_qrcodes.php?newbase=" . urlencode($urlBase));
    exit;
}

// Carregar QR codes pré-gerados
require_once __DIR__ . "/qr_data.php";

// Buscar mesas da BD
$mesas = [];
$res = $conn->query("SELECT number, status, occupied_seats FROM `tables` ORDER BY number ASC");
if ($res) while ($r = $res->fetch_assoc()) $mesas[] = $r;
if (empty($mesas)) {
    for ($i = 1; $i <= 25; $i++) $mesas[] = ["number" => $i, "status" => "livre", "occupied_seats" => 0];
}

// URL base do sistema
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https" : "http";
$baseUrl = $protocol . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
$baseUrl = rtrim($baseUrl, '/');
$menuUrl = $baseUrl . "/mesa_dashboard.php";
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>SmartTable — QR Codes</title>
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<link rel="icon" type="image/png" href="assets/favicon.png">
<link rel="icon" type="image/x-icon" href="assets/favicon.ico">
<?php include_once __DIR__ . "/theme.php"; ?>
<script src="https://cdn.jsdelivr.net/npm/qrcode-generator@1.4.4/qrcode.min.js"></script>
<link rel="stylesheet" href="assets/sidebar_admin.css">
<!-- QR via Google Charts API -->
<style>
body{margin:0;font-family:var(--font,Georgia),serif;color:var(--cream)}
.topbar{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:32px;flex-wrap:wrap}
.subtitle{color:var(--gold-light);letter-spacing:7px;font-size:12px;margin-bottom:6px}
.topbar h1{font-size:44px;line-height:1;color:var(--cream);margin:0}
.session-box{padding:11px 20px;border-radius:999px;background:rgba(13,6,0,.65);border:1px solid rgba(var(--gold-rgb,201,168,76),.25);color:var(--cream2);font-size:14px;white-space:nowrap}
.btn-back{padding:11px 18px;border-radius:var(--radius,14px);border:1px solid rgba(var(--gold-rgb,201,168,76),.25);background:rgba(13,6,0,.65);color:var(--gold-light);text-decoration:none;font-weight:bold;font-size:14px}
.btn-back:hover{background:var(--grad-primary,linear-gradient(135deg,#c9a84c,#e8c97a));color:#140900}

/* URL bar */
.url-bar{background:rgba(13,6,0,.55);border:1px solid rgba(var(--gold-rgb,201,168,76),.2);border-radius:var(--radius,14px);padding:16px 22px;margin-bottom:28px;display:flex;align-items:center;gap:14px;flex-wrap:wrap}
.url-bar label{font-size:12px;letter-spacing:2px;color:var(--gold-light);white-space:nowrap}
.url-bar code{font-size:13px;color:var(--cream2);word-break:break-all;flex:1}
.url-bar .btn-edit{padding:8px 14px;border-radius:999px;border:1px solid rgba(var(--gold-rgb,201,168,76),.3);background:transparent;color:var(--gold-light);cursor:pointer;font-size:12px;white-space:nowrap}

/* Controls */
.controls{display:flex;gap:12px;margin-bottom:24px;flex-wrap:wrap;align-items:center}
.btn-dl-all{padding:12px 24px;border-radius:var(--radius,14px);border:none;background:var(--grad-primary,linear-gradient(135deg,#c9a84c,#e8c97a));color:#140900;font-weight:bold;cursor:pointer;font-size:14px;font-family:var(--font,Georgia),serif}
.btn-dl-all:hover{opacity:.88}
.filter-label{font-size:13px;color:var(--cream2);margin-left:auto}
select.filter-sel{padding:9px 14px;border-radius:var(--radius,12px);border:1px solid rgba(var(--gold-rgb,201,168,76),.2);background:rgba(13,6,0,.6);color:var(--cream);font-family:var(--font,Georgia),serif;font-size:13px}

/* Grid */
.qr-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:20px}

/* Card */
.qr-card{border:1px solid rgba(var(--gold-rgb,201,168,76),.2);border-radius:var(--radius-lg,20px);background:linear-gradient(145deg,rgba(30,16,4,.9),rgba(13,6,0,.97));overflow:hidden;display:flex;flex-direction:column;align-items:center;padding:0 0 18px;transition:border-color .2s}
.qr-card:hover{border-color:rgba(var(--gold-rgb,201,168,76),.45)}
.qr-card.ocupada{border-color:rgba(239,68,68,.3)}
.qr-card.livre{border-color:rgba(34,197,94,.25)}

.card-header{width:100%;padding:10px 14px 8px;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid rgba(var(--gold-rgb,201,168,76),.1)}
.card-header .mesa-num{font-size:20px;font-weight:bold;color:var(--gold-light)}
.status-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0}
.status-dot.livre{background:#22c55e;box-shadow:0 0 6px rgba(34,197,94,.5)}
.status-dot.ocupada{background:#ef4444;box-shadow:0 0 6px rgba(239,68,68,.5)}
.status-dot.reservada{background:#f59e0b}
.status-dot.manutencao{background:#64748b}

/* QR container — fundo branco com moldura dourada */
.qr-wrapper{
  margin:14px auto 10px;
  padding:8px;
  background:#fff;
  border-radius:10px;
  border:2px solid #c9a84c;
  width:fit-content;
  line-height:0;
}
.qr-wrapper img{ display:block !important; width:160px !important; height:160px !important; }
.qr-wrapper svg{ display:block; width:160px !important; height:160px !important; }

.mesa-label{font-size:13px;color:var(--cream2);margin-bottom:4px}
.mesa-url{font-size:10px;color:rgba(245,234,216,.35);margin-bottom:12px;word-break:break-all;padding:0 12px;text-align:center}

/* Download btn per card */
.btn-dl{padding:8px 16px;border-radius:999px;border:1px solid rgba(var(--gold-rgb,201,168,76),.3);background:rgba(var(--gold-rgb,201,168,76),.08);color:var(--gold-light);cursor:pointer;font-size:12px;font-family:var(--font,Georgia),serif;transition:.15s}
.btn-dl:hover{background:rgba(var(--gold-rgb,201,168,76),.18)}

/* Print styles */
@media print{
  *{ -webkit-print-color-adjust:exact; print-color-adjust:exact; }
  .sidebar,.topbar,.controls,.url-bar,.btn-dl,.card-header .status-dot,
  .mesa-url,.session-box,.btn-back{ display:none!important; }
  body{ background:#fff!important; color:#000!important; }
  .admin-layout{display:block;margin:0;padding:0}
  .content{ margin-left:0; padding:38px 42px; }
  .qr-grid{
    display:grid!important;
    grid-template-columns:repeat(4,1fr)!important;
    gap:16px!important;
  }
  .qr-card{
    border:1px solid #c9a84c!important;
    border-radius:12px!important;
    background:#fff!important;
    padding:12px 8px 10px!important;
    page-break-inside:avoid!important;
    break-inside:avoid!important;
    display:flex!important;
    flex-direction:column!important;
    align-items:center!important;
    text-align:center!important;
  }
  .card-header{
    width:100%!important;
    border-bottom:1px solid #c9a84c!important;
    padding:4px 8px 6px!important;
    margin-bottom:8px!important;
  }
  .card-header .mesa-num{ color:#1a0e04!important; font-size:14px!important; }
  .qr-wrapper{
    border:1.5px solid #c9a84c!important;
    padding:6px!important;
    background:#fff!important;
    margin:0 auto 6px!important;
  }
  .qr-wrapper img{
    width:120px!important;
    height:120px!important;
  }
  .mesa-label{ font-size:11px!important; color:#1a0e04!important; }
}

@media(max-width:900px){
  .admin-layout{display:block;margin:0;padding:0}
  .sidebar{position:relative!important;width:100%!important;height:auto!important}
  .content,main.content{margin-left:0!important;padding:24px 18px;overflow-x:auto;min-height:auto;width:100%!important}
  .topbar h1{font-size:32px}
  .qr-grid{grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:14px}
}
</style>
</head>
<body>
<div class="admin-layout">
  <?php include "sidebar_admin.php"; ?>

  <main class="content" style="display:block;min-height:100vh;box-sizing:border-box">
    <div class="topbar">
      <div>
        <p class="subtitle">ADMIN — QRCODES</p>
        <h1>📲 Gerador de QR Codes</h1>
      </div>
      <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
        <div class="session-box">Sessão iniciada como: <strong><?= htmlspecialchars($adminName) ?></strong></div>
      </div>
    </div>

    <!-- URL base -->
    <div class="url-bar">
      <label>URL BASE</label>
      <code id="baseUrlDisplay"><?= htmlspecialchars($menuUrl) ?></code>
      <button class="btn-edit" onclick="editBaseUrl()">✏️ Editar URL</button>
    </div>

    <!-- Controlos -->
    <?php if (isset($_GET["regenerado"])): ?>
      <div style="padding:13px 18px;border-radius:12px;background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.3);color:#86efac;margin-bottom:16px;font-weight:bold">
        ✓ QR codes regenerados com sucesso para o domínio actual.
      </div>
    <?php endif; ?>

    <div class="controls">
      <button class="btn-dl-all" onclick="downloadAll()">⬇ Descarregar todos</button>
      <button class="btn-dl-all" style="background:rgba(13,6,0,.65);border:1px solid rgba(201,168,76,.3);color:var(--gold-light)" onclick="window.print()">🖨 Imprimir todos</button>
      <button class="btn-dl-all" style="background:rgba(59,130,246,.15);border:1px solid rgba(59,130,246,.3);color:#93c5fd" onclick="abrirModalRegerar()">
        🔄 Regenerar todos os QR Codes
      </button>
      <label class="filter-label">Filtrar:
        <select class="filter-sel" onchange="filterMesas(this.value)">
          <option value="all">Todas as mesas</option>
          <option value="livre">Livres</option>
          <option value="ocupada">Ocupadas</option>
        </select>
      </label>
    </div>

    <!-- Grid de QR Codes -->
    <div class="qr-grid" id="qrGrid">
      <?php foreach ($mesas as $mesa): ?>
        <?php
          $num    = intval($mesa["number"]);
          $status = htmlspecialchars($mesa["status"] ?? "livre");
          $url    = $menuUrl . "?mesa=" . $num;
        ?>
        <div class="qr-card <?= $status ?>" data-status="<?= $status ?>" data-mesa="<?= $num ?>">
          <div class="card-header">
            <span class="mesa-num">Mesa <?= $num ?></span>
            <span class="status-dot <?= $status ?>" title="<?= ucfirst($status) ?>"></span>
          </div>
          <div class="qr-wrapper">
            <?php if (isset($qrCodes[$num])): ?>
              <img
                src="<?= $qrCodes[$num] ?>"
                alt="QR Mesa <?= $num ?>"
                style="display:block;width:160px;height:160px"
              >
            <?php endif; ?>
          </div>
          <div class="mesa-label">Mesa <?= $num ?></div>
          <div class="mesa-url"><?= htmlspecialchars($url) ?></div>
          <div style="display:flex;gap:6px;flex-wrap:wrap;justify-content:center">
            <button class="btn-dl" onclick="downloadQR(<?= $num ?>)">⬇ PNG</button>
            <form method="POST" style="display:inline">
              <input type="hidden" name="regenerar_qr" value="1">
              <input type="hidden" name="mesa_num" value="<?= $num ?>">
              <input type="hidden" name="url_base" value="<?= htmlspecialchars($currentBase) ?>">
              <button type="submit" class="btn-dl" style="color:#93c5fd;border-color:rgba(59,130,246,.3)"
                onclick="return confirm('Regenerar QR da Mesa <?= $num ?> para o domínio actual?')">
                🔄 Regenerar
              </button>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </main>
</div>


<!-- Modal regenerar todos -->
<div id="regenerarModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.75);z-index:9999;align-items:center;justify-content:center;padding:20px">
  <div style="background:linear-gradient(145deg,rgba(30,16,4,.98),rgba(13,6,0,.99));border:1px solid rgba(201,168,76,.3);border-radius:20px;padding:28px;max-width:480px;width:100%">
    <h3 style="color:var(--gold-light);font-size:22px;margin-bottom:8px">🔄 Regenerar todos os QR Codes</h3>
    <p style="color:rgba(245,234,216,.6);font-size:14px;margin-bottom:20px;line-height:1.6">
      Usa o URL base abaixo para gerar os QR codes. Já está preenchido com o domínio actual — confirma que está correcto.
    </p>
    <form onsubmit="regenerarTodos(this.url_base.value);document.getElementById('regenerarModal').style.display='none';return false">
      <div style="margin-bottom:16px">
        <label style="font-size:12px;letter-spacing:2px;color:var(--gold-light);display:block;margin-bottom:6px">URL BASE DO MENU</label>
        <input type="text" name="url_base"
          value="<?= htmlspecialchars($currentBase) ?>"
          style="width:100%;padding:12px 14px;border-radius:10px;border:1px solid rgba(201,168,76,.25);background:rgba(13,6,0,.7);color:var(--cream);font-size:13px">
      </div>
      <div style="display:flex;gap:10px">
        <button type="submit" style="flex:1;padding:13px;border:none;border-radius:12px;background:linear-gradient(135deg,var(--gold,#c9a84c),var(--gold-light,#e8c97a));color:#140900;font-weight:bold;cursor:pointer;font-size:14px;font-family:var(--font,Georgia),serif">
          ✓ Regenerar agora
        </button>
        <button type="button" onclick="document.getElementById('regenerarModal').style.display='none'"
          style="padding:13px 20px;border-radius:12px;border:1px solid rgba(239,68,68,.3);background:rgba(239,68,68,.08);color:#fca5a5;cursor:pointer;font-size:14px;font-family:var(--font,Georgia),serif">
          Cancelar
        </button>
      </div>
    </form>
  </div>
</div>

</body>
</html>

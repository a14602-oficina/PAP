<?php
require_once "error_config.php";
require_once "auth_check.php";

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

if (isset($_SESSION['user_id']) || isset($_SESSION['mesa_numero'])) {
    $_SESSION['last_ping'] = time();
    echo json_encode(['ok' => true]);
    exit;
}

/* Só força redirect se não há cookie de recuperação */
$hasRecoveryCookie = !empty($_COOKIE['remember_token']);
echo json_encode([
    'ok'       => false,
    'redirect' => !$hasRecoveryCookie,
    'reason'   => 'no_session'
]);
exit;

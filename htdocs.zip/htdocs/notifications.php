<?php
/**
 * notifications.php — Endpoint AJAX de contagens para badges e notificações
 * Devolve JSON com contagens de itens pendentes por área.
 */
require_once "error_config.php";
require_once "session_config.php";
require_once "config/db.php";
require_once "session_handler.php";
session_start();
require_once "config/db.php";
header('Content-Type: application/json');
header('Cache-Control: no-store');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['ok' => false]);
    exit;
}

$role = $_SESSION['role'] ?? '';

$data = [
    'ok'             => true,
    'pagamentos'     => 0,  // orders com status='pagamento'
    'gerente'        => 0,  // manager_calls pendentes
    'cozinha'        => 0,  // orders enviados/processando
    'pronto'         => 0,  // orders prontos para entregar (empregado de mesa)
    'mesas_ocupadas' => 0,  // mesas ocupadas
    'total'          => 0,
];

// Pagamentos pendentes
$r = $conn->query("SELECT COUNT(*) AS n FROM orders WHERE status='pagamento'");
if ($r) $data['pagamentos'] = intval($r->fetch_assoc()['n']);

// Chamadas ao gerente
$r = $conn->query("SELECT COUNT(*) AS n FROM manager_calls WHERE status='pendente'");
if ($r) $data['gerente'] = intval($r->fetch_assoc()['n']);

// Pedidos na cozinha (enviados + a processar), excluindo pedidos só de bebidas
$r = $conn->query("
    SELECT COUNT(DISTINCT o.id) AS n
    FROM orders o
    INNER JOIN order_items oi ON oi.order_id = o.id
    WHERE o.status IN ('enviado','processando')
    AND LOWER(COALESCE(oi.category, '')) NOT LIKE '%bebida%'
");
if ($r) $data['cozinha'] = intval($r->fetch_assoc()['n']);

// Pedidos prontos (para o empregado de mesa entregar)
$r = $conn->query("SELECT COUNT(*) AS n FROM orders WHERE status='pronto'");
if ($r) $data['pronto'] = intval($r->fetch_assoc()['n']);

// Mesas ocupadas
$r = $conn->query("SELECT COUNT(*) AS n FROM `tables` WHERE status='ocupada'");
if ($r) $data['mesas_ocupadas'] = intval($r->fetch_assoc()['n']);

$data['total'] = $data['pagamentos'] + $data['gerente'] + $data['cozinha'] + $data['pronto'];

echo json_encode($data);
<?php
/**
 * SmartTable — Session Handler em Base de Dados
 * Guarda sessões na BD em vez de ficheiros do servidor.
 * O InfinityFree não permite alterar gc_maxlifetime via ini_set,
 * por isso usamos a BD onde controlamos a expiração nós próprios.
 *
 * Incluir ANTES de session_start() em todos os ficheiros que usam sessão.
 * auth_check.php já faz include deste ficheiro.
 */

if (!isset($conn)) {
    require_once __DIR__ . "/config/db.php";
}

/* Criar tabela se não existir */
$conn->query("
    CREATE TABLE IF NOT EXISTS `php_sessions` (
        `id`         VARCHAR(128) NOT NULL PRIMARY KEY,
        `data`       MEDIUMTEXT NOT NULL,
        `updated_at` INT UNSIGNED NOT NULL,
        INDEX `idx_updated` (`updated_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");

$LIFETIME = 7 * 24 * 60 * 60; /* 7 dias */

class DBSessionHandler implements SessionHandlerInterface {
    private $conn;
    private $lifetime;

    public function __construct($conn, $lifetime) {
        $this->conn     = $conn;
        $this->lifetime = $lifetime;
    }

    public function open($path, $name): bool { return true; }
    public function close(): bool            { return true; }

    public function read($id): string {
        $stmt = $this->conn->prepare(
            "SELECT data FROM php_sessions WHERE id=? AND updated_at > ?"
        );
        $expiry = time() - $this->lifetime;
        $stmt->bind_param("si", $id, $expiry);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();
        return $res ? $res['data'] : '';
    }

    public function write($id, $data): bool {
        $now  = time();
        $stmt = $this->conn->prepare(
            "INSERT INTO php_sessions (id, data, updated_at) VALUES (?,?,?)
             ON DUPLICATE KEY UPDATE data=VALUES(data), updated_at=VALUES(updated_at)"
        );
        $stmt->bind_param("ssi", $id, $data, $now);
        return $stmt->execute();
    }

    public function destroy($id): bool {
        $stmt = $this->conn->prepare("DELETE FROM php_sessions WHERE id=?");
        $stmt->bind_param("s", $id);
        return $stmt->execute();
    }

    public function gc($max_lifetime): int|false {
        $expiry = time() - $this->lifetime;
        $res = $this->conn->query(
            "DELETE FROM php_sessions WHERE updated_at < $expiry"
        );
        return $res ? $this->conn->affected_rows : false;
    }
}

$handler = new DBSessionHandler($conn, $LIFETIME);
session_set_save_handler($handler, true);

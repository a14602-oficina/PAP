<?php
require_once "error_config.php";

require_once "auth_check.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "bar") {
    header("Location: login.php");
    exit;
}

$barName = $_SESSION["name"] ?? $_SESSION["username"] ?? "Bar";
$msg = "";

/* Garantir tabela bar_orders */
$conn->query("CREATE TABLE IF NOT EXISTS bar_orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    table_number VARCHAR(20) NOT NULL,
    item_name VARCHAR(255) NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    customization TEXT DEFAULT NULL,
    status ENUM('pendente','preparando','pronto') NOT NULL DEFAULT 'pendente',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_order_id (order_id)
)");

/* Garantir colunas em order_items */
$cols = $conn->query("SHOW COLUMNS FROM order_items")->fetch_all(MYSQLI_ASSOC);
$colNames = array_column($cols, 'Field');
if (!in_array('customization', $colNames))
    $conn->query("ALTER TABLE order_items ADD COLUMN customization TEXT DEFAULT NULL");
if (!in_array('category', $colNames))
    $conn->query("ALTER TABLE order_items ADD COLUMN category VARCHAR(50) DEFAULT 'outro'");

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["preparar"])) {
    $orderId = intval($_POST["order_id"] ?? 0);
    if ($orderId > 0) {
        $stmt = $conn->prepare("UPDATE bar_orders SET status='preparando' WHERE id=?");
        $stmt->bind_param("i", $orderId);
        if ($stmt->execute()) $msg = "Bebida marcada como a ser preparada.";
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["pronto"])) {
    $orderId = intval($_POST["order_id"] ?? 0);
    if ($orderId > 0) {
        $stmt = $conn->prepare("UPDATE bar_orders SET status='pronto' WHERE id=?");
        $stmt->bind_param("i", $orderId);
        if ($stmt->execute()) $msg = "Bebida marcada como pronta!";
    }
}

$orders = $conn->query("
    SELECT * FROM bar_orders
    WHERE status IN ('pendente','preparando')
    ORDER BY created_at ASC
");
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>SmartTable - Bar</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="favicon.ico" sizes="any">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="apple-touch-icon" href="assets/logo.png">
<link rel="manifest" href="site.webmanifest">
<meta name="theme-color" content="#0d0600">
<script src="assets/auto_refresh.js"></script>
<link rel="stylesheet" href="assets/responsive.css">
<link rel="stylesheet" href="assets/style.css">
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{min-height:100vh;font-family:Georgia,"Times New Roman",serif;background:linear-gradient(90deg,rgba(201,168,76,.04) 1px,transparent 1px),linear-gradient(rgba(201,168,76,.03) 1px,transparent 1px),radial-gradient(circle at top left,rgba(201,168,76,.18),transparent 35%),linear-gradient(135deg,var(--dark),#080300 70%);background-size:80px 80px,80px 80px,cover,cover;color:var(--cream)}
.header{padding:26px 42px;display:flex;justify-content:space-between;align-items:center;background:rgba(13,6,0,.78);border-bottom:1px solid rgba(201,168,76,.25)}.brand{display:flex;align-items:center;gap:14px}.logo{width:58px;height:58px;border-radius:16px;background:linear-gradient(135deg,var(--gold),var(--gold-light));color:#140900;display:flex;align-items:center;justify-content:center;font-size:28px;font-weight:bold}.brand span{font-size:11px;letter-spacing:4px;color:var(--gold-light)}.brand h1{font-size:30px}.session{display:flex;align-items:center;gap:14px}.session-box{padding:13px 18px;border-radius:999px;border:1px solid rgba(201,168,76,.25);background:rgba(13,6,0,.65);color:var(--cream2)}.logout{padding:13px 18px;border-radius:14px;text-decoration:none;color:#fca5a5;background:rgba(239,68,68,.10);border:1px solid rgba(239,68,68,.35);font-weight:bold}
.main{padding:38px}.subtitle{color:var(--gold-light);letter-spacing:8px;font-size:13px;margin-bottom:8px}.top h2{font-size:46px;margin-bottom:32px}.msg{padding:14px 18px;margin-bottom:24px;border-radius:14px;background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.35);color:#86efac}.orders-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px}.order-card{border:1px solid rgba(201,168,76,.28);border-radius:24px;background:linear-gradient(145deg,rgba(38,21,8,.78),rgba(13,6,0,.94));box-shadow:0 18px 55px rgba(0,0,0,.35);overflow:hidden}.order-header{padding:22px 24px;border-bottom:1px solid rgba(201,168,76,.16);display:flex;justify-content:space-between;align-items:center}.order-header h3{color:var(--gold-light);font-size:28px}.badge{padding:8px 12px;border-radius:999px;text-transform:uppercase;font-size:12px;font-weight:bold}.badge.pendente{color:#fbbf24;background:rgba(245,158,11,.12);border:1px solid rgba(245,158,11,.35)}.badge.preparando{color:#93c5fd;background:rgba(59,130,246,.12);border:1px solid rgba(59,130,246,.35)}.order-body{padding:22px 24px}.meta{color:rgba(245,234,216,.6);font-size:14px;margin-bottom:18px}.item-row{display:flex;justify-content:space-between;gap:18px;padding:12px 0;border-bottom:1px solid rgba(201,168,76,.10);color:var(--cream2)}.item-row strong{color:var(--cream)}.item-row:last-child{border-bottom:none}
.customization-badges{display:flex;flex-wrap:wrap;gap:4px;margin-top:4px}
.cbadge{padding:3px 9px;border-radius:999px;font-size:11px;font-weight:bold}
.cbadge.sem{background:rgba(239,68,68,.15);border:1px solid rgba(239,68,68,.35);color:#fca5a5}
.cbadge.com{background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.3);color:#86efac}
.cbadge.extra{background:rgba(245,158,11,.12);border:1px solid rgba(245,158,11,.3);color:#fbbf24}
.cbadge.outro{background:rgba(148,163,184,.1);border:1px solid rgba(148,163,184,.25);color:#cbd5e1}
.actions{padding:22px 24px;display:grid;gap:12px}button{width:100%;padding:14px;border:none;border-radius:14px;background:linear-gradient(135deg,var(--gold),var(--gold-light));color:#140900;font-weight:bold;cursor:pointer;font-size:15px;font-family:Georgia,"Times New Roman",serif}.btn-ready{background:linear-gradient(135deg,#22c55e,#86efac);color:#052e16}
.empty{padding:28px;border:1px solid rgba(201,168,76,.28);border-radius:24px;background:rgba(13,6,0,.45);color:rgba(245,234,216,.65)}
@media(max-width:1200px){.orders-grid{grid-template-columns:repeat(2,1fr)}}@media(max-width:750px){.header{flex-direction:column;align-items:flex-start;gap:18px;padding:24px 18px}.main{padding:22px 18px}.orders-grid{grid-template-columns:1fr}.top h2{font-size:34px}}
body{width:100%;min-height:100vh;display:block !important}
.header{width:100%;max-width:none !important;margin:0 !important;padding:28px 42px !important;display:flex !important;justify-content:space-between !important;align-items:center !important}
.brand{display:flex !important;align-items:center !important;gap:14px !important}
.main{width:100%;max-width:none !important;margin:0 !important;padding:42px !important}
</style>
<?php include_once __DIR__ . "/theme.php"; ?>
<link rel="stylesheet" href="assets/responsive_global.css">
</head>
<body>
<header class="header">
  <div class="brand">
    <a href="index.php" style="text-decoration:none"><img src="assets/logo.png" alt="SmartTable" style="height:72px;width:auto;object-fit:contain"></a>
    <div><span>RESTAURANT MANAGEMENT</span><h1>SmartTable</h1></div>
  </div>
  <div class="session">
    <div class="session-box">Sessão iniciada como: <strong><?= htmlspecialchars($barName) ?></strong></div>
    <a href="logout.php" class="logout">Terminar Sessão</a>
  </div>
</header>

<main class="main">
  <div class="top">
    <p class="subtitle">PAINEL DO BAR</p>
    <h2>Pedidos de Bebidas</h2>
  </div>

  <?php if ($msg !== ""): ?>
    <div class="msg"><?= htmlspecialchars($msg) ?></div>
  <?php endif; ?>

  <section class="orders-grid" id="live-content">
  <?php if ($orders && $orders->num_rows > 0): ?>
    <?php while($order = $orders->fetch_assoc()):
      $customStr = $order["customization"] ?? "";
      $badges = [];
      if ($customStr) {
        foreach (explode("|", $customStr) as $opt) {
          $opt = trim($opt);
          if ($opt === "") continue;
          if (str_starts_with($opt,"sem "))   $badges[] = ['sem',  $opt];
          elseif (str_starts_with($opt,"com ")) $badges[] = ['com',  $opt];
          elseif (str_starts_with($opt,"+"))    $badges[] = ['extra',$opt];
          else                                   $badges[] = ['outro',$opt];
        }
      }
    ?>
    <article class="order-card">
      <div class="order-header">
        <h3>Mesa <?= htmlspecialchars($order["table_number"]) ?></h3>
        <span class="badge <?= htmlspecialchars($order["status"]) ?>"><?= htmlspecialchars($order["status"]) ?></span>
      </div>
      <div class="order-body">
        <div class="meta">Pedido #<?= htmlspecialchars($order["order_id"]) ?> · <?= htmlspecialchars($order["created_at"]) ?></div>
        <div class="item-row">
          <div>
            <div><strong><?= intval($order["quantity"]) ?>x</strong> <?= htmlspecialchars($order["item_name"]) ?></div>
            <?php if (!empty($badges)): ?>
              <div class="customization-badges">
                <?php foreach ($badges as [$type,$label]): ?>
                  <span class="cbadge <?= $type ?>"><?= htmlspecialchars($label) ?></span>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
      <div class="actions">
        <?php if ($order["status"] === "pendente"): ?>
          <form method="POST">
            <input type="hidden" name="order_id" value="<?= $order["id"] ?>">
            <button type="submit" name="preparar">A ser preparado</button>
          </form>
        <?php endif; ?>
        <form method="POST" onsubmit="return confirm('Marcar bebida como pronta?')">
          <input type="hidden" name="order_id" value="<?= $order["id"] ?>">
          <button type="submit" name="pronto" class="btn-ready">Bebida pronta</button>
        </form>
      </div>
    </article>
    <?php endwhile; ?>
  <?php else: ?>
    <div class="empty">Ainda não existem pedidos de bebidas.</div>
  <?php endif; ?>
  </section>
</main>

<script src="assets/keep_session.js"></script>
</body>
</html>
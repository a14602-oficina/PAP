<?php
require_once "error_config.php";
require_once "config/db.php";
$_tRes = $conn->query("SELECT restaurant_name FROM system_settings LIMIT 1");
$_t = $_tRes ? $_tRes->fetch_assoc() : [];
$restaurantName = htmlspecialchars($_t['restaurant_name'] ?? 'SmartTable');
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title><?= $restaurantName ?> — Painel Principal</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="favicon.ico" sizes="any">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="apple-touch-icon" href="assets/logo.png">
<link rel="manifest" href="site.webmanifest">
<link rel="manifest" href="manifest.json">
<meta name="theme-color" content="#0d0600">
<style>
  *{margin:0;padding:0;box-sizing:border-box}
  :root{
    --gold:     #c9a84c;
    --gold-l:   #e8c97a;
    --dark:     #0d0600;
    --cream:    #f5ead8;
    --font:     Georgia, "Times New Roman", serif;
  }
  body{
    min-height:100vh;
    background:
      linear-gradient(90deg,rgba(201,168,76,.04) 1px,transparent 1px),
      linear-gradient(rgba(201,168,76,.03) 1px,transparent 1px),
      radial-gradient(ellipse at 20% 50%,rgba(201,168,76,.12) 0%,transparent 55%),
      radial-gradient(ellipse at 80% 20%,rgba(201,168,76,.08) 0%,transparent 45%),
      linear-gradient(135deg,var(--dark) 0%,#080300 100%);
    background-size:80px 80px,80px 80px,cover,cover,cover;
    font-family:var(--font);
    color:var(--cream);
    display:flex;
    flex-direction:column;
    align-items:center;
    justify-content:center;
    padding:40px 20px;
  }
  /* ── HEADER ── */
  .header{
    text-align:center;
    margin-bottom:64px;
    animation:fadeDown .7s ease both;
  }
  .logo-ring{
    width:88px;height:88px;
    border-radius:24px;
    background:linear-gradient(135deg,var(--gold),var(--gold-l));
    display:flex;align-items:center;justify-content:center;
    font-size:40px;font-weight:bold;color:#140900;
    margin:0 auto 24px;
    box-shadow:0 16px 48px rgba(201,168,76,.35);
  }
  .eyebrow{
    font-size:11px;letter-spacing:6px;
    color:rgba(201,168,76,.6);
    margin-bottom:10px;
    text-transform:uppercase;
  }
  h1{
    font-size:clamp(36px,6vw,56px);
    line-height:1.05;
    color:var(--cream);
    font-weight:normal;
    margin-bottom:10px;
  }
  h1 span{
    background:linear-gradient(135deg,var(--gold),var(--gold-l));
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
    background-clip:text;
  }
  .sub{
    font-size:15px;
    color:rgba(245,234,216,.45);
    letter-spacing:1px;
  }
  /* ── GRID ── */
  .grid{
    display:flex;
    align-items:flex-end;   /* alinha pela base — efeito pódio */
    justify-content:center;
    gap:16px;
    width:100%;
    max-width:960px;
    animation:fadeUp .7s .15s ease both;
  }
  .card{
    flex:1;
    max-width:300px;
  }
  /* ── CARD ── */
  .card{
    position:relative;
    text-decoration:none;
    border-radius:22px;
    border:1px solid rgba(201,168,76,.22);
    background:linear-gradient(145deg,rgba(30,16,4,.9),rgba(13,6,0,.97));
    padding:32px 28px;
    display:flex;flex-direction:column;gap:12px;
    transition:transform .22s ease,box-shadow .22s ease,border-color .22s ease;
    overflow:hidden;
    cursor:pointer;
  }
  .card::before{
    content:'';
    position:absolute;inset:0;
    border-radius:inherit;
    background:linear-gradient(135deg,var(--gold),var(--gold-l));
    opacity:0;
    transition:opacity .22s;
  }
  .card:hover{
    transform:translateY(-6px);
    box-shadow:0 24px 60px rgba(0,0,0,.5), 0 0 0 1px rgba(201,168,76,.4);
    border-color:rgba(201,168,76,.5);
  }
  .card:hover::before{ opacity:.06; }
  .card:active{ transform:translateY(-2px); }
  .card-icon{
    font-size:36px;
    line-height:1;
    position:relative;z-index:1;
  }
  .card-label{
    font-size:11px;
    letter-spacing:4px;
    color:rgba(201,168,76,.55);
    text-transform:uppercase;
    position:relative;z-index:1;
  }
  .card-title{
    font-size:24px;
    color:var(--cream);
    line-height:1.2;
    font-weight:normal;
    position:relative;z-index:1;
  }
  .card-desc{
    font-size:13px;
    color:rgba(245,234,216,.45);
    line-height:1.6;
    position:relative;z-index:1;
    flex:1;
  }
  .card-arrow{
    display:inline-flex;align-items:center;gap:6px;
    font-size:13px;font-weight:bold;
    color:var(--gold);
    position:relative;z-index:1;
    transition:gap .2s;
  }
  .card:hover .card-arrow{ gap:10px; }
  /* Card de destaque (login) — pódio: mais alto, no centro */
  .card.featured{
    margin-bottom: 40px;   /* sobe 40px acima dos outros dois */
    border-color:rgba(201,168,76,.55);
    background:linear-gradient(145deg,rgba(60,33,5,.95),rgba(20,9,0,.98));
    box-shadow:0 12px 48px rgba(201,168,76,.18), 0 0 0 1px rgba(201,168,76,.25);
    padding:40px 28px;
  }
  .card.featured .card-icon{ font-size:48px; }
  .card.featured .card-title{ font-size:28px; color:var(--gold-l); }
  .card.featured .card-label{ color:rgba(201,168,76,.8); }
  .card.featured .card-arrow{ font-size:14px; color:var(--gold-l); }
  .card.featured::after{
    content:'';
    position:absolute;top:0;left:0;right:0;height:4px;
    background:linear-gradient(90deg,transparent,var(--gold),var(--gold-l),var(--gold),transparent);
    border-radius:22px 22px 0 0;
  }
  .card.featured:hover{
    transform:translateY(-8px);
    box-shadow:0 32px 80px rgba(0,0,0,.6), 0 0 0 1px var(--gold), 0 0 60px rgba(201,168,76,.22);
    border-color:var(--gold);
  }
  /* ── FOOTER ── */
  .footer{
    margin-top:48px;
    font-size:12px;
    color:rgba(245,234,216,.2);
    letter-spacing:2px;
    text-align:center;
    animation:fadeUp .7s .3s ease both;
  }
  /* ── ANIMATIONS ── */
  @keyframes fadeDown{
    from{opacity:0;transform:translateY(-20px)}
    to{opacity:1;transform:translateY(0)}
  }
  @keyframes fadeUp{
    from{opacity:0;transform:translateY(20px)}
    to{opacity:1;transform:translateY(0)}
  }
  /* ── RESPONSIVE ── */
  @media(max-width:700px){
    .grid{ flex-direction:column; align-items:center; }
    .card{ max-width:100%; width:100%; }
    .card.featured{ margin-bottom:0; order:-1; }
    .header{ margin-bottom:40px; }
  }

  /* ── BOTÃO INSTALAR APP (PWA) ── */
  #btnInstalarApp{
    display:none;
    padding:14px 26px;
    border-radius:14px;
    border:1px solid rgba(201,168,76,.4);
    background:linear-gradient(135deg,var(--gold),var(--gold-l));
    color:#140900;
    font-weight:bold;
    font-size:14px;
    cursor:pointer;
    font-family:var(--font);
    position:fixed;
    bottom:24px;
    right:24px;
    z-index:9999;
    box-shadow:0 8px 24px rgba(0,0,0,.45);
    transition:transform .2s ease, box-shadow .2s ease;
  }
  #btnInstalarApp:hover{
    transform:translateY(-3px);
    box-shadow:0 12px 32px rgba(201,168,76,.35);
  }
  #btnInstalarApp:active{ transform:translateY(-1px); }
  @media(max-width:700px){
    #btnInstalarApp{
      bottom:18px; right:18px; left:18px;
      width:auto; text-align:center;
    }
  }
</style>
</head>
<body>
<header class="header">
  <img src="assets/logo.png" alt="SmartTable" style="height:160px;width:auto;object-fit:contain">
  <p class="eyebrow">Restaurant Management</p>
  <h1><?= $restaurantName ?></h1>
  <p class="sub">Seleciona o teu painel de acesso</p>
</header>
<div class="grid">
  <!-- Mesa Dashboard — esquerda -->
  <a href="mesa_dashboard.php" class="card">
    <div class="card-icon">🪑</div>
    <p class="card-label">Tablet de Mesa</p>
    <h2 class="card-title">Selecionar Mesa</h2>
    <p class="card-desc">Escolhe a tua mesa e acede ao menu para fazer o teu pedido diretamente.</p>
    <span class="card-arrow">Ir para mesa →</span>
  </a>
  <!-- Login — centro, em destaque -->
  <a href="login.php" class="card featured">
    <div class="card-icon">🔐</div>
    <p class="card-label">Autenticação</p>
    <h2 class="card-title">Entrar no Sistema</h2>
    <p class="card-desc">Acede ao teu painel de administrador, empregado de mesa, cozinha, bar ou gerente. Login por utilizador e palavra-passe ou cartão RFID.</p>
    <span class="card-arrow">Fazer login →</span>
  </a>
  <!-- Entrada Dashboard — direita -->
  <a href="entrada_dashboard.php" class="card">
    <div class="card-icon">🚪</div>
    <p class="card-label">Receção</p>
    <h2 class="card-title">Painel de Entrada</h2>
    <p class="card-desc">Visão geral das mesas disponíveis e ocupadas. Chamar gerente em caso de necessidade.</p>
    <span class="card-arrow">Abrir painel →</span>
  </a>
</div>

<!-- Botão de instalação da PWA -->
<button id="btnInstalarApp">📲 Instalar App</button>

<script>
// Registar o service worker (necessário para a PWA ser instalável)
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('sw.js')
    .then(() => console.log('Service Worker registado'))
    .catch(err => console.log('Erro ao registar Service Worker:', err));
}

// Capturar o evento de instalação da PWA (Chrome/Android/Edge)
let deferredPrompt;
const btnInstalar = document.getElementById('btnInstalarApp');

window.addEventListener('beforeinstallprompt', (e) => {
  // Impede o prompt automático do browser
  e.preventDefault();
  deferredPrompt = e;

  // Mostrar o botão personalizado de instalação
  btnInstalar.style.display = 'block';
});

btnInstalar.addEventListener('click', async () => {
  if (!deferredPrompt) return;

  // Mostrar o prompt nativo de instalação
  deferredPrompt.prompt();

  const { outcome } = await deferredPrompt.userChoice;

  if (outcome === 'accepted') {
    console.log('App SmartTable instalada com sucesso');
  }

  // Esconder o botão depois de usado
  btnInstalar.style.display = 'none';
  deferredPrompt = null;
});

// Esconder o botão se a app já estiver instalada
window.addEventListener('appinstalled', () => {
  btnInstalar.style.display = 'none';
});
</script>
</body>
</html>